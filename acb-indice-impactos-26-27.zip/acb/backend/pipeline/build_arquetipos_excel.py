# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""Excel para que Miguel revise/corrija a mano el arquetipo de los 224
jugadores del roster 26/27: Jugador, Equipo, Posicion, Arquetipo (el que
asigna hoy el modelo) + una columna en blanco para que escriba el suyo.
Con eso como "ground truth" se podria entrenar despues un clasificador de
arquetipo real (en vez del arbol de reglas fijas actual)."""
import json
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

with open('roster_dashboard_data.json', encoding='utf-8') as f:
    data = json.load(f)

POS_ES = {'Guard': 'Base/Escolta', 'Forward': 'Alero/Ala-Pívot', 'Center': 'Pívot'}
STATUS_ES = {'returning': 'Se queda', 'alta_acb': 'Alta (ACB->ACB)', 'alta_extranjero': 'Alta (fuera ACB)'}

rows = []
for team, eq in data['equipos'].items():
    for p in eq['roster_26_27']:
        rows.append({
            'Jugador': p['player'],
            'Equipo': team,
            'Posición': POS_ES.get(p.get('pos_group'), p.get('pos_group') or ''),
            'Estado': STATUS_ES.get(p.get('status'), p.get('status')),
            'Arquetipo (modelo hoy)': p.get('role_es') or p.get('role') or 'Sin clasificar',
            'Arquetipo (Miguel)': None,
            'Rating actual': p.get('rating_0_100'),
        })

df = pd.DataFrame(rows).sort_values(['Equipo', 'Jugador'])
print(f"{len(df)} jugadores")

wb = openpyxl.Workbook()
ws = wb.active
ws.title = 'Arquetipos 26-27'
headers = list(df.columns)
ws.append(headers)
FONT = 'Arial'
header_fill = PatternFill('solid', fgColor='1F2937')
header_font = Font(name=FONT, bold=True, color='FFFFFF', size=11)
normal_font = Font(name=FONT, size=10)
input_fill = PatternFill('solid', fgColor='FFF6CC')
input_font = Font(name=FONT, size=10, color='7A5B00')
thin = Side(style='thin', color='D9D9D9')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
for c in range(1, len(headers) + 1):
    cell = ws.cell(row=1, column=c)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.border = border

input_col = headers.index('Arquetipo (Miguel)') + 1
for _, row in df.iterrows():
    ws.append(list(row))
for i in range(2, ws.max_row + 1):
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=i, column=c)
        cell.border = border
        cell.alignment = Alignment(vertical='center', wrap_text=True)
        if c == input_col:
            cell.font = input_font
            cell.fill = input_fill
        else:
            cell.font = normal_font

widths = [22, 24, 18, 16, 22, 22, 12]
for i, w in enumerate(widths[:len(headers)], start=1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = 'A2'
ws.auto_filter.ref = f'A1:{get_column_letter(len(headers))}{ws.max_row}'

ws2 = wb.create_sheet('Léeme')
ws2.column_dimensions['A'].width = 105
lines = [
    f'{len(df)} JUGADORES -- todo el roster 26/27, con el arquetipo que les asigna el modelo hoy.',
    '',
    'Cómo usarlo: escribe en la columna amarilla "Arquetipo (Miguel)" el arquetipo que tú le darías a cada',
    'jugador (puedes usar tus propias etiquetas, no hace falta que sean las mismas 11 del modelo). Para los',
    'que ya estén bien tal y como los tiene el modelo, puedes dejarlo en blanco o copiar el mismo valor --',
    'lo que importe es que quede claro dónde SÍ corriges algo.',
    '',
    'Para qué es: con tus correcciones como referencia, se puede entrenar un clasificador de arquetipo real',
    '(a partir de las métricas de cada jugador -- % de uso, % de asistencias, % de triples, altura, etc.)',
    'en vez del árbol de reglas fijas que usa el modelo ahora mismo, que es el que hace la asignación de la',
    'columna "Arquetipo (modelo hoy)".',
    '',
    '"Rating actual" es solo de referencia (el rating 26/27 ya publicado en el dashboard), no hace falta',
    'que lo mires para esto.',
]
for i, l in enumerate(lines, start=1):
    ws2.cell(row=i, column=1, value=l).font = Font(name=FONT, size=10, bold=(i == 1))
    ws2.cell(row=i, column=1).alignment = Alignment(wrap_text=True, vertical='top')

wb.save('Arquetipos_26-27_revision_Miguel.xlsx')
print('OK -> Arquetipos_26-27_revision_Miguel.xlsx')

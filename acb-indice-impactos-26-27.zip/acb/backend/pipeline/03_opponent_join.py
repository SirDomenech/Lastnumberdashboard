import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

tg = pd.read_csv('team_game.csv')

# self-join: for each team-game row, pull the opponent's row for the same game
opp = tg.rename(columns={
    'Nombre equipo': 'Opp_Team',
})
opp_cols = ['ID Partido','Opp_Team','PTS','FTM','FTA','P2M','P2A','P3M','P3A','AST','OREB','DREB','TRB',
            'STL','TOV','BLK','BLK_against','PF','FoulsDrawn','FGM','FGA']
opp = opp[opp_cols]
opp = opp.add_prefix('Opp_')
opp = opp.rename(columns={'Opp_ID Partido': 'ID Partido', 'Opp_Opp_Team': 'Opp_Team'})

# join on ID Partido + "the other team in this game" (Rival names are abbreviated/inconsistent,
# so instead join every team-row to every other row of the same game, then drop self-matches)
merged = tg.merge(opp, on='ID Partido', how='left')
merged = merged[merged['Nombre equipo'] != merged['Opp_Team']].reset_index(drop=True)

print("rows after merge:", merged.shape)
print("nulls in Opp_PTS:", merged['Opp_PTS'].isna().sum())

# sanity: Opp_PTS should equal PTS of the rival row, and rival's Opp_PTS should equal this team's PTS
check = merged[['ID Partido','Nombre equipo','Rival','PTS','Opp_PTS']].head(6)
print(check)

# --- possession estimate per team-game (standard NBA-style formula), then game pace = avg of both teams ---
def poss_est(row, prefix=''):
    FGA = row[f'{prefix}FGA']
    OREB = row[f'{prefix}OREB']
    TOV = row[f'{prefix}TOV']
    FTA = row[f'{prefix}FTA']
    return FGA - OREB + TOV + 0.44*FTA

merged['POSS_own_est'] = merged.apply(lambda r: poss_est(r, ''), axis=1)
merged['POSS_opp_est'] = merged.apply(lambda r: poss_est(r, 'Opp_'), axis=1)
merged['POSS_game'] = (merged['POSS_own_est'] + merged['POSS_opp_est']) / 2

print(merged[['ID Partido','Nombre equipo','POSS_own_est','POSS_opp_est','POSS_game']].head(6))

merged.to_csv('team_game_full.csv', index=False)
print("saved team_game_full.csv, shape:", merged.shape)

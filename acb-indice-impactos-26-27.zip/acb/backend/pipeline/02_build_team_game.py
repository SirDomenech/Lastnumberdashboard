import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

BOX = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77c1dac6-Box_Scores_ACB.csv"

df = pd.read_csv(BOX)

# --- canonicalize team names (sponsor renames mid-season) ---
NAME_MAP = {
    'Asisa Joventut': 'Joventut Badalona',
    'Joventut Badalona': 'Joventut Badalona',
    'Kosner Baskonia': 'Baskonia',
    'Baskonia': 'Baskonia',
    'Surne Bilbao': 'Surne Bilbao Basket',
    'Surne Bilbao Basket': 'Surne Bilbao Basket',
}
def canon(x):
    return NAME_MAP.get(x, x)

for col in ['Nombre equipo', 'Rival', 'Equipo local', 'Equipo visitante']:
    df[col] = df[col].map(canon)

teams = sorted(df['Nombre equipo'].unique())
print("N teams after canonicalization:", len(teams))
print(teams)

games_per_team = df.groupby('Nombre equipo')['ID Partido'].nunique()
print(games_per_team.sort_values())

# --- aggregate player rows to team-game level ---
agg_cols = {
    'points': 'sum',
    'freeThrowsMade': 'sum',
    'freeThrowsAttempted': 'sum',
    'twoPointersMade': 'sum',
    'twoPointersAttempted': 'sum',
    'threePointersMade': 'sum',
    'threePointersAttempted': 'sum',
    'assists': 'sum',
    'offRebounds': 'sum',
    'defRebounds': 'sum',
    'totalRebounds': 'sum',
    'steals': 'sum',
    'turnovers': 'sum',
    'blocks': 'sum',
    'receivedBlocks': 'sum',
    'personalFouls': 'sum',
    'foulsDrawn': 'sum',
    'Puntos totales equipo': 'first',
    'Rival': 'first',
    'Jornada': 'first',
}
tg = df.groupby(['ID Partido', 'Nombre equipo'], as_index=False).agg(agg_cols)
tg = tg.rename(columns={
    'points': 'PTS', 'freeThrowsMade': 'FTM', 'freeThrowsAttempted': 'FTA',
    'twoPointersMade': 'P2M', 'twoPointersAttempted': 'P2A',
    'threePointersMade': 'P3M', 'threePointersAttempted': 'P3A',
    'assists': 'AST', 'offRebounds': 'OREB', 'defRebounds': 'DREB', 'totalRebounds': 'TRB',
    'steals': 'STL', 'turnovers': 'TOV', 'blocks': 'BLK', 'receivedBlocks': 'BLK_against',
    'personalFouls': 'PF', 'foulsDrawn': 'FoulsDrawn',
})
tg['FGM'] = tg['P2M'] + tg['P3M']
tg['FGA'] = tg['P2A'] + tg['P3A']

print("team-game rows:", tg.shape)

# validation: sum of player points == official team total points for that game
mismatch = tg[tg['PTS'] != tg['Puntos totales equipo']]
print("mismatches PTS vs Puntos totales equipo:", len(mismatch))
if len(mismatch):
    print(mismatch[['ID Partido','Nombre equipo','PTS','Puntos totales equipo']].head(20))

tg.to_csv('team_game.csv', index=False)
print("saved team_game.csv")

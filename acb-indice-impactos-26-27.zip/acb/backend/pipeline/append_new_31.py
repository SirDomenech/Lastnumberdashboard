# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""Añade a jugadores_miguel_completado.csv los 31 jugadores de los 4 equipos
nuevos (MoraBanc Andorra, Recoletas Salud San Pablo Burgos, Río Breogán,
Monbus Obradoiro) investigados via acb.com/proballers/wikipedia/realgm por
Claude (mismo proceso que el pase inicial de Valencia/Real Madrid) -- estos
NO estan confirmados por Miguel todavia, se marcan explicitamente como tal."""
import pandas as pd

NEW_ROWS = [
    # --- MoraBanc Andorra ---
    dict(Jugador="James Akinjo", equipo="MoraBanc Andorra", pos="Base", pos_det="Base organizador",
         alt=1.85, fnac="27/11/2000", origen="Ness Ziona", liga="Israel"),
    dict(Jugador="Aaron Best", equipo="MoraBanc Andorra", pos="Escolta", pos_det="Escolta tirador/defensivo",
         alt=1.93, fnac="01/09/1992", origen="MoraBanc Andorra (renovación)", liga="ACB"),
    dict(Jugador="Chumi Ortega", equipo="MoraBanc Andorra", pos="Escolta", pos_det="Escolta defensivo",
         alt=1.90, fnac="13/08/1997", origen="MoraBanc Andorra (renovación)", liga="ACB"),
    dict(Jugador="Kassius Robertson", equipo="MoraBanc Andorra", pos="Escolta", pos_det="Escolta anotador/tirador",
         alt=1.91, fnac="20/04/1994", origen="Dreamland Gran Canaria", liga="ACB"),
    dict(Jugador="Lazar Mutic", equipo="MoraBanc Andorra", pos="Alero", pos_det="Alero polivalente",
         alt=2.03, fnac="06/01/1999", origen="BC Lietkabelis", liga="Lituania"),
    dict(Jugador="Wes Iwundu", equipo="MoraBanc Andorra", pos="Alero", pos_det="Alero-escolta defensor",
         alt=1.98, fnac="20/12/1994", origen="Ironi Kiryat Ata", liga="Israel"),
    dict(Jugador="Cameron McGriff", equipo="MoraBanc Andorra", pos="Ala-Pívot", pos_det="Ala-pívot físico",
         alt=2.01, fnac="30/09/1997", origen="Salt Lake City Stars", liga="G League"),
    dict(Jugador="Owen Aquino", equipo="MoraBanc Andorra", pos="Ala-Pívot", pos_det="Ala-pívot interior",
         alt=2.03, fnac="08/01/2003", origen="Universidad de High Point", liga="NCAA"),
    dict(Jugador="Leon Radosevic", equipo="MoraBanc Andorra", pos="Pívot", pos_det="Pívot de experiencia",
         alt=2.08, fnac="26/02/1990", origen="Treviso Basket", liga="Italia"),
    # --- Recoletas Salud San Pablo Burgos ---
    dict(Jugador="DJ Steward", equipo="Recoletas Salud San Pablo Burgos", pos="Base", pos_det="Base organizador",
         alt=1.88, fnac="02/10/2001", origen="Trentino", liga="Italia"),
    dict(Jugador="Ziga Samar", equipo="Recoletas Salud San Pablo Burgos", pos="Base", pos_det="",
         alt=1.97, fnac="26/01/2001", origen="Dreamland Gran Canaria", liga="ACB"),
    dict(Jugador="Chase Audige", equipo="Recoletas Salud San Pablo Burgos", pos="Escolta", pos_det="",
         alt=1.93, fnac="29/06/1999", origen="Unicaja", liga="ACB"),
    dict(Jugador="Raúl Lobaco", equipo="Recoletas Salud San Pablo Burgos", pos="Escolta", pos_det="",
         alt=1.90, fnac="29/11/2000", origen="Alimerka Oviedo", liga="Primera FEB"),
    dict(Jugador="Retin Obasohan", equipo="Recoletas Salud San Pablo Burgos", pos="Base-Escolta", pos_det="Combo guard",
         alt=1.91, fnac="06/07/1993", origen="Kids&Us Manresa", liga="ACB"),
    dict(Jugador="Dusan Radosavljevic", equipo="Recoletas Salud San Pablo Burgos", pos="Alero", pos_det="Alero polivalente",
         alt=2.01, fnac="03/11/2001", origen="FMP SoccerBet", liga="Serbia"),
    dict(Jugador="Vlatko Cancar", equipo="Recoletas Salud San Pablo Burgos", pos="Alero", pos_det="",
         alt=2.01, fnac="10/04/1997", origen="EA7 Milán", liga="Italia/Euroliga"),
    dict(Jugador="Christian Sengfelder", equipo="Recoletas Salud San Pablo Burgos", pos="Ala-Pívot", pos_det="Ala-pívot versátil",
         alt=2.03, fnac="28/02/1995", origen="Ratiopharm Ulm", liga="Alemania"),
    dict(Jugador="Sekou Doumbouya", equipo="Recoletas Salud San Pablo Burgos", pos="Ala-Pívot", pos_det="Ala-pívot físico",
         alt=2.06, fnac="23/12/2000", origen="Koshigaya Alphas", liga="Japón"),
    dict(Jugador="Balsa Koprivica", equipo="Recoletas Salud San Pablo Burgos", pos="Pívot", pos_det="Pívot defensivo",
         alt=2.16, fnac="01/05/2000", origen="Bahcesehir Koleji", liga="Turquía"),
    dict(Jugador="Rubén Guerrero", equipo="Recoletas Salud San Pablo Burgos", pos="Pívot", pos_det="Pívot de área",
         alt=2.13, fnac="22/10/1995", origen="MoraBanc Andorra", liga="ACB"),
    # --- Río Breogán ---
    dict(Jugador="Rasir Bolton", equipo="Río Breogán", pos="Base", pos_det="Base organizador-anotador",
         alt=1.90, fnac="27/09/1999", origen="GeVi Napoli", liga="Italia"),
    dict(Jugador="Josep Peris", equipo="Río Breogán", pos="Escolta", pos_det="Escolta tirador/versátil",
         alt=1.92, fnac="06/08/2000", origen="CB Zamora", liga="España (liga inferior)"),
    dict(Jugador="Tevin Brown", equipo="Río Breogán", pos="Alero", pos_det="Alero anotador/tirador",
         alt=1.95, fnac="23/09/1998", origen="Rasta Vechta", liga="Alemania"),
    dict(Jugador="Andersson García", equipo="Río Breogán", pos="Ala-Pívot", pos_det="Ala-pívot defensivo/reboteador",
         alt=2.01, fnac="23/08/2000", origen="Utah Jazz", liga="NBA/G League"),
    dict(Jugador="Edgar Vicedo", equipo="Río Breogán", pos="Ala-Pívot", pos_det="Ala-pívot tirador",
         alt=2.04, fnac="24/08/1994", origen="Hestia Menorca", liga="España (liga inferior)"),
    dict(Jugador="Aleksa Ilic", equipo="Río Breogán", pos="Pívot", pos_det="Pívot móvil, defensor",
         alt=2.04, fnac="17/09/1996", origen="SC Derby", liga="Montenegro"),
    dict(Jugador="Jonathan Kasibabu", equipo="Río Breogán", pos="Pívot", pos_det="Pívot físico/defensivo",
         alt=2.04, fnac="24/04/1996", origen="Flexicar Fuenlabrada", liga="ACB/LEB"),
    # --- Monbus Obradoiro (ascendido de Primera FEB) ---
    dict(Jugador="Brandon Childress", equipo="Monbus Obradoiro", pos="Base", pos_det="Base organizador",
         alt=1.83, fnac="31/08/1997", origen="Bursaspor", liga="Turquía"),
    dict(Jugador="Caleb Agada", equipo="Monbus Obradoiro", pos="Escolta", pos_det="",
         alt=1.93, fnac="31/08/1994", origen="Ilerna Lleida", liga="ACB"),
    dict(Jugador="Leo Meindl", equipo="Monbus Obradoiro", pos="Alero", pos_det="",
         alt=2.01, fnac="20/03/1993", origen="Recoletas Salud San Pablo Burgos", liga="ACB"),
    dict(Jugador="Alonso Faure", equipo="Monbus Obradoiro", pos="Pívot", pos_det="(acb.com lo ficha como Pívot; procedencia indicaba Ala-Pívot)",
         alt=2.08, fnac="20/02/2002", origen="Alimerka Oviedo", liga="Primera FEB"),
    dict(Jugador="Efe Abogidi", equipo="Monbus Obradoiro", pos="Ala-Pívot", pos_det="",
         alt=2.08, fnac="11/10/2001", origen="Rio Grande Valley", liga="G League"),
    dict(Jugador="Joel Soriano", equipo="Monbus Obradoiro", pos="Pívot", pos_det="",
         alt=2.08, fnac="30/01/2000", origen="Ratiopharm Ulm", liga="Alemania"),
]

_POS_PRIMARIA_CANON = {'Base':'Base','Escolta':'Escolta','Base-Escolta':'Base-Escolta','Alero':'Alero',
                        'Ala-Pívot':'Ala-Pívot','Pívot':'Pívot'}

rows_out = []
for r in NEW_ROWS:
    rows_out.append({
        'Jugador': r['Jugador'],
        'Equipo destino': r['equipo'],
        'Posición detectada': r['pos'],
        'Fuente / confianza': 'PENDIENTE DE CONFIRMAR POR MIGUEL -- investigación Claude via acb.com/proballers/wikipedia/realgm (26/27)',
        'Posición primaria': r['pos'],
        'Posición en detalle': r['pos_det'],
        'Altura (m)': r['alt'],
        'Fecha nacimiento / Edad': r['fnac'],
        'Equipo origen': r['origen'],
        'Liga origen': r['liga'],
        'Temporada ref.': '2025-26',
        'PJ': None, 'MPG': None, 'PPG': None, 'RPG': None, 'APG': None, 'BPG': None,
        'Notas': 'Alta nueva (equipo añadido al modelo completo tras el fichero de fichajes ampliado a 18 equipos). Estadísticas de temporada en la hoja de fichajes, no aquí.',
    })

existing = pd.read_csv('jugadores_miguel_completado.csv')
new_df = pd.DataFrame(rows_out)
combined = pd.concat([existing, new_df], ignore_index=True)
combined.to_csv('jugadores_miguel_completado.csv', index=False)
print(f"OK -- {len(existing)} filas existentes + {len(new_df)} nuevas = {len(combined)} filas totales")

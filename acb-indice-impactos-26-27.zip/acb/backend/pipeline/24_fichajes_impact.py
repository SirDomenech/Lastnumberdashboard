# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Modelo de impacto de fichajes 26/27 (fase 1 — solo movimientos medibles).

Decisión de alcance (confirmada por el usuario): de las 135 altas del mercado 26/27,
solo 32 (24%) tienen histórico medible en Liga Endesa (jugadores que ya jugaban en
ACB y cambian de equipo); el resto son fichajes de otras ligas o debutantes sin
boxscore propio. Las bajas sí están casi completas (64 de 75, 85%).

En vez de estimar el 76% de altas sin datos con un proxy débil, el modelo se
construye SOLO sobre movimientos medibles (altas con histórico ACB + todas las
bajas con histórico ACB) y expone explícitamente, por equipo, qué porcentaje de
su mercado queda fuera del cálculo (columna cobertura_altas_pct).

Unidad de valor: Hollinger Game Score por partido (GmSc/PJ), una métrica estándar
de producción individual por partido:
    GmSc = PTS + 0.4*FGM - 0.7*FGA - 0.4*(FTA-FTM) + 0.7*OREB + 0.3*DREB
           + STL + 0.7*AST + 0.7*BLK - 0.4*PF - TOV
Se calcula sobre los totales de la temporada de referencia y se divide por
partidos jugados -> GmSc/PJ. Es una cifra ya usada de forma estándar en
baloncesto (NBA/ACB-style box score) para resumir la producción de un jugador
en un número, combinando volumen y eficiencia sin inventar una ponderación ad hoc.

Salida: fichajes_impact.json con, por equipo:
  - bajas: nº y detalle de jugadores medibles que se van, GmSc/PJ perdido total
  - altas: nº y detalle de jugadores medibles que llegan, GmSc/PJ ganado total
  - cobertura_altas_pct: % de las altas totales del equipo que tienen dato medible
  - balance_medible: ganado - perdido (SOLO sobre la parte medible, no es una
    predicción completa del mercado)
"""
import pandas as pd
import numpy as np
import unicodedata
import json

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 60)

# ---------------- Game Score por partido, desde player_season.csv ----------------
ps = pd.read_csv('player_season.csv')

GmSc = (ps['PTS'] + 0.4*ps['FGM'] - 0.7*ps['FGA'] - 0.4*(ps['FTA']-ps['FTM'])
        + 0.7*ps['OREB'] + 0.3*ps['DREB'] + ps['STL'] + 0.7*ps['AST']
        + 0.7*ps['BLK'] - 0.4*ps['PF'] - ps['TOV'])
ps['GmSc_total'] = GmSc
ps['GmSc_PJ'] = ps['GmSc_total'] / ps['games']

def norm(s):
    if pd.isna(s):
        return ''
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode('ascii')
    return ' '.join(s.lower().strip().split())

ps['name_norm'] = ps['nickname'].map(norm)
ps_by_name = ps.set_index('name_norm')

# ---------------- mercado 26/27 ----------------
mk = pd.read_csv('mercado_2026_27.csv')
mk['name_norm'] = mk['Jugador'].map(norm)

def lookup_gmsc(name):
    row = ps_by_name.loc[name] if name in ps_by_name.index else None
    if row is None:
        return None
    if isinstance(row, pd.DataFrame):  # nombre duplicado, coger el de más partidos
        row = row.sort_values('games', ascending=False).iloc[0]
    return row

mk['GmSc_PJ'] = np.nan
mk['games_ref'] = np.nan
mk['team_last_ref'] = None
for i, r in mk.iterrows():
    row = lookup_gmsc(r['name_norm'])
    if row is not None:
        mk.loc[i, 'GmSc_PJ'] = row['GmSc_PJ']
        mk.loc[i, 'games_ref'] = row['games']
        mk.loc[i, 'team_last_ref'] = row['team_last']

mk['medible'] = mk['GmSc_PJ'].notna()

# nombres de equipo canónicos del dashboard (coinciden con TEAMS/LOGOS/ABBR)
TEAM_NAME_MAP = {
    'Rio Breogan': 'Río Breogán',
    'Leyma Coruña (ASCIENDE)': 'Leyma Coruña',
    'Monbus Obradoiro (ASCIENDE)': 'Monbus Obradoiro',
}
mk['Equipo'] = mk['Equipo'].map(lambda x: TEAM_NAME_MAP.get(x, x))

NEW_TEAMS = ['Leyma Coruña', 'Monbus Obradoiro']

teams = sorted(mk['Equipo'].unique())
out = {}
for team in teams:
    sub = mk[mk['Equipo'] == team]
    altas = sub[sub['Tipo'] == 'Alta']
    bajas = sub[sub['Tipo'] == 'Baja']

    altas_med = altas[altas['medible']]
    bajas_med = bajas[bajas['medible']]

    n_altas, n_altas_med = len(altas), len(altas_med)
    n_bajas, n_bajas_med = len(bajas), len(bajas_med)

    cobertura_altas = round(100 * n_altas_med / n_altas, 1) if n_altas else None
    cobertura_bajas = round(100 * n_bajas_med / n_bajas, 1) if n_bajas else None

    ganado = round(altas_med['GmSc_PJ'].sum(), 2)
    perdido = round(bajas_med['GmSc_PJ'].sum(), 2)
    balance = round(ganado - perdido, 2)

    def detail(df):
        return [
            {
                'jugador': r['Jugador'],
                'procedencia_destino': r['Club_relacionado'],
                'gmsc_pj': round(r['GmSc_PJ'], 2),
                'equipo_referencia': r['team_last_ref'],
                'partidos_referencia': int(r['games_ref']) if not pd.isna(r['games_ref']) else None,
            }
            for _, r in df.sort_values('GmSc_PJ', ascending=False).iterrows()
        ]

    out[team] = {
        'equipo': team,
        'es_ascendido': team in NEW_TEAMS,
        'altas_total': n_altas,
        'altas_medibles': n_altas_med,
        'cobertura_altas_pct': cobertura_altas,
        'bajas_total': n_bajas,
        'bajas_medibles': n_bajas_med,
        'cobertura_bajas_pct': cobertura_bajas,
        'gmsc_pj_ganado_medible': ganado,
        'gmsc_pj_perdido_medible': perdido,
        'balance_medible': balance,
        'detalle_altas_medibles': detail(altas_med),
        'detalle_bajas_medibles': detail(bajas_med),
    }

with open('fichajes_impact.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

# ---------------- resumen en consola ----------------
summary = pd.DataFrame(out).T[['altas_total','altas_medibles','cobertura_altas_pct',
                                'bajas_total','bajas_medibles','cobertura_bajas_pct',
                                'gmsc_pj_ganado_medible','gmsc_pj_perdido_medible','balance_medible']]
summary = summary.sort_values('balance_medible', ascending=False)
print(summary.to_string())
print()
print(f"Cobertura global altas: {mk[mk['Tipo']=='Alta']['medible'].mean()*100:.1f}%")
print(f"Cobertura global bajas: {mk[mk['Tipo']=='Baja']['medible'].mean()*100:.1f}%")

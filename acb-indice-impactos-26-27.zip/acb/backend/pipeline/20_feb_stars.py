import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 100)

OUT_TEAMS = ['Coviran Granada', 'Dreamland Gran Canaria']

acb = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
acb_full = acb.join(track, how='left')
acb_full['PF_per100'] = acb_full['PF'] / acb_full['POSS'] * 100
acb_full['Top3_share'] = pd.read_csv('scoring_top3share.csv', index_col=0)['share']
acb_cont = acb_full.drop(index=[t for t in OUT_TEAMS if t in acb_full.index])

trans = pd.read_csv('feb_translated_to_acb.csv', index_col=0)
trans.index = ['Leyma Coruña', 'Monbus Obradoiro']

# columnas que necesitamos para el sistema de estrellas (algunas no estan en trans:
# Opp_2P% si esta; Opp_AST% / Opp_3PAr no las usa el sistema de estrellas base)
NEEDED = ['Pace', 'OER', 'DER', 'TRB%', 'ORB%', 'DRB%', 'TOV%', 'AST/TOV', 'AST%',
          'eFG%', 'TS%', 'FG%', '3P%', '3PAr', 'FTr', 'STL%', 'BLK%', 'Opp_2P%']

df = pd.concat([acb_cont[NEEDED], trans[NEEDED]])
print(f"Liga combinada (16 ACB continuistas + 2 FEB traducidos): {len(df)} equipos")

def z(col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def stars(zseries):
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    s = pd.cut(zseries, bins=bins, labels=labels).astype(float)
    s[zseries <= -2.5] = 0
    return s.astype(int)

def stars_neutral(col):
    x = df[col]
    zc = (x - x.mean()) / x.std(ddof=0)
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    return pd.cut(zc, bins=bins, labels=labels).astype(float).astype(int)

out = pd.DataFrame(index=df.index)
out['Ritmo_poss'] = df['Pace']
out['Ritmo_perfil'] = stars_neutral('Pace')
out['Ataque_OER'] = df['OER']
out['Ataque_estrellas'] = stars(z('OER'))
out['Defensa_DER'] = df['DER']
out['Defensa_estrellas'] = stars(z('DER', invert=True))
out['Rebote_TRB%'] = df['TRB%']
out['Rebote_estrellas'] = stars(z('TRB%'))
out['Rebote_ORB%'] = df['ORB%']
out['Rebote_ORB_estrellas'] = stars(z('ORB%'))
out['Rebote_DRB%'] = df['DRB%']
out['Rebote_DRB_estrellas'] = stars(z('DRB%'))
out['Control_TOV%'] = df['TOV%']
out['Control_TOV_estrellas'] = stars(z('TOV%', invert=True))
out['Control_ASTTOV'] = df['AST/TOV']
out['Control_ASTTOV_estrellas'] = stars(z('AST/TOV'))
z_control = (z('TOV%', invert=True) + z('AST/TOV')) / 2
out['Control_estrellas_global'] = stars(z_control)
z_gen = (z('OER') + z('AST%') + z('AST/TOV')) / 3
out['Generacion_estrellas'] = stars(z_gen)
out['Eficiencia_eFG%'] = df['eFG%']
out['Eficiencia_TS%'] = df['TS%']
out['Eficiencia_FG%'] = df['FG%']
z_efi = (z('eFG%') + z('TS%') + z('FG%')) / 3
out['Eficiencia_estrellas'] = stars(z_efi)
out['Exterior_3P%'] = df['3P%']
out['Exterior_3PAr'] = df['3PAr']
z_ext = (z('3P%') + z('3PAr')) / 2
out['Exterior_estrellas'] = stars(z_ext)
out['Faltas_FTr'] = df['FTr']
out['Faltas_estrellas'] = stars(z('FTr'))
out['DefBalon_STL%'] = df['STL%']
z_defbalon = (z('DER', invert=True) + z('STL%')) / 2
out['DefBalon_estrellas'] = stars(z_defbalon)
out['Aro_BLK%'] = df['BLK%']
out['Aro_Opp2P%'] = df['Opp_2P%']
z_aro = (z('BLK%') + z('Opp_2P%', invert=True)) / 2
out['Aro_estrellas'] = stars(z_aro)

# Total de estrellas: ahora SI incluye Ritmo (ponderado como una categoria mas, a
# peticion del usuario). Ritmo_perfil usa stars_neutral (percentil de la liga combinada,
# sin direccion "buena/mala" impuesta) en vez de stars() con target de calidad.
STAR_COLS = ['Ritmo_perfil', 'Ataque_estrellas', 'Defensa_estrellas', 'Rebote_estrellas',
             'Control_estrellas_global', 'Generacion_estrellas', 'Eficiencia_estrellas',
             'Exterior_estrellas', 'Faltas_estrellas', 'DefBalon_estrellas', 'Aro_estrellas']
out['Total_estrellas'] = out[STAR_COLS].sum(axis=1)

out = out.round(2)
print(out.loc[['Leyma Coruña', 'Monbus Obradoiro']].T.to_string())
out.to_csv('feb_new_teams_stars.csv')

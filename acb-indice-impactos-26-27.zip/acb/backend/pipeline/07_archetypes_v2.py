import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 100)

season = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
df = season.join(track, how='left')
df['PF_per100'] = df['PF'] / df['POSS'] * 100

top3share = pd.read_csv('scoring_top3share.csv', index_col=0)['share']
df['Top3_share'] = top3share

def zg(col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def tertile(col, invert=False):
    """Return 'Alto'/'Medio'/'Bajo' by rank-based tertile (6/6/6 of 18 teams).
    'Alto' = highest raw values by default; invert=True flips so 'Alto' = lowest raw values."""
    r = df[col].rank(ascending=invert)  # ascending=False (rank 1 = largest) puts the top values in bin 'Alto'
    n = len(df)
    tier = pd.cut(r, bins=[0, n/3, 2*n/3, n], labels=['Alto', 'Medio', 'Bajo'])
    return tier

df['Pace_tier'] = tertile('Pace')
df['3PAr_tier'] = tertile('3PAr')

print("Pace tiers:\n", df[['Pace','Pace_tier']].sort_values('Pace', ascending=False))
print("\n3PAr tiers:\n", df[['3PAr','3PAr_tier']].sort_values('3PAr', ascending=False))

# =========================================================================
# OFFENSE: hierarchical rules first, nearest-fit (RMS z-distance) as tiebreak
# =========================================================================
REMAINING_ARCHETYPES = {
    'Juego Coral (Pase y Corte)': {'AST%': False, 'AST/TOV': False},
    'Juego Interior y Físico': {'ORB%': False, 'FTr': False, 'ptsPIN_per100pos': False, 'ptsRO_per100pos': False},
    'Talento Individual (1c1)': {'Top3_share': False, 'AST%': True},
}
TARGET = 1.4

def best_fit(row_idx, candidates):
    dists = {}
    for arch, metrics in candidates.items():
        vals = []
        for m, inv in metrics.items():
            zval = zg(m, invert=inv)[row_idx]
            vals.append((zval - TARGET) ** 2)
        dists[arch] = np.sqrt(np.mean(vals))
    best = min(dists, key=dists.get)
    return best, dists

ataque = {}
ataque_detail = {}
for team in df.index:
    pace_tier = df.loc[team, 'Pace_tier']
    p3ar_tier = df.loc[team, '3PAr_tier']
    if pace_tier == 'Alto' and p3ar_tier == 'Alto':
        ataque[team] = 'Ritmo y Espacio'
        ataque_detail[team] = 'Regla 1: ritmo alto + 3PAr alto'
    elif pace_tier == 'Bajo':
        ataque[team] = 'Baloncesto de Control'
        ataque_detail[team] = 'Regla 2: ritmo bajo'
    else:
        # medium pace -> all 3 remaining candidates; high pace w/o high 3PAr -> exclude Coral (needs ritmo medio)
        candidates = dict(REMAINING_ARCHETYPES)
        if pace_tier == 'Alto':
            candidates = {k: v for k, v in candidates.items() if k != 'Juego Coral (Pase y Corte)'}
        best, dists = best_fit(team, candidates)
        ataque[team] = best
        ataque_detail[team] = f"Regla 3 (nearest-fit entre {list(candidates.keys())}): {dists}"

for team in df.index:
    print(team, '->', ataque[team], '|', ataque_detail[team])

result = pd.DataFrame({'Ataque_arquetipo_v2': pd.Series(ataque)})
result['Pace_tier'] = df['Pace_tier']
result['3PAr_tier'] = df['3PAr_tier']
result['Top3_share'] = df['Top3_share'].round(3)
result['AST%'] = df['AST%'].round(2)
print()
print(result.sort_index())
print()
print(result['Ataque_arquetipo_v2'].value_counts())

result.to_csv('team_archetypes_offense_v2.csv')

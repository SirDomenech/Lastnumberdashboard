import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np
from scipy import stats

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 60)
pd.set_option('display.max_rows', 400)

df = pd.read_csv('roster_matched.csv')

# ---------------- manual position overrides (criterio real de baloncesto, indicado por el usuario) ----------------
POS_OVERRIDES = {
    'Jan Vesely': 'C',
    'Martin Krampelj': 'C',
    'William Howard': 'PF',
    'Ruben Guerrero': 'C',
    'Kelan Martin': 'F',
    'Devontae Cacok': 'C',
    'Tyler Kalinoski': 'SG',
    'Xabier Lopez-Arostegui': 'SF',
    'Isaac Nogues': 'SG',
}
for player, new_pos in POS_OVERRIDES.items():
    mask = df['Player'] == player
    assert mask.sum() == 1, f"expected exactly 1 match for {player!r}, got {mask.sum()}"
    df.loc[mask, 'Pos'] = new_pos

# ---------------- position group mapping ----------------
POS_MAP = {
    'G': 'Guard', 'PG': 'Guard', 'SG': 'Guard',
    'F': 'Forward', 'SF': 'Forward', 'PF': 'Forward', 'GF': 'Forward',
    'C': 'Center', 'FC': 'Center',
    '-': None,
}
df['pos_group'] = df['Pos'].map(POS_MAP)

# ---------------- height HT "F-I" -> meters ----------------
def ht_to_m(v):
    if pd.isna(v) or v == '-':
        return np.nan
    try:
        ft, inch = v.split('-')
        return (int(ft) * 12 + int(inch)) * 0.0254
    except Exception:
        return np.nan
df['height_m'] = df['HT'].map(ht_to_m)

has_stats = df['nickname'].notna()
qualified = has_stats & (df['bajo_volumen'] == False)

METRICS = ['USG%', 'AST%', 'TS%', 'PPG', 'TOV%', 'AST/TOV', '3PAr', 'FTr']

# ---------------- percentiles within position group, scale = qualified players ----------------
for m in METRICS:
    pct_col = f'pct_{m}'
    df[pct_col] = np.nan
    for grp in ['Guard', 'Forward', 'Center']:
        ref_mask = qualified & (df['pos_group'] == grp)
        ref_vals = df.loc[ref_mask, m].dropna().values
        if len(ref_vals) < 5:
            continue
        apply_mask = has_stats & (df['pos_group'] == grp) & df[m].notna()
        df.loc[apply_mask, pct_col] = df.loc[apply_mask, m].apply(
            lambda x: stats.percentileofscore(ref_vals, x, kind='mean')
        )

def p(row, m):
    return row.get(f'pct_{m}', np.nan)

AST_ABS_MIN = 18  # Post Player passer absolute floor

def classify(row):
    if pd.isna(row['pos_group']):
        return 'Sin clasificar (posición desconocida)'
    if pd.isna(row['nickname']):
        return 'Sin datos (sin referencia en boxscore)'

    g = row['pos_group']
    ast_pct = p(row, 'AST%'); usg_pct = p(row, 'USG%'); ts_pct = p(row, 'TS%')
    threepar_pct = p(row, '3PAr'); ftr_pct = p(row, 'FTr')
    ppg = row['PPG']

    if any(pd.isna(v) for v in [ast_pct, usg_pct, ts_pct, threepar_pct, ftr_pct]) or pd.isna(ppg):
        return 'Sin datos (métricas incompletas)'

    elite_scorer = (ppg > 15.5 and ast_pct < 80) or \
                   (usg_pct >= 70 and ts_pct >= 65) or (usg_pct >= 80 and ppg >= 14)

    if g == 'Guard':
        if ast_pct >= 80 and usg_pct >= 55:
            return 'Primary Ball Handler'
        if ast_pct >= 80 and usg_pct < 55:
            return 'Floor General'
        if ppg > 15.5 and ast_pct < 80:
            return 'Elite Scorer'
        if 40 <= ast_pct <= 80 and 45 <= usg_pct <= 90:
            return 'Secondary Ball Handler'
        if elite_scorer:
            return 'Elite Scorer'
        if threepar_pct >= 75 and usg_pct < 55:
            return 'Spot-Up Shooter'
        if usg_pct >= 50:
            return 'Scorer'
        return 'Spot-Up Shooter'

    if g == 'Forward':
        tall = row['height_m'] > 2.00 if not pd.isna(row['height_m']) else False
        if tall and ppg >= 9 and usg_pct >= 35:
            return 'Three-Level Wing Scorer'
        if elite_scorer:
            return 'Elite Scorer'
        if ftr_pct >= 70 and threepar_pct <= 45:
            return 'Slasher'
        if threepar_pct >= 75:
            return 'Spot-Up Shooter'
        if usg_pct >= 50:
            return 'Three-Level Wing Scorer' if (tall and ppg >= 9) else 'Scorer'
        return 'Spot-Up Shooter'

    if g == 'Center':
        ast_abs = row['AST%']
        if ast_pct >= 75 and ast_abs >= AST_ABS_MIN:
            return 'Post Player'
        if row['USG%'] >= 16 and ppg >= 5:
            return 'Post Player'
        if threepar_pct >= 70:
            return 'Stretch Big'
        return 'Roller'

    return 'Sin clasificar'

df['role_raw'] = df.apply(classify, axis=1)

# ---------------- post-processing ----------------
PRESTIGE_DOWNGRADE = {
    'Elite Scorer': 'Scorer',
    'Three-Level Wing Scorer': 'Scorer',
    'Primary Ball Handler': 'Secondary Ball Handler',
    'Floor General': 'Secondary Ball Handler',
    'Post Player': 'Roller',
}

df['role'] = df['role_raw']

# 1. degradar bajo volumen
mask_bv = (df['bajo_volumen'] == True) & df['role_raw'].isin(PRESTIGE_DOWNGRADE.keys())
df.loc[mask_bv, 'role'] = df.loc[mask_bv, 'role_raw'].map(PRESTIGE_DOWNGRADE)

# 2. ningun equipo sin Primary -> Secondary de ese equipo ascienden a Primary
for team, sub in df.groupby('Team'):
    if 'Primary Ball Handler' not in sub['role'].values:
        idx = sub[sub['role'] == 'Secondary Ball Handler'].index
        df.loc[idx, 'role'] = 'Primary Ball Handler'

# 3. filtro de relevancia: Primary debe ser top-5 de su equipo en MPG o en PTS totales
for team, sub in df.groupby('Team'):
    top5_mpg = set(sub.nlargest(5, 'MPG', keep='all')['Player']) if sub['MPG'].notna().any() else set()
    top5_pts = set(sub.nlargest(5, 'PTS', keep='all')['Player']) if sub['PTS'].notna().any() else set()
    relevant = top5_mpg | top5_pts
    idx = sub[(sub['role'] == 'Primary Ball Handler') & (~sub['Player'].isin(relevant))].index
    df.loc[idx, 'role'] = 'Secondary Ball Handler'

# nomenclatura: Rim Roller -> Roller ya usamos "Roller" directamente

out_cols = ['Player', 'Pos', 'pos_group', 'HT', 'height_m', 'Team', 'nickname', 'team_last',
            'match_method', 'team_match', 'bajo_volumen', 'games', 'MPG', 'PPG', 'APG',
            'USG%', 'AST%', 'TS%', 'TOV%', 'AST/TOV', '3PAr', 'FTr', 'BoxCreation', 'DOI%', 'role_raw', 'role']
final = df[out_cols].copy()
final.to_csv('player_archetypes.csv', index=False)

print("=== Distribución de roles (todos) ===")
print(final['role'].value_counts())
print("\n=== Distribución por grupo de posición ===")
print(final.groupby('pos_group')['role'].value_counts())

print("\n=== Cambios por post-proceso (role_raw != role) ===")
changed = final[final['role_raw'] != final['role']][['Player', 'Team', 'pos_group', 'role_raw', 'role']]
print(changed.to_string(index=False))

print("\n=== Muestra de verificación (jugadores conocidos) ===")
sample_names = ['Llull', 'Campazzo', 'Kuric', 'Tavares', 'Abrines', 'Sastre', 'Sergio Rodriguez', 'Deck']
for n in sample_names:
    sub = final[final['Player'].str.contains(n, case=False, na=False)]
    if len(sub):
        print(sub[['Player', 'Team', 'pos_group', 'PPG', 'USG%', 'AST%', 'role']].to_string(index=False))

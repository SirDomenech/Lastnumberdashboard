import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 100)

COEF = 0.30  # peso Primera FEB vs ACB, definido por el usuario (ajustado de 0.80 a 0.30)
PEN = 1.20   # penalizacion estructural por venir de categoria inferior (en unidades z),
             # recalibrada (de 1.00 a 1.20) tras introducir el rating ponderado con pesos por
             # categoria + Net Rating/Clasificacion: con PEN=1.00 Obradoiro quedaba en zona
             # media (puesto 10 de 18); a 1.20 ambos ascendidos vuelven a caer en zona baja
             # (puestos 17-18 de 18)
NEW_TEAMS = ['LEYMA CORUÑA', 'MONBUS OBRADOIRO']
OUT_TEAMS = ['Coviran Granada', 'Dreamland Gran Canaria']  # no juegan ACB 26/27

# ---------------- ACB: equipos que continuan (16) ----------------
acb = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
acb_full = acb.join(track, how='left')
acb_full['PF_per100'] = acb_full['PF'] / acb_full['POSS'] * 100
acb_full['Top3_share'] = pd.read_csv('scoring_top3share.csv', index_col=0)['share']
acb_cont = acb_full.drop(index=[t for t in OUT_TEAMS if t in acb_full.index])
print(f"ACB equipos que continuan: {len(acb_cont)}")

# ---------------- FEB: los 17 equipos, referencia de estandarizacion ----------------
feb = pd.read_csv('feb_season_metrics.csv', index_col='team')
feb['PF_per100'] = feb['PF'] / feb['POSS'] * 100

# metricas de "calidad" que SI se traducen por el coeficiente de liga
QUALITY_METRICS = ['OER', 'DER', 'TRB%', 'ORB%', 'DRB%', 'TOV%', 'AST/TOV', 'AST%',
                    'eFG%', 'TS%', 'FG%', '3P%', '3PAr', 'FTr', 'STL%', 'BLK%',
                    'Opp_2P%', 'Opp_TOV%', 'Opp_FTr', 'PF_per100', 'Top3_share']
# Ritmo (Pace) queda fuera de la traduccion por coeficiente/penalizacion: es descriptivo
# (no evaluativo), no se corrige por nivel de liga. SI se pondera en el total de estrellas
# (ver 20_feb_stars.py: Ritmo_perfil se incluye ahora en Total_estrellas, a peticion del usuario)

# Direccion de "lo bueno" para cada metrica de calidad: +1 = mas alto es mejor,
# -1 = mas bajo es mejor, 0 = neutro/descriptivo (no se penaliza, ej. estilo de juego)
DIRECTION = {
    'OER': 1, 'DER': -1, 'TRB%': 1, 'ORB%': 1, 'DRB%': 1, 'TOV%': -1, 'AST/TOV': 1,
    'AST%': 1, 'eFG%': 1, 'TS%': 1, 'FG%': 1, '3P%': 1, '3PAr': 1, 'FTr': 1,
    'STL%': 1, 'BLK%': 1, 'Opp_2P%': -1, 'Opp_TOV%': 1, 'Opp_FTr': -1,
    'PF_per100': 0, 'Top3_share': 0,
}

feb_mean = feb[QUALITY_METRICS].mean()
feb_std = feb[QUALITY_METRICS].std(ddof=0)
acb_mean = acb_cont[QUALITY_METRICS].mean()
acb_std = acb_cont[QUALITY_METRICS].std(ddof=0)

translated = {}
for team in NEW_TEAMS:
    row = {}
    z_feb = (feb.loc[team, QUALITY_METRICS] - feb_mean) / feb_std
    # 1) se traduce el nivel relativo dentro de FEB por el coeficiente de liga (0.30)
    # 2) se resta ademas una penalizacion estructural fija por venir de una categoria
    #    inferior: incluso el mejor equipo de FEB parte con una desventaja de nivel que
    #    no depende de cuanto domino su propia liga
    z_transladado = z_feb * COEF - PEN * pd.Series(DIRECTION)
    raw_acb_equiv = acb_mean + z_transladado * acb_std
    for m in QUALITY_METRICS:
        row[m] = raw_acb_equiv[m]
    # Pace: sin traducir, valor FEB real tal cual
    row['Pace'] = feb.loc[team, 'Pace']
    translated[team] = row

trans_df = pd.DataFrame(translated).T
print("\nMetricas traducidas a equivalente ACB:")
print(trans_df.round(2).to_string())
trans_df.to_csv('feb_translated_to_acb.csv')

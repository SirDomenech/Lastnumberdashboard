import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 60)

ps = pd.read_csv('player_season.csv')

TPO = ps['Team_Poss_onfloor']

AST_100 = ps['AST'] / TPO * 100
PTS_100 = ps['PTS'] / TPO * 100
TOV_100 = ps['TOV'] / TPO * 100
FGA_100 = ps['FGA'] / TPO * 100
FTA_100 = ps['FTA'] / TPO * 100
P3A_100 = ps['P3A'] / TPO * 100
P3pct = ps['3P%'] / 100  # our '3P%' column is 0-100; formula needs 0-1

prof3 = (2 / (1 + np.exp(-P3A_100)) - 1) * P3pct.fillna(0)

box_creation = (
    AST_100 * 0.1843
    + (PTS_100 + TOV_100) * 0.0969
    - 2.3021 * prof3
    + 0.0582 * (AST_100 * (PTS_100 + TOV_100) * prof3)
    - 1.1942
)
# Box Creation isn't meaningful as negative (no creation); clip at 0
box_creation = box_creation.clip(lower=0)

offensive_load = (AST_100 - 0.38 * box_creation) * 0.75 + FGA_100 + 0.44 * FTA_100 + box_creation + TOV_100

ps['BoxCreation'] = box_creation
ps['DOI%_simple'] = ps['DOI%']  # keep the old simplified version for comparison
ps['DOI%'] = offensive_load

ps.to_csv('player_season.csv', index=False)

print("Box Creation describe:")
print(ps['BoxCreation'].describe())
print()
print("DOI% (Offensive Load) vs DOI%_simple, top 15 cualificados:")
q = ps[~ps['bajo_volumen']].sort_values('DOI%', ascending=False).head(15)
print(q[['nickname', 'team_last', 'PPG', 'APG', 'USG%', 'AST%', 'BoxCreation', 'DOI%_simple', 'DOI%']].round(1).to_string(index=False))
print()
print("Comparación para conocidos:")
for n in ['Llull', 'Campazzo', 'Tavares', 'Kuric', 'Deck']:
    sub = ps[ps['nickname'].str.contains(n, case=False, na=False)]
    print(sub[['nickname', 'team_last', 'USG%', 'AST%', 'BoxCreation', 'DOI%_simple', 'DOI%']].round(1).to_string(index=False))

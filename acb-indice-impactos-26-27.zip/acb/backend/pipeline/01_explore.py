import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd

pd.set_option('display.width', 200)
pd.set_option('display.max_columns', 100)

BOX = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77c1dac6-Box_Scores_ACB.csv"
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"

df = pd.read_csv(BOX)
print("shape:", df.shape)
print("Competicion values:", df['Competicion'].unique())
print("Fase competición values:", df['Fase competición'].unique())
print("Jornada range:", df['Jornada'].min(), df['Jornada'].max())
print("n unique ID Partido:", df['ID Partido'].nunique())
print("n unique teams (Nombre equipo):", df['Nombre equipo'].nunique())
print(sorted(df['Nombre equipo'].unique()))

# filter to Liga Endesa regular season only? check Fase competición values
print(df.groupby('Fase competición')['ID Partido'].nunique())

df_le = df[df['Competicion'] == 'Liga Endesa']
print("Liga Endesa rows:", df_le.shape)
print("Liga Endesa unique games:", df_le['ID Partido'].nunique())
print("Liga Endesa unique teams:", df_le['Nombre equipo'].nunique())
print(sorted(df_le['Nombre equipo'].unique()))

games_per_team = df_le.groupby('Nombre equipo')['ID Partido'].nunique().sort_values()
print(games_per_team)

track = pd.read_csv(TRACK)
print(track)
print(track.columns.tolist())

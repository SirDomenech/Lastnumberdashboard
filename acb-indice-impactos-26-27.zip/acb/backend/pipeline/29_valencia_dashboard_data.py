# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Prepara los datos consolidados para el artefacto "Radar de Roster -- Valencia
Basket 26/27" (3 pestañas: ranking de jugadores, ranking de equipos, matriz
de arquetipos). Reutiliza y corrige la metodologia v4:

  - BUG FIX: role_from_row() en v4 no pasaba la altura real del jugador para
    los traspasos ACB->ACB, así que el check "tall" de Alero nunca se activaba
    (Valtonen, 2.01m, salia como "Spot-Up Shooter" en vez de "Three-Level Wing
    Scorer"). Aqui se reutiliza directamente el campo 'role' ya validado de
    player_archetypes.csv / mercado_2026_27.csv (que SI usa la altura real via
    12_classify.py), en lugar de recalcular.
  - Añade los 9 jugadores que SE QUEDAN en Valencia (no estaban en v4, que solo
    cubria altas y bajas) con su rating y rol, usando la misma metodologia.
  - Añade una capa de proyeccion de NIVEL DE EQUIPO: se descubre que el rating
    de jugador (percentil ponderado por USG%/AST%) NO correlaciona con el
    NetRtg real del equipo (R^2=0.00) -- es logico, el uso es un recurso
    limitado dentro de un equipo (suma cero), por lo que promediarlo no puede
    reflejar la calidad colectiva. En su lugar se usa GmSc_PJ sumado del
    roster (metrica aditiva, no de "porcentaje de posesiones"), que SI predice
    razonablemente el NetRtg real (R^2=0.68, n=18, p<0.0001) -- ese es el
    modelo que se usa para proyectar el rating de equipo esperado.
"""
import pandas as pd
import numpy as np
from scipy import stats as sps
import json
import re
import unicodedata

def norm(s):
    if pd.isna(s):
        return ''
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode('ascii')
    return ' '.join(s.lower().strip().split())

# ============================================================================
# -1b) Arquetipos corregidos a mano por Miguel (fichero devuelto 03/10/2026,
#      223/224 jugadores del roster 26/27) + columna nueva "Etiqueta
#      especial". Se usan en 2 sitios mas abajo: (a) sustituyen el
#      role/role_es calculado por el modelo donde Miguel dio una etiqueta
#      valida, (b) las etiquetas especiales alimentan ajustes de rating
#      explicitos (ver bloque "ETIQUETAS ESPECIALES" junto a
#      RATING_FLOOR_OVERRIDE). ES_TO_ROLE traduce su texto en español a la
#      clave interna en ingles (la misma que ya usa get_validated_role/
#      classify) -- 'Jugador versatil' es la UNICA categoria nueva que
#      Miguel introduce, sin equivalente previo; se añade como rol interno
#      'Versatile' (ver ROLE_ES mas abajo, donde ya existen las otras 11).
# ============================================================================
# Reorg 28/09/2026 (paquete GitHub): antes apuntaba a la ruta absoluta del
# fichero tal y como lo subio Miguel a esta conversacion; se copio a
# backend/data/raw_uploads/ para que el repo sea autocontenido y el pipeline
# se pueda ejecutar en cualquier maquina/clon, no solo en este contenedor.
_ARQ_MIGUEL_CSV = 'raw_uploads/Arquetipos_26-27_revision_Miguel.csv'
_arq_df = pd.read_csv(_ARQ_MIGUEL_CSV)

ES_TO_ROLE = {
    'Floor General': 'Floor General', 'Manejador principal': 'Primary Ball Handler',
    'Manejador secundario': 'Secondary Ball Handler', 'Manejador secunadrio': 'Secondary Ball Handler',
    'Jugador de poste': 'Post Player', 'Finalizador': 'Roller',
    'Alero anotador completo': 'Three-Level Wing Scorer', 'Lanzador exterior': 'Spot-Up Shooter',
    'Anotador': 'Scorer', 'Anotador de élite': 'Elite Scorer', 'Interior abierto': 'Stretch Big',
    'Penetrador': 'Slasher', 'Jugador versátil': 'Versatile',
}
ARQUETIPO_MIGUEL_BY_KEY = {}   # (equipo, norm(jugador)) -> rol interno (ingles)
ETIQUETAS_BY_KEY = {}          # (equipo, norm(jugador)) -> ['Líder', 'Jugador referencia', ...]
ARQ_MIGUEL_AMBIGUOS = []       # etiquetas de arquetipo que no se pudieron mapear (typos/incompletas) -- no se aplican
for _, _row in _arq_df.iterrows():
    _key = (_row['Equipo'], norm(_row['Jugador']))
    _arq_txt = _row['Arquetipo (Miguel)']
    if pd.notna(_arq_txt):
        if _arq_txt in ES_TO_ROLE:
            ARQUETIPO_MIGUEL_BY_KEY[_key] = ES_TO_ROLE[_arq_txt]
        else:
            ARQ_MIGUEL_AMBIGUOS.append((_row['Jugador'], _row['Equipo'], _arq_txt))
    if pd.notna(_row.get('Etiqueta especial')):
        ETIQUETAS_BY_KEY[_key] = [t.strip() for t in _row['Etiqueta especial'].split(' - ') if t.strip()]

# Correcciones puntuales de Miguel via chat (24/09/2026), NO vienen en el
# csv de arquetipos -- se anaden a mano aqui, mismo formato/clave que las
# del csv, para que pasen por el mismo bloque "ETIQUETAS ESPECIALES" (rol,
# visibilidad, efecto en rating) sin duplicar logica.
ETIQUETAS_BY_KEY[('UCAM Murcia', norm('Moussa Diagne'))] = ['Lesionado de larga duración']

# ============================================================================
# -1) Lista de jugadores confirmada por Miguel (poda manual del roster) --
#     revisó el Excel de auditoría de 348 jugadores (los 18 equipos) y
#     devolvió 224 filas ("Te los devuelvo. Los que no estén, elimínalos.").
#     Cualquier (jugador, equipo) que construya el modelo y NO esté en esta
#     lista se elimina del roster final -- ver filtro en build_team().
#     Nota: 2 de las 224 filas llevan el equipo YA CORREGIDO por Miguel
#     respecto al que tenia el modelo (Rafael Villar: Kosner Baskonia ->
#     Kids&Us Manresa; Yannick Nzosa: Recoletas Salud San Pablo Burgos ->
#     Unicaja) -- ver MANUAL_TEAM_MOVE mas abajo, que mueve a esos 2
#     jugadores de equipo ANTES de que se aplique esta poda, para que casen.
# ============================================================================
# (ver nota de reorg junto a _ARQ_MIGUEL_CSV mas arriba)
_keep_df = pd.read_csv('raw_uploads/Jugadores_dashboard_26-27_auditoria.csv')
MANUAL_ROSTER_KEEP = set(zip(_keep_df['Jugador'].map(norm), _keep_df['Equipo']))
print(f"[poda manual] Miguel confirmo {len(MANUAL_ROSTER_KEEP)} (jugador, equipo) a mantener en el dashboard")

# ============================================================================
# 0) Referencias de equipo: NetRtg real (curva 16 reales, para ajuste por
#    equipo de origen) y NetRtg real de TODOS los equipos (season_metrics)
# ============================================================================
with open('dashboard_v2_content.html', encoding='utf-8') as f:
    _html = f.read()
_m = re.search(r'const TEAMS = (\{.*?\});\n(?=const LOGOS)', _html, re.S)
_teams_dash = json.loads(_m.group(1))
_m_logos = re.search(r'const LOGOS = (\{.*?\});', _html, re.S)
ALL_LOGOS = json.loads(_m_logos.group(1))

# ----------------------------------------------------------------------------
# Alias de nombre de equipo: la temporada 26/27 se referencia con el nombre de
# PATROCINADOR actual (Asisa Joventut, Kosner Baskonia, FIATC Girona, Ilerna
# Lleida, Kids&Us Manresa, Surne Bilbao...) -- así vienen 'New Team' en el CSV
# de fichajes de Miguel, el Excel de posiciones/altura, y el scraping de
# acb.com. Pero TODA la infraestructura de referencia real de equipo (NetRtg,
# GP, PTS, season_metrics.csv, dashboard_v2_content.html, y las claves de
# fichajes_impact.json) se construyo con el nombre de temporada 25/26 (sin
# patrocinador, o con el patrocinador de entonces: Joventut Badalona,
# Baskonia, Bàsquet Girona, Hiopos Lleida, BAXI Manresa, Surne Bilbao Basket).
# canon_team() resuelve CUALQUIER variante (incluida la que trae el propio
# fichajes_impact.json en el campo libre 'procedencia_destino', que en algun
# caso usa aun otra grafia -- 'ASISA Joventut' en mayusculas) al nombre
# canonico 25/26, que es el que hay que usar para indexar TEAM_NETRTG/sm/
# fichajes. Para mk['New Team'] y para lo que se muestra en el dashboard se
# sigue usando el nombre de patrocinador actual (team_name tal cual llega).
# ----------------------------------------------------------------------------
CANON_TEAM_NAME_RAW = {
    'Asisa Joventut': 'Joventut Badalona', 'ASISA Joventut': 'Joventut Badalona',
    'Kosner Baskonia': 'Baskonia',
    'FIATC Girona': 'Bàsquet Girona', 'Basquet Girona': 'Bàsquet Girona',
    'Ilerna Lleida': 'Hiopos Lleida',
    'Kids&Us Manresa': 'BAXI Manresa',
    'Surne Bilbao': 'Surne Bilbao Basket',
    'Rio Breogan': 'Río Breogán',
}
CANON_TEAM_NAME = {norm(k): v for k, v in CANON_TEAM_NAME_RAW.items()}

def canon_team(team_name):
    """Nombre canonico 25/26 (el que usan TEAM_NETRTG/sm/fichajes_impact.json)
    para cualquier grafia de team_name que aparezca en el pipeline. Si no hay
    alias registrado, devuelve el nombre tal cual (recortado de espacios) --
    cubre los equipos cuyo nombre no cambio (Valencia Basket, Real Madrid,
    Barça, Casademont Zaragoza, La Laguna Tenerife, MoraBanc Andorra,
    Recoletas Salud San Pablo Burgos, Río Breogán, UCAM Murcia, Unicaja,
    Leyma Coruña, Monbus Obradoiro)."""
    if not team_name:
        return team_name
    t = str(team_name).strip()
    return CANON_TEAM_NAME.get(norm(t), t)

# Alias de nombre de equipo -> clave real en ALL_LOGOS.
LOGO_ALIASES = CANON_TEAM_NAME_RAW

def logo_key_for(team_name):
    """Clave canonica en ALL_LOGOS para team_name, o None si no tenemos
    escudo (equipos fuera de la ACB -- Euroliga, NBA, NCAA, G League...)."""
    if not team_name:
        return None
    key = canon_team(team_name)
    return key if key in ALL_LOGOS else None
_real = {k: v for k, v in _teams_dash.items() if not v['estimado_feb']}
_net_vals = [t['netrtg'] for t in _real.values()]
NET_MEAN, NET_STD = np.mean(_net_vals), np.std(_net_vals)

sm = pd.read_csv('season_metrics.csv')
TEAM_NETRTG = dict(zip(sm['Nombre equipo'], sm['NetRtg']))
TEAM_PTS = dict(zip(sm['Nombre equipo'], sm['PTS']))
TEAM_OPP_PTS = dict(zip(sm['Nombre equipo'], sm['Opp_PTS']))
TEAM_POSS = dict(zip(sm['Nombre equipo'], sm['POSS']))
TEAM_GP = dict(zip(sm['Nombre equipo'], sm['GP']))

K_TEAM_CONTEXT = 8.0

def team_context_adj(team_name):
    team_name = canon_team(team_name)
    if team_name not in TEAM_NETRTG:
        return 0.0, None
    z = (TEAM_NETRTG[team_name] - NET_MEAN) / NET_STD
    return round(K_TEAM_CONTEXT * z, 1), round(z, 2)

# ---------------------------------------------------------------------------
# Ajuste por SALTO de contexto (origen -> destino), feedback de Miguel:
#   - "cuanto mayor el salto, mayor la cautela" cuando el jugador SUBE de
#     nivel de equipo (destino mejor que origen): se descuenta, y mas cuanto
#     mayor sea el salto -- no es lo mismo Corbalan (10o->1o) que un jugador
#     que sube un solo escalon.
#   - Cuando el jugador BAJA de nivel de equipo, es al reves: esperamos MAS
#     rol/impacto (menos competencia por minutos), así que el mismo mecanismo
#     lineal produce un ajuste positivo -- una sola formula sirve para los dos
#     sentidos: adj = -K_CAUTELA * (z_destino - z_origen).
#   - EXCEPCION explícita de Miguel: si la muestra del jugador en origen es
#     muy baja (bajo_volumen -- p.ej. Isaac Nogues, 22 partidos a 6.9 MPG), no
#     hay base para proyectar "mas rol" con confianza -- se cae al mecanismo
#     antiguo, solo-origen, igual que cuando no se conoce el destino.
#   - Solo se puede calcular cuando origen Y destino son equipos con NetRtg
#     real (TEAM_NETRTG, season_metrics.csv -- excluye ligas fuera de ACB y
#     los 2 equipos recien ascendidos sin historial real). En cualquier otro
#     caso, cae al ajuste antiguo solo-origen (team_context_adj).
# ---------------------------------------------------------------------------
K_CAUTELA = 3.0  # puntos de rating por unidad de z de salto -- primer corte, ajustable

def team_gap_adj(origin_team, destination_team, low_sample=False):
    """Devuelve (adj, detalle_dict). adj en puntos de rating."""
    origin_norm = canon_team(origin_team)
    dest_norm = canon_team(destination_team)
    origin_ok = origin_norm in TEAM_NETRTG
    dest_ok = dest_norm is not None and dest_norm in TEAM_NETRTG
    if low_sample or not origin_ok or not dest_ok:
        adj, z_origin = team_context_adj(origin_team)
        return adj, {'metodo': 'solo-origen (fallback)', 'z_origen': z_origin, 'z_destino': None, 'gap': None}
    z_origin = (TEAM_NETRTG[origin_norm] - NET_MEAN) / NET_STD
    z_dest = (TEAM_NETRTG[dest_norm] - NET_MEAN) / NET_STD
    gap = z_dest - z_origin
    adj = round(-K_CAUTELA * gap, 1)
    return adj, {'metodo': 'salto origen->destino', 'z_origen': round(z_origin, 2), 'z_destino': round(z_dest, 2), 'gap': round(gap, 2)}

# ============================================================================
# 1) Referencia ACB para rating_from_metrics (igual que v3/v4)
# ============================================================================
ps = pd.read_csv('player_season.csv')
rm = pd.read_csv('roster_matched.csv')
POS_MAP = {'G':'Guard','PG':'Guard','SG':'Guard','F':'Forward','SF':'Forward','PF':'Forward',
           'GF':'Forward','C':'Center','FC':'Center','-':None}
rm['pos_group'] = rm['Pos'].map(POS_MAP)
pos_by_id = rm.dropna(subset=['id']).drop_duplicates('id').set_index('id')['pos_group']
ps['pos_group'] = ps['id'].map(pos_by_id)

tg = pd.read_csv('team_game_full.csv')
team_trb = tg.groupby('Nombre equipo', as_index=False).agg(Team_TRB_season=('TRB','sum'), Opp_TRB_season=('Opp_TRB','sum'))
ps = ps.merge(team_trb, left_on='team_last', right_on='Nombre equipo', how='left')
MP = ps['MP_sec']/60; T_MP = ps['T_MPsec']/60
ps['eFG%'] = 100*(ps['FGM'] + 0.5*ps['P3M']) / ps['FGA']
ps['TRB%'] = 100*ps['TRB']*(T_MP/5) / (MP*(ps['Team_TRB_season']+ps['Opp_TRB_season']))
ps['BPG'] = ps['BLK']/ps['games']
ps['SPG'] = ps['STL']/ps['games']
ps['RPG'] = ps['TRB']/ps['games']
ps['FG%'] = 100*ps['FGM']/ps['FGA']
g = ps['games'].replace(0, np.nan)
ps['gmsc_pj'] = (ps['PTS'] + 0.4*ps['FGM'] - 0.7*ps['FGA'] - 0.4*(ps['FTA']-ps['FTM']) + 0.7*ps['OREB'] + 0.3*ps['DREB']
                  + ps['STL'] + 0.7*ps['AST'] + 0.7*ps['BLK'] - 0.4*ps['PF'] - ps['TOV']) / g

ps['name_norm'] = ps['nickname'].map(norm)

# ---- Plus/minus real de boxscore (partido a partido, pedido por Miguel) ----
# Box_Scores_ACB_1.csv trae plusMinus por jugador-partido para toda la 25/26.
# Se valido que es un +/- real (no relleno): suma por equipo en un partido =
# 5 x diferencial final (cada uno de los 5 en pista arrastra el mismo swing).
# Se normaliza a "+/- por 40 minutos" para poder comparar jugadores con
# reparto de minutos muy distinto, y se filtran los DNP (0 minutos).
# (ver nota de reorg junto a _ARQ_MIGUEL_CSV mas arriba)
_bx = pd.read_csv('raw_uploads/Box_Scores_ACB.csv')
def _to_min(t):
    try:
        mm, ss = str(t).split(':')
        return int(mm) + int(ss)/60
    except Exception:
        return 0.0
_bx['min_dec'] = _bx['playTime'].map(_to_min)
_bx = _bx[_bx['min_dec'] > 0].copy()
_pm = _bx.groupby('nickname').agg(pm_games=('id', 'count'), pm_min=('min_dec', 'sum'), pm_sum=('plusMinus', 'sum')).reset_index()
_pm['PM40'] = _pm['pm_sum'] / _pm['pm_min'] * 40
_pm['name_norm'] = _pm['nickname'].map(norm)
ps = ps.merge(_pm[['name_norm', 'PM40', 'pm_games']], on='name_norm', how='left')
print(f"Plus/minus real: cobertura {ps['PM40'].notna().sum()}/{len(ps)} jugadores ACB (resto sin match en el boxscore, p.ej. canteranos con pocos minutos)")

# ---- Presencia real en el equipo y ultima jornada jugada (filtro de bajas, ----
#      pedido por Miguel: "si el jugador no aparece en el csv, no lo apuntes
#      como baja de un equipo u otro" / "si no jugo a partir de la J17,
#      eliminalo directamente"). Se detectaron 2 bajas fantasma en Valencia
#      (Joel Soriano, Millan Jimenez -- en realidad jugaron toda la temporada
#      en otro equipo, nunca en Valencia; llegaron a la lista por un cruce de
#      nombre mal hecho en una fase anterior del pipeline). Generalizado por
#      equipo (antes solo Valencia) para poder aplicar la misma validacion a
#      Real Madrid y a cualquier otro equipo que se añada despues.
_LAST_JORNADA_BY_TEAM = {}
# Baskonia y Surne Bilbao cambiaron de nombre de patrocinador a mitad de la
# 25/26 ('Baskonia' J1-7 / 'Kosner Baskonia' J8-34; 'Surne Bilbao Basket' J1-7
# / 'Surne Bilbao' J8-34), y el boxscore crudo usa la grafia vigente en cada
# jornada -- NO el nombre canonico unico que usan TEAM_NETRTG/season_metrics.
# Si aqui se filtra solo por canon_team(team_name) (p.ej. 'Baskonia'), el CSV
# solo tiene ESE nombre para 7 de las 34 jornadas, así que cualquier jugador
# que solo aparece con la otra grafia sale con "ultima jornada" adelantada o
# directamente ausente -- causaba que TODAS las bajas de Baskonia y Bilbao se
# descartaran como poco fiables. Se agrupa el boxscore por el mismo
# canon_team() aplicado a 'Nombre equipo', asi las dos grafias de un mismo
# equipo (temporada completa) caen bajo la misma clave.
_BX_TEAM_CANON = _bx['Nombre equipo'].map(canon_team)

def _last_jornada_map(team_name):
    team_key = canon_team(team_name)
    if team_key not in _LAST_JORNADA_BY_TEAM:
        _t_bx = _bx[_BX_TEAM_CANON == team_key].copy()
        _t_bx['name_norm'] = _t_bx['nickname'].map(norm)
        _LAST_JORNADA_BY_TEAM[team_key] = _t_bx.groupby('name_norm')['Jornada'].max().to_dict()
    return _LAST_JORNADA_BY_TEAM[team_key]

def baja_valida(name, team_name, min_jornada=17):
    """(ok, motivo). ok=False si no hay prueba en el boxscore de que jugara en
    team_name, o si su ultimo partido con minutos es anterior a min_jornada."""
    key = norm(name)
    last_j = _last_jornada_map(team_name).get(key)
    if last_j is None:
        return False, f'no aparece jugando por {team_name} en el boxscore real'
    if last_j < min_jornada:
        return False, f'ultimo partido con minutos en la J{int(last_j)} (antes de la J{min_jornada})'
    return True, None

qualified = ps[~ps['bajo_volumen']].copy()
ps_by_name = ps.set_index('name_norm')

def lookup_player(name):
    key = norm(name)
    if key not in ps_by_name.index:
        return None
    row = ps_by_name.loc[key]
    if isinstance(row, pd.DataFrame):
        row = row.sort_values('games', ascending=False).iloc[0]
    return row

CORE = ['USG%', 'AST%', 'PPG', 'APG']
# SPG (robos por partido) anadido para no penalizar a jugadores solidos y poco
# anotadores (ej. Sako) que aportan por vias distintas al anotador puro -- antes
# solo se contaban tapones (BPG) como aportacion defensiva de conteo.
SEC = {'eFG%': 1, 'TRB%': 1, 'BPG': 1, 'SPG': 1, 'FG%': 1, '3P%': 1, 'TOV%': -1}
REF_WHOLE = {m: qualified[m].dropna().values for m in CORE + ['MPG']}
REF_POS = {grp: {m: qualified[qualified['pos_group']==grp][m].dropna().values for m in SEC}
           for grp in ['Guard', 'Forward', 'Center']}
# Referencia para el +/- real por 40' (impacto en el resultado mientras esta en
# pista). Solo dentro de 'qualified' (no bajo_volumen), igual que el resto de
# referencias, para no dejar que muestras minusculas y ruidosas definan la
# curva. PRIMER CORTE de peso -- pendiente de calibrar con Miguel.
REF_POS_IMPACT = {grp: qualified[qualified['pos_group']==grp]['PM40'].dropna().values
                   for grp in ['Guard', 'Forward', 'Center']}

def pctl(ref, value, invert=False):
    if value is None or pd.isna(value) or len(ref) < 5:
        return np.nan
    p = sps.percentileofscore(ref, value, kind='mean')
    return 100 - p if invert else p

# ----------------------------------------------------------------------------
# Pesos v6 -- POR POSICION (pedido explicito de Miguel: "aplicar distintos
# sesgos" segun el rol, en vez de un unico blend generico para las 3
# posiciones):
#   - Base (Guard): se valora por anotar y crear. USG%/AST%/PPG/APG y minutos
#     son la vara de medir -- el bloque secundario (eficiencia/robos/TOV%)
#     pesa poco.
#   - Alero (Forward): anota Y equilibra en rebote/defensa/asistencia. Son
#     focos ofensivos SECUNDARIOS en la mayoria de los casos (salvo un
#     Hezonja o un Luwawu-Cabarrot, que ya destacan solos en el bloque de
#     uso) -- así que uso y bloque secundario (rebote+tapones+robos+
#     eficiencia) pesan casi lo mismo, en vez de que el uso domine.
#   - Pivot (Center): NADA de USG% -- los grandes no son focos ofensivos,
#     son complementos. Formula propia (no el blend generico de
#     core/minutos/secundario/impacto): eficiencia finalizando (eFG%
#     dentro de la posicion) + tapones + rebote + +/- real, SIN minutos
#     (en jugadores de bajo uso los minutos miden menos "importancia" real
#     que la produccion por posesion) y SIN AST%/PPG/USG% (eso es "core",
#     pensado para focos ofensivos).
# Primer corte, validado contra el caso de referencia que dio Miguel:
# Tavares -- 95.8 pctl en eficiencia, 98.6 en tapones, 90.3 en +/-, pero solo
# 37.5 en rebote -- tenia que quedar por encima de 90 con este desglose, y
# con estos pesos da ~92.
# ----------------------------------------------------------------------------
POS_WEIGHTS = {
    'Guard':   {'core': 0.55, 'mpg': 0.20, 'sec': 0.05, 'impact': 0.20},
    'Forward': {'core': 0.30, 'mpg': 0.15, 'sec': 0.30, 'impact': 0.25},
}
CENTER_WEIGHTS = {'eficiencia': 0.30, 'tapones': 0.30, 'rebote': 0.05, 'impacto': 0.35}

# La eficiencia finalizando (eFG%) de un pivot solo se cuenta cuando esta
# respaldada por minutos reales suficientes -- pedido explicito de Miguel:
# "no lo multiplicaria en Sima, Len, Garuba o Sarr, si en Tavares". Un puñado
# de tiros de alto acierto en pocos minutos no demuestra nada todavia (Sima
# 8.1 MPG, Len 12.2, Garuba 12.4 -- los tres por debajo del umbral). Sarr
# queda fuera aunque juegue mas minutos (23.5 MPG) porque su dato no viene de
# la curva real ACB (G League, acb_verified=False) -- el propio eFG% no es
# comparable a la referencia aunque el volumen de minutos sea alto. Tavares
# (20.7 MPG, dato ACB real) si la pasa. Por debajo del umbral (o fuera de ACB)
# el termino de eficiencia se sustituye por un valor neutro (percentil 50):
# ni premia ni penaliza -- que es lo que pidio Miguel ("no lo multiplicaria"),
# no que el peso se redistribuya hacia tapones/impacto (eso podia terminar
# SUBIENDO el rating de un jugador de pocos minutos si su +/- o sus tapones
# son buenos, justo lo contrario de la cautela pedida). Con el valor neutro
# los pesos (30/30/5/35) no cambian.
CENTER_EFICIENCIA_MPG_MIN = 18.0
CENTER_EFICIENCIA_NEUTRAL = 50.0

def center_eff_reliable(m, acb_verified=True):
    if not acb_verified:
        return False
    mpg = m.get('MPG')
    if mpg is None or pd.isna(mpg):
        return False
    return mpg >= CENTER_EFICIENCIA_MPG_MIN

def rating_from_metrics(m, pos_group, acb_verified=True):
    if pos_group == 'Center':
        sec_ref = REF_POS.get('Center', {})
        eff_p = pctl(sec_ref.get('eFG%', np.array([])), m['eFG%'])
        if not center_eff_reliable(m, acb_verified):
            eff_p = CENTER_EFICIENCIA_NEUTRAL
        blk_p = pctl(sec_ref.get('BPG', np.array([])), m['BPG'])
        reb_p = pctl(sec_ref.get('TRB%', np.array([])), m['TRB%'])
        impact_p = pctl(REF_POS_IMPACT.get('Center', np.array([])), m.get('PM40'))
        parts = [(CENTER_WEIGHTS['eficiencia'], eff_p), (CENTER_WEIGHTS['tapones'], blk_p),
                 (CENTER_WEIGHTS['rebote'], reb_p), (CENTER_WEIGHTS['impacto'], impact_p)]
        parts = [(w, v) for w, v in parts if not pd.isna(v)]
        if not parts:
            return np.nan
        wsum = sum(w for w, v in parts)
        return sum(w * v for w, v in parts) / wsum

    prof = POS_WEIGHTS.get(pos_group, POS_WEIGHTS['Forward'])
    core_p = [pctl(REF_WHOLE[k], m[k]) for k in CORE]
    core_avg = np.nanmean(core_p) if not all(pd.isna(x) for x in core_p) else np.nan
    mpg_p = pctl(REF_WHOLE['MPG'], m['MPG'])
    if pos_group in REF_POS:
        sec_p = [pctl(REF_POS[pos_group][k], m[k], invert=(d==-1)) for k, d in SEC.items()]
        sec_avg = np.nanmean(sec_p) if not all(pd.isna(x) for x in sec_p) else np.nan
    else:
        sec_avg = np.nan
    impact_p = pctl(REF_POS_IMPACT.get(pos_group, np.array([])), m.get('PM40'))
    parts = [(prof['core'], core_avg), (prof['mpg'], mpg_p), (prof['sec'], sec_avg), (prof['impact'], impact_p)]
    parts = [(w, v) for w, v in parts if not pd.isna(v)]
    if not parts:
        return np.nan
    wsum = sum(w for w, v in parts)
    return sum(w*v for w, v in parts) / wsum

# ----------------------------------------------------------------------------
# Mapa hexagonal de atributos (pedido por Miguel): 6 ejes, cada uno un
# percentil 0-100 reutilizando las mismas referencias de rating_from_metrics
# -- no son metricas nuevas, son las mismas recombinadas para lectura rapida:
#   Anotacion       = media(percentil PPG, percentil eFG%)      [volumen + eficiencia]
#   Creacion         = media(percentil AST%, percentil APG)      [playmaking]
#   Cuidado balon    = percentil TOV% invertido                  [menos perdidas = mejor]
#   Defensa          = media(percentil BPG, percentil SPG)       [tapones + robos]
#   Rebote           = percentil TRB%
#   Impacto          = percentil +/- por 40' (mismo que W_IMPACT arriba) --
#                       sin dato para altas de fuera de la ACB (no hay +/- ahi)
# ----------------------------------------------------------------------------
def attributes_from_metrics(m, pos_group):
    sec_ref = REF_POS.get(pos_group, {})
    anotacion = np.nanmean([pctl(REF_WHOLE['PPG'], m['PPG']), pctl(sec_ref.get('eFG%', np.array([])), m['eFG%'])])
    creacion = np.nanmean([pctl(REF_WHOLE['AST%'], m['AST%']), pctl(REF_WHOLE['APG'], m['APG'])])
    cuidado = pctl(sec_ref.get('TOV%', np.array([])), m['TOV%'], invert=True)
    defensa = np.nanmean([pctl(sec_ref.get('BPG', np.array([])), m['BPG']), pctl(sec_ref.get('SPG', np.array([])), m['SPG'])])
    rebote = pctl(sec_ref.get('TRB%', np.array([])), m['TRB%'])
    impacto = pctl(REF_POS_IMPACT.get(pos_group, np.array([])), m.get('PM40'))
    def r1(x):
        return None if pd.isna(x) else round(float(x))
    return {'anotacion': r1(anotacion), 'creacion': r1(creacion), 'cuidado_balon': r1(cuidado),
            'defensa': r1(defensa), 'rebote': r1(rebote), 'impacto': r1(impacto)}

qualified['raw_rating'] = qualified.apply(
    lambda r: rating_from_metrics({k: r[k] for k in CORE + ['MPG'] + list(SEC.keys()) + ['PM40']}, r['pos_group']), axis=1)
raw_rating_by_name = dict(zip(qualified['name_norm'] if 'name_norm' in qualified.columns else qualified['nickname'].map(norm), qualified['raw_rating']))

# ============================================================================
# 2) Regresion equipo: SUM(GmSc_PJ roster cualificado) -> NetRtg real (18 equipos)
# ============================================================================
team_sum_gmsc = qualified.groupby('team_last')['gmsc_pj'].sum().rename('sum_gmsc').reset_index()
merged = team_sum_gmsc.merge(sm[['Nombre equipo', 'NetRtg']], left_on='team_last', right_on='Nombre equipo', how='inner')
slope, intercept, r_value, p_value, se = sps.linregress(merged['sum_gmsc'], merged['NetRtg'])
R2 = r_value**2
print(f"Regresion equipo SUM(GmSc_PJ) -> NetRtg: n={len(merged)} slope={slope:.4f} intercept={intercept:.2f} R2={R2:.3f} p={p_value:.4f}")

def predict_netrtg(sum_gmsc):
    return slope * sum_gmsc + intercept

def pythag_wins(pts_for, pts_against, gp, exp=13.91):
    win_pct = pts_for**exp / (pts_for**exp + pts_against**exp)
    return win_pct, win_pct * gp

# ============================================================================
# 3) Roles validados (evita el bug de altura de v4): player_archetypes.csv
#    para jugadores con historial ACB, mercado_2026_27.csv como respaldo.
# ============================================================================
pa = pd.read_csv('player_archetypes.csv')
pa['name_norm'] = pa['nickname'].map(norm)
role_by_name = dict(zip(pa['name_norm'], pa['role']))

mk26 = pd.read_csv('mercado_2026_27.csv')
mk26['name_norm'] = mk26['Jugador'].map(norm)
role_by_name_mk = dict(zip(mk26['name_norm'], mk26['role']))

def get_validated_role(player_name):
    key = norm(player_name)
    if key in role_by_name and pd.notna(role_by_name[key]):
        return role_by_name[key]
    if key in role_by_name_mk and pd.notna(role_by_name_mk[key]):
        return role_by_name_mk[key]
    return None

# ---- clasificador de rol para las 7 altas de fuera de ACB (sin historial en
#      nuestras tablas ACB) -- misma logica original de 12_classify.py /
#      25_valencia_player_impact.py, referencia = roster_matched.csv por
#      posicion. classify() opera sobre PERCENTILES frente a esa referencia. ----
ROLE_METRICS = ['USG%', 'AST%', 'TS%', '3PAr', 'FTr']
qualified_rm_mask = rm['nickname'].notna() & (rm['bajo_volumen'] == False)
REF_ROLE = {grp: {m: rm.loc[qualified_rm_mask & (rm['pos_group'] == grp), m].dropna().values for m in ROLE_METRICS}
            for grp in ['Guard', 'Forward', 'Center']}

def pct_role(grp, m, val):
    ref = REF_ROLE[grp][m]
    if val is None or pd.isna(val) or len(ref) < 5:
        return np.nan
    return sps.percentileofscore(ref, val, kind='mean')

def classify(pos_group, ast_pct, usg_pct, ts_pct, threepar_pct, ftr_pct, ppg, height_m, ast_raw=None, usg_raw=None):
    g = pos_group
    if any(pd.isna(v) for v in [ast_pct, usg_pct, ts_pct, threepar_pct, ftr_pct]) or pd.isna(ppg):
        return 'Sin datos (metricas incompletas)'
    elite_scorer = (ppg > 15.5 and ast_pct < 80) or (usg_pct >= 70 and ts_pct >= 65) or (usg_pct >= 80 and ppg >= 14)
    if g == 'Guard':
        if ast_pct >= 80 and usg_pct >= 55: return 'Primary Ball Handler'
        if ast_pct >= 80 and usg_pct < 55: return 'Floor General'
        if ppg > 15.5 and ast_pct < 80: return 'Elite Scorer'
        if 40 <= ast_pct <= 80 and 45 <= usg_pct <= 90: return 'Secondary Ball Handler'
        if elite_scorer: return 'Elite Scorer'
        if threepar_pct >= 75 and usg_pct < 55: return 'Spot-Up Shooter'
        if usg_pct >= 50: return 'Scorer'
        return 'Spot-Up Shooter'
    if g == 'Forward':
        tall = height_m > 2.00 if height_m is not None else False
        if tall and ppg >= 9 and usg_pct >= 35: return 'Three-Level Wing Scorer'
        if elite_scorer: return 'Elite Scorer'
        if ftr_pct >= 70 and threepar_pct <= 45: return 'Slasher'
        if threepar_pct >= 75: return 'Spot-Up Shooter'
        if usg_pct >= 50: return 'Three-Level Wing Scorer' if (tall and ppg >= 9) else 'Scorer'
        return 'Spot-Up Shooter'
    if g == 'Center':
        # ORDEN CORREGIDO (analisis de patrones pedido por Miguel sobre los 14
        # equipos, con posicion/altura ya confirmadas): el fallback generico de
        # 'Post Player' (usg_raw>=16 y ppg>=5) es un umbral muy bajo que
        # capturaba a CASI TODOS los pivots de rotacion -- 16/19 (84%) de los
        # pivots de las 14 plantillas caian en 'Post Player' antes de esta
        # correccion, incluyendo jugadores con volumen real de triples
        # (Olivier Sarr 3PAr=42.5%, Aljaz Kunc 41.3%, Karlis Silins 29.6%,
        # Damien Jones 33.8%, Ondrej Hustak 53.8%) porque el chequeo de
        # 'Stretch Big' nunca llegaba a evaluarse -- quedaba SIEMPRE despues
        # del fallback generico. Comprobar primero el perfil de tirador
        # (threepar_pct) reactiva el arquetipo 'Stretch Big' (Interior
        # abierto) para estos 5 casos reales, que es justo el patron nuevo
        # mas claro que aparecio en la muestra de 14 equipos.
        if ast_pct >= 75 and (ast_raw is not None and ast_raw >= AST_ABS_MIN): return 'Post Player'
        if threepar_pct >= 70: return 'Stretch Big'
        if (usg_raw is not None and usg_raw >= 16) and ppg >= 5: return 'Post Player'
        return 'Roller'
    return 'Sin clasificar'

AST_ABS_MIN = 18

def classify_foreign_alta(r, pos_group, height_m):
    """r = fila cruda del CSV de Miguel (temporada 'primaria', mayor blend_weight)."""
    if pos_group is None:
        return 'Sin clasificar (posicion no asignada)', {}
    usg, ast, ppg = r['USG%'], r['AST%'], r['PTS']
    ts_raw = r['TS%'] / 10 if not pd.isna(r['TS%']) else np.nan
    p3ar_raw = (r['3PA'] / r['FGA'] * 100) if r['FGA'] else np.nan
    ftr_raw = (r['FTA'] / r['FGA'] * 100) if r['FGA'] else np.nan
    usg_pct = pct_role(pos_group, 'USG%', usg); ast_pct = pct_role(pos_group, 'AST%', ast)
    ts_pct = pct_role(pos_group, 'TS%', ts_raw); p3ar_pct = pct_role(pos_group, '3PAr', p3ar_raw)
    ftr_pct = pct_role(pos_group, 'FTr', ftr_raw)
    role = classify(pos_group, ast_pct, usg_pct, ts_pct, p3ar_pct, ftr_pct, ppg, height_m, ast_raw=ast, usg_raw=usg)
    pctls = {'USG%': round(usg_pct, 0) if not pd.isna(usg_pct) else None,
             'AST%': round(ast_pct, 0) if not pd.isna(ast_pct) else None,
             'TS%': round(ts_pct, 0) if not pd.isna(ts_pct) else None,
             '3PAr': round(p3ar_pct, 0) if not pd.isna(p3ar_pct) else None,
             'FTr': round(ftr_pct, 0) if not pd.isna(ftr_pct) else None}
    return role, pctls

# ============================================================================
# 4) fichajes_impact.json (bajas y altas ya medidas dentro de ACB, por equipo)
# ============================================================================
with open('fichajes_impact.json', encoding='utf-8') as f:
    fichajes = json.load(f)

adj_val, z_val = team_context_adj('Valencia Basket')
print(f"Ajuste equipo de origen Valencia (NetRtg={TEAM_NETRTG['Valencia Basket']:.1f}, z={z_val}): {adj_val:+.1f} pts")

# ============================================================================
# CORRECCIONES manuales confirmadas por Miguel (26/27) -- de momento solo
# aplican a Valencia, el primer equipo modelado en profundidad:
#   - Iroegbu, Xabi Lopez-Arostegui NO se quedan en Valencia (se suman a las
#     bajas, destino desconocido) y Valtonen NO ficha por Valencia despues de
#     todo (se retira por completo -- nunca estuvo en la plantilla real, no es
#     una baja, simplemente se cancela como alta).
# ============================================================================
EXIT_ADICIONAL = {'Valencia Basket': ['Ike Iroegbu', 'Xabi López-Arostegui'],
                   'Real Madrid': ['David Kramer', 'Izan Almansa', 'Egor Amosov']}
CANCELADOS = {'Valencia Basket': ['Elias Valtonen']}
# Bajas de Real Madrid confirmadas explicitamente por Miguel (Kramer, Bruno
# Fernando, Almansa, Grinvalds, Amosov, Kayser) que en 3 casos NO pasan el
# filtro automatico de J17 (Bruno Fernando: ultimo partido con minutos J3;
# Grinvalds: J1; Kayser: 0 minutos reales registrados) -- probablemente por
# lesion o por no haber entrado apenas en rotacion. Se incluyen igual porque
# la confirmacion directa y nominal de Miguel pesa mas que la heuristica
# generica (pensada para pillar cruces de nombre erroneos, no bajas reales de
# muestra corta), pero quedan marcadas como muestra insuficiente (bajo_volumen)
# en la ficha para que la fiabilidad del rating quede clara.
EXIT_ADICIONAL_FORZADO = {'Real Madrid': ['Bruno Fernando', 'Gunars Grinvalds', 'Fabian Kayser']}

# Lesionados de larga duracion (marcado explicito de Miguel) -- se queda en
# la plantilla (su rol/valor sigue siendo relevante para 26/27) pero se marca
# visualmente en la ficha.
LESIONADOS = {'Real Madrid': {'Usman Garuba': 'Lesión de larga duración -- previsiblemente baja para buena parte de la 26/27.'}}

# Correcciones manuales de equipo (Miguel, revision del Excel de auditoria de
# 224 jugadores, 03/09/2026): estos 2 jugadores aparecian en el modelo como
# "returning" (team_last de player_season.csv, temporada 25/26) en un equipo
# distinto al real para 26/27 -- fichajes de verano no capturados por el
# fichero de altas (mk) porque no son altas "medibles" via boxscore, son
# vueltas/traspasos entre equipos ACB que player_season.csv aun no refleja.
# Verificado via prensa/paginas oficiales de los clubes (08/07/2026 nota
# oficial Baskonia + basquetmanresa.com para Villar; unicajabaloncesto.com +
# nota de dorsal 09/2026 para Nzosa, que vuelve de la cesion en Burgos).
# name_norm (sin acentos, minuscula) -> nombre de PATROCINADOR destino real.
MANUAL_TEAM_MOVE = {
    'rafael villar': 'Kids&Us Manresa',      # antes: Kosner Baskonia (team_last)
    'yannick nzosa': 'Unicaja',              # antes: Recoletas Salud San Pablo Burgos (team_last, cesion 25/26)
}

# ----------------------------------------------------------------------------
# Ajuste de sistema por cambio de entrenador (hecho verificado, no supuesto):
# Real Madrid ficha a Pedro Martinez -- el entrenador de Valencia Basket en
# 25/26 -- para dirigir el equipo en 26/27 (El Espanol, 06/07/2026: "arquitecto
# del mejor Valencia Basket de la Historia"; su Valencia jugo a alta cadencia
# ofensiva, 90.9 puntos/partido en Euroliga esta temporada). Pedido explicito
# de Miguel: con ese cambio se espera mas ritmo y mas peso real para los
# guards manejadores/creadores de la rotacion, mas alla de lo que capta el
# rating generico frente a la curva ACB -- ejemplo suyo: Nick Smith Jr, que
# el ve como manejador secundario en este sistema (y sus percentiles de
# creacion ya rozaban ese corte: AST% pctl 34 / USG% pctl 44 frente al 40/45
# que exige la clasificacion automatica). Se trata como un ajuste editorial
# pequeno y documentado -- mismo criterio que el resto de overrides manuales
# de esta sesion (LESIONADOS, EXIT_ADICIONAL_FORZADO) -- no como una
# reescritura del modelo de rating.
# ----------------------------------------------------------------------------
ROLE_OVERRIDE_SISTEMA = {
    'Real Madrid': {
        'Nick Smith Jr': ('Secondary Ball Handler',
            'Reclasificado de Spot-Up Shooter: sus percentiles de creacion/uso ya '
            'estaban al borde del corte (AST% pctl 34, USG% pctl 44 -- la '
            'clasificacion automatica exige 40/45) y, con Pedro Martinez al mando '
            '(ex-Valencia Basket, sistema de mas ritmo), su perfil de manejador '
            'secundario gana peso real.'),
    },
}
SISTEMA_RITMO_TEAMS = {'Real Madrid'}
SISTEMA_RITMO_ROLES = {'Primary Ball Handler', 'Secondary Ball Handler', 'Floor General'}
SISTEMA_RITMO_BOOST = 4.0
SISTEMA_RITMO_NOTA = ('Ajuste de sistema: Real Madrid ficha a Pedro Martinez (entrenador de '
    'Valencia Basket en 25/26) para 26/27 -- su Valencia jugo a mas ritmo (90.9 pts/partido '
    'en Euroliga esta temporada). Se espera mas peso para los guards manejadores/creadores '
    'de la rotacion -- ajuste editorial pendiente de calibrar.')

def apply_role_override_sistema(team_name, player_name, role):
    ov = ROLE_OVERRIDE_SISTEMA.get(team_name, {}).get(player_name)
    if ov:
        return ov[0], ov[1]
    return role, None

def sistema_ritmo_boost(team_name, role):
    if team_name in SISTEMA_RITMO_TEAMS and role in SISTEMA_RITMO_ROLES:
        return SISTEMA_RITMO_BOOST
    return 0.0

# ----------------------------------------------------------------------------
# Competencia posicional con un titular importante del equipo destino --
# pedido por Miguel: "el equipo al que llega" importa; ej. Damien Jones va a
# jugar menos que Tavares. Se penaliza el rating de las ALTAS (nunca el de
# los que se quedan) que comparten posicion con un titular "importante"
# (jugador que se queda con rating >= IMPORTANT_RATING_MIN). Si ese titular
# es ademas una referencia defensiva de elite (percentil de 'defensa' --
# tapones+robos -- muy alto, ej. Tavares), la penalizacion se multiplica:
# un center que compite con un taponador de elite pierde mas minutos
# esperados que uno que compite con un center mediocre. Primer corte de
# constantes, pendiente de calibrar con Miguel.
# ----------------------------------------------------------------------------
K_CROWDING = 6.0
DEF_REF_MULT = 1.6
MPG_INCUMBENT_MIN = 18.0  # minutos/partido minimos para contar como "titular"
                           # real de esa posicion -- primer corte
DEF_REF_PCTL_MIN = 85

def apply_positional_crowding(roster_players):
    """Devuelve el dict de titulares identificados (para logging). Modifica
    roster_players in-place: penaliza rating_0_100 de las altas que compiten
    en posicion con un titular importante, y marca ese titular con
    'referencia_defensiva' si aplica.

    El titular de cada posicion se elige por MINUTOS reales (MPG), no por el
    rating agregado -- BUG detectado con Tavares: su rating global (62, muy
    penalizado por el bloque 'core' que pesa USG%/AST%/PPG/APG, metricas de
    un rim-runner que no anota ni crea) no reflejaba que es, con diferencia,
    el titular indiscutible del centro del Real Madrid. Minutos reales es un
    proxy mucho mas fiable de "quien es el titular" que un rating pensado
    para valorar produccion ofensiva."""
    candidates = {}
    for p in roster_players:
        if p['status'] != 'returning' or not p.get('pos_group') or not p.get('seasons'):
            continue
        mpg = p['seasons'][0].get('mpg')
        if mpg is None or mpg < MPG_INCUMBENT_MIN:
            continue
        cur = candidates.get(p['pos_group'])
        if cur is None or mpg > cur[1]:
            candidates[p['pos_group']] = (p, mpg)

    incumbents = {}
    for pos, (inc, mpg) in candidates.items():
        defensa = (inc.get('atributos') or {}).get('defensa')
        is_def_ref = bool(defensa is not None and defensa >= DEF_REF_PCTL_MIN)
        inc['referencia_defensiva'] = is_def_ref
        mpg_pctl = pctl(REF_WHOLE['MPG'], mpg)
        rating = inc.get('rating_0_100') or 0
        importance = np.nanmean([v for v in [mpg_pctl, rating] if not pd.isna(v)])
        inc['_importance'] = round(float(importance), 1) if not pd.isna(importance) else None
        incumbents[pos] = inc

    for p in roster_players:
        if p['status'] == 'returning' or not p.get('pos_group'):
            continue
        inc = incumbents.get(p['pos_group'])
        if inc is None or inc['player'] == p['player'] or inc.get('_importance') is None:
            continue
        rating = p.get('rating_0_100')
        if rating is None:
            continue
        mult = DEF_REF_MULT if inc.get('referencia_defensiva') else 1.0
        penalty = round(K_CROWDING * (inc['_importance'] / 100.0) * mult, 1)
        p['rating_pre_crowding'] = rating
        p['rating_0_100'] = round(float(np.clip(rating - penalty, 1, 99)), 1)
        p['crowding'] = {'titular': inc['player'], 'titular_rating': inc['rating_0_100'],
                          'referencia_defensiva': inc.get('referencia_defensiva', False),
                          'penalizacion': penalty}
    for inc in incumbents.values():
        inc.pop('_importance', None)
    return incumbents

def attribute_mix(roster_players, bajas_players):
    """Compara los atributos (6 ejes) de quienes SE VAN vs quienes LLEGAN --
    pedido por Miguel: 've qué se pierde y qué se gana' en el intercambio de
    plantilla, mas alla del rating agregado."""
    axes = ['anotacion', 'creacion', 'cuidado_balon', 'defensa', 'rebote', 'impacto']
    llegan = [p for p in roster_players if p['status'] in ('alta_acb', 'alta_extranjero')]
    out = {}
    for ax in axes:
        llegan_vals = [p['atributos'][ax] for p in llegan if p.get('atributos') and p['atributos'].get(ax) is not None]
        van_vals = [b['atributos'][ax] for b in bajas_players if b.get('atributos') and b['atributos'].get(ax) is not None]
        avg_llegan = round(sum(llegan_vals) / len(llegan_vals), 1) if llegan_vals else None
        avg_van = round(sum(van_vals) / len(van_vals), 1) if van_vals else None
        delta = round(avg_llegan - avg_van, 1) if (avg_llegan is not None and avg_van is not None) else None
        out[ax] = {'llegan': avg_llegan, 'se_van': avg_van, 'delta': delta, 'n_llegan': len(llegan_vals), 'n_se_van': len(van_vals)}
    return out

def build_player_entry(nickname, row, pos_group, rating_base, rating_final, role, status, seasons, gmsc_pj, atributos=None):
    pm40 = row.get('PM40') if hasattr(row, 'get') else None
    return {
        'player': nickname, 'pos_group': pos_group, 'status': status, 'role': role,
        'rating_base': None if rating_base is None or pd.isna(rating_base) else round(float(rating_base), 1),
        'rating_0_100': None if rating_final is None or pd.isna(rating_final) else round(float(rating_final), 1),
        'gmsc_pj': None if gmsc_pj is None or pd.isna(gmsc_pj) else round(float(gmsc_pj), 2),
        'pm_40': None if pm40 is None or pd.isna(pm40) else round(float(pm40), 1),
        'atributos': atributos,
        'seasons': seasons,
    }

# ---- altas de fuera de ACB, TODOS los equipos (Miguel amplio el fichero de
#      fichajes una segunda vez, "ya tengo todas las estadisticas de las
#      altas": ahora trae 560 filas / 127 jugadores / 18 equipos destino --
#      superset estricto del fichero anterior de 96 jugadores/14 equipos, mas
#      los 4 equipos que faltaban (MoraBanc Andorra, Monbus Obradoiro,
#      Recoletas Salud San Pablo Burgos, Río Breogán). Mismo esquema de
#      columnas, mismo mecanismo de relleno de filas en blanco mas abajo) ----
# (ver nota de reorg junto a _ARQ_MIGUEL_CSV mas arriba)
mk = pd.read_csv('raw_uploads/Fichajes_ACB_Players.csv')
mk['New Team'] = mk['New Team'].str.strip()
_MK_NON_NUMERIC = ['Player', 'New Team', 'Season', 'Team', 'League', 'Level', 'Context']
for _c in mk.columns:
    if _c not in _MK_NON_NUMERIC:
        mk[_c] = pd.to_numeric(mk[_c], errors='coerce')

# ---- Relleno de filas "Historico ACB sin estadisticas" (pedido explicito de
#      Miguel: "revisar manualmente, debes coger las medias de la temporada
#      pasada en ACB. Todos estos jugaron ACB por lo que los datos estan
#      disponibles"). 26 filas del fichero nuevo son un placeholder vacio
#      (Team=club real, League='Liga Endesa', pero GP/MIN/PTS/... en blanco)
#      para jugadores que YA tienen historial real en player_season.csv. Se
#      recalculan aqui a partir de esa fuente -- mismo mecanismo ya usado
#      (y validado con Miguel) para el Excel de posiciones. ----
_NICK_ALIAS_BACKFILL = {'nicolas laprovittola': 'nico laprovittola'}
_ps_bf = ps.copy()
_ps_bf['FG%_pg'] = 100 * _ps_bf['FGM'] / _ps_bf['FGA']
_ps_bf['eFG%_pg'] = 100 * (_ps_bf['FGM'] + 0.5*_ps_bf['P3M']) / _ps_bf['FGA']
_ps_bf['RPG_bf'] = _ps_bf['TRB'] / _ps_bf['games']
_ps_bf['BPG_bf'] = _ps_bf['BLK'] / _ps_bf['games']
_ps_bf['SPG_bf'] = _ps_bf['STL'] / _ps_bf['games']
_blank_mask = mk['GP'].isna() & mk['MIN'].isna() & mk['PTS'].isna()
_n_backfilled = 0
for _idx in mk[_blank_mask].index:
    _player = mk.at[_idx, 'Player']
    _key = _NICK_ALIAS_BACKFILL.get(norm(_player), norm(_player))
    _cand = _ps_bf[_ps_bf['name_norm'] == _key]
    if len(_cand) == 0:
        continue
    _row = _cand.sort_values('games', ascending=False).iloc[0]
    mk.at[_idx, 'GP'] = _row['games']; mk.at[_idx, 'MIN'] = _row['MPG']; mk.at[_idx, 'PTS'] = _row['PPG']
    mk.at[_idx, 'AST'] = _row['APG']; mk.at[_idx, 'TRB'] = _row['RPG_bf']
    mk.at[_idx, 'BLK'] = _row['BPG_bf']; mk.at[_idx, 'STL'] = _row['SPG_bf']
    mk.at[_idx, 'FGM'] = _row['FGM']/_row['games']; mk.at[_idx, 'FGA'] = _row['FGA']/_row['games']
    mk.at[_idx, 'FTM'] = _row['FTM']/_row['games']; mk.at[_idx, 'FTA'] = _row['FTA']/_row['games']
    mk.at[_idx, 'ORB'] = _row['OREB']/_row['games']; mk.at[_idx, 'DRB'] = _row['DREB']/_row['games']
    mk.at[_idx, 'TOV'] = _row['TOV']/_row['games']; mk.at[_idx, 'PF'] = _row['PF']/_row['games']
    mk.at[_idx, 'FG%'] = _row['FG%_pg']*10; mk.at[_idx, 'eFG%'] = _row['eFG%_pg']*10
    mk.at[_idx, 'TS%'] = _row['TS%']*10; mk.at[_idx, '3P%'] = _row['3P%']*10
    mk.at[_idx, '3PA'] = _row['P3A']/_row['games']; mk.at[_idx, '3PM'] = _row['P3M']/_row['games']
    mk.at[_idx, 'USG%'] = _row['USG%']; mk.at[_idx, 'AST%'] = _row['AST%']; mk.at[_idx, 'TOV%'] = _row['TOV%']
    mk.at[_idx, 'League'] = 'ACB'
    _n_backfilled += 1
print(f"Fichajes: {_n_backfilled}/{_blank_mask.sum()} filas 'Historico ACB sin datos' rellenadas desde player_season.csv")

# ---- Posicion / altura / fecha de nacimiento CONFIRMADAS por Miguel (Excel
#      devuelto, 96 jugadores de los 14 equipos destino) -- sustituye por
#      completo a los antiguos POS_ASSUMED/HEIGHT_ASSUMED (12 entradas,
#      solo Valencia/Real Madrid, mezcla de heuristica + estimacion manual). ----
_mig = pd.read_csv('jugadores_miguel_completado.csv')
_mig['Jugador'] = _mig['Jugador'].str.strip()
_mig['Equipo destino'] = _mig['Equipo destino'].str.strip()
_mig['Posición primaria'] = _mig['Posición primaria'].str.strip()
_POS_PRIMARIA_MAP = {'Base': 'Guard', 'Escolta': 'Guard', 'Base-Escolta': 'Guard', 'Base-escolta': 'Guard',
                      'Alero': 'Forward', 'Ala-Pívot': 'Forward', 'Pívot': 'Center'}
_mig['pos_group'] = _mig['Posición primaria'].map(_POS_PRIMARIA_MAP)
_mig['height_m'] = pd.to_numeric(_mig['Altura (m)'], errors='coerce')
POS_ASSUMED = dict(zip(_mig['Jugador'], _mig['pos_group']))
HEIGHT_ASSUMED = dict(zip(_mig['Jugador'], _mig['height_m']))
BIRTHDATE_ASSUMED = dict(zip(_mig['Jugador'], _mig['Fecha nacimiento / Edad']))
POS_DETALLE_ASSUMED = dict(zip(_mig['Jugador'], _mig['Posición en detalle']))

# Año de nacimiento (solo el año, no fecha completa) para jugadores 'returning'
# / 'alta_acb' -- pedido explicito de Miguel tras revisar el Excel de
# auditoria de 224 jugadores: "En edad, coge el año de nacimiento de la web
# https://acb.com/es/liga/equipos". Investigado por equipos via acb.com (perfil
# de jugador, campo "Fecha nacimiento") con Wikipedia/proballers/RealGM/
# eurobasket/basketnews como respaldo cuando el jugador no aparecia en la
# ficha de equipo de acb.com. Clave: nombre normalizado (norm()).
BIRTHYEAR_ASSUMED = {norm(k): v for k, v in {
    # --- Asisa Joventut ---
    'Ante Tomic': 1987, 'Emir Sulejmanovic': 1995, 'Isaac Nogues': 2004, 'Ludde Hakanson': 1996,
    'Ricky Rubio': 1990, 'Simon Birgander': 1997, 'Yannick Kraag': 2002,
    # --- Barça ---
    'Agustin Ubal': 2003, 'Darío Brizuela': 1994, 'Joel Parra': 2000, 'Juan Núñez': 2004,
    'Kevin Punter': 1993, 'Olek Balcerowski': 2000,
    # --- Casademont Zaragoza ---
    'Gabriel Olaseni': 1991, 'Guillem Vives': 1993, 'Joaquín Rodríguez': 1999,
    'Justin Jaworski': 1999, 'Miguel González': 1999, 'Nico Brussino': 1993, 'Trae Bell-Haynes': 1995,
    # --- FIATC Girona ---
    'James Karnik': 1998, 'Jassel Perez': 2001, 'Martinas Geben': 1994, 'Maxi Fjellerup': 1997,
    'Nikola Maric': 1998, 'Pep Busquets': 1999, 'Sergi Martínez': 1999,
    # --- Ilerna Lleida ---
    'Adria Rodriguez': 2003, 'Atoumane Diagne': 1998, 'Dani García': 1998, 'James Batemon': 1997,
    'John Shurna': 1990, 'Kur Kuath': 1998, 'Mark Hughes': 1997, 'Melvin Ejim': 1991,
    'Mikel Sanz': 1999, 'Oriol Paulí': 1994,
    # --- Kids&Us Manresa ---
    'Eric Vila': 1998, 'Ferran Bassas': 1992, 'Hugo Benitez': 2001, 'Pierre Oriola': 1992,
    'Rafael Villar': 2004,
    # --- Kosner Baskonia ---
    'Chris Duarte': 1997, 'Clement Frisch': 2002, 'Kobi Simmons': 1997, 'Markus Howard': 1999,
    'Matteo Spagnolo': 2003, 'Rodions Kurucs': 1998, 'Stefan Joksimovic': 2008, 'Tadas Sedekerskis': 1998,
    # --- La Laguna Tenerife ---
    'Aaron Doornekamp': 1985, 'Arturs Kurucs': 2000, 'Bruno Fitipaldo': 1991, 'Ethan Happ': 1996,
    'Giorgi Shermadini': 1989, 'Héctor Alderete': 2002, 'Marcelinho Huertas': 1983,
    'Tim Abromaitis': 1989, 'Wesley Van Beck': 1996, 'Xabi Lopez-Arostegui': 1997,
    # --- Monbus Obradoiro ---
    'Caleb Agada': 1994, 'Joel Soriano': 2000, 'Leo Meindl': 1993,
    # --- MoraBanc Andorra ---
    'Artem Pustovyi': 1992, 'Chumi Ortega': 1997, 'Kassius Robertson': 1994, 'Kyle Kuric': 1989, 'Rafa Luz': 1992,
    # --- Real Madrid ---
    'Alberto Abalde': 1995, 'Andrés Feliz': 1997, 'Chuma Okeke': 1998, 'Edy Tavares': 1992,
    'Facu Campazzo': 1991, 'Gabriel Deck': 1995, 'Gabriele Procida': 2002, 'Jaime Pradilla': 2001,
    'Sergio Llull': 1987, 'Theo Maledon': 2001, 'Timothe Luwawu-Cabarrot': 1995, 'Usman Garuba': 2002,
    # --- Recoletas Salud San Pablo Burgos ---
    'Chase Audige': 1999, 'Dani Díez': 1993, 'Retin Obasohan': 1993, 'Ziga Samar': 2001,
    # --- Río Breogán ---
    'Aleksandar Aranitovic': 1998, 'Danko Brankovic': 2000, 'Dominik Mavra': 1994, 'Erik Quintela': 1991,
    'Francis Alonso': 1996, 'Mihajlo Andric': 1994,
    # --- Surne Bilbao ---
    'Bingen Errasti': 2007, 'Darrun Hilliard': 1993, 'Harald Frey': 1997, 'Luke Petrasek': 1995,
    'Margiris Normantas': 1996, 'Martin Krampelj': 1995, 'Tryggvi Hlinason': 1997,
    # --- UCAM Murcia ---
    'Dylan Ennis': 1991, 'Emanuel Cate': 1997, 'Howard Sant-Roos': 1991, 'Jonah Radebaugh': 1997,
    'Juani Marcos': 2000, 'Marcis Steinbergs': 2001, 'Michael Forrest': 1999, 'Moussa Diagne': 1994,
    'Rubén López De La Torre': 2002, 'Sander Raieste': 1999, 'Toni Nakic': 1999, 'Wilhelm Falk': 2003,
    # --- Unicaja ---
    'Yannick Nzosa': 2003, 'Alberto Díaz': 1994, 'Cameron Hunt': 1997, 'David Kravish': 1992,
    'Jonathan Barreiro': 1997, 'Kendrick Perry': 1992, 'Nihad Djedovic': 1990, 'Tyler Kalinoski': 1992,
    'Tyson Pérez': 1996, 'Willy Hernangomez': 1994,
    # --- Valencia Basket ---
    'Gonzalo Corbalan': 2002, 'Josep Puerto': 1999, 'Kameron Taylor': 1994, 'Nate Reuvers': 1998,
    'Neal Sako': 1998, 'Omari Moore': 2000, 'Yankuba Sima': 1996, 'Álvaro Cárdenas': 2002,
    # --- Confirmado directamente por Miguel en el Excel devuelto (fila con
    #     valor ya relleno, no un placeholder de edad) ---
    'Alex Reyes': 1993,
}.items()}

# Caso ambiguo: DOS jugadores distintos se llaman igual (Jaime Fernández
# Bernabé en La Laguna Tenerife, nacido 1993, vs. un Jaime Fernández mas joven
# en Casademont Zaragoza, nacido 2000) -- BIRTHYEAR_ASSUMED (por nombre) no
# puede distinguirlos, asi que este caso se resuelve por (nombre, equipo).
BIRTHYEAR_ASSUMED_BY_TEAM = {
    (norm('Jaime Fernández'), 'Casademont Zaragoza'): 2000,
    (norm('Jaime Fernández'), 'La Laguna Tenerife'): 1993,
}

def birthyear_for(player_name, team_name):
    """Año de nacimiento investigado para 'returning'/'alta_acb' -- por
    (nombre, equipo) si es un caso ambiguo conocido, si no por nombre solo."""
    key_team = (norm(player_name), team_name)
    if key_team in BIRTHYEAR_ASSUMED_BY_TEAM:
        return BIRTHYEAR_ASSUMED_BY_TEAM[key_team]
    return BIRTHYEAR_ASSUMED.get(norm(player_name))

def season_rows(df_player):
    out = []
    for season, sub in df_player.groupby('Season', sort=False):
        agg = sub[sub['Team'] == 'All Teams']
        if len(agg) == 1:
            out.append(agg.iloc[0])
        elif len(sub) == 1:
            out.append(sub.iloc[0])
        else:
            out.append(sub.sort_values('GP', ascending=False).iloc[0])
    return out

def resolve_club_name(player, season, team):
    """'All Teams' es un agregado (mismo club, varias competiciones -- liga +
    Euroliga/Eurocup + copa), no una lista real de equipos. Para mostrar y
    para buscar escudo, se sustituye por el nombre del club real (la fila no-
    agregada de esa misma temporada)."""
    if team != 'All Teams':
        return team
    alt = mk[(mk['Player'] == player) & (mk['Season'] == season) & (mk['Team'] != 'All Teams')]
    return alt.iloc[0]['Team'] if len(alt) else team

def display_rows_current_season(player):
    """Filas a MOSTRAR en la ficha del jugador -- pedido por Miguel: una fila
    por cada competicion realmente jugada (liga domestica, Euroliga/Eurocup,
    copa...), no el resumen 'All Teams'. Solo temporada 25/26. Distinto del
    'detail'/'seasons_fmt' interno usado para el rating (que sigue usando el
    agregado 'All Teams' cuando existe, por ser la mejor foto de conjunto de
    la temporada) -- esto es puramente para lo que se ve en la tarjeta."""
    sub = mk[(mk['Player'] == player) & (mk['Season'].astype(str).str.startswith('2025')) & (mk['Team'] != 'All Teams')]
    out = []
    for _, r in sub.iterrows():
        key = (player, r['Season'], r['Team'])
        if key in CORRUPT_ROW_FIX and CORRUPT_ROW_FIX[key] is None:
            continue
        # Nivel/competicion mostrados en la ficha -- misma jerarquia de ligas
        # v2 usada para el rating (ya NO la columna 'Level'/'Context' del csv,
        # mayormente vacia/corrupta), para que lo que se ve coincida con lo
        # que se calcula.
        _kind, _val = _classify_league_row(r['League'])
        if _kind == 'continental':
            _level_disp = _val
        elif _kind == 'cup':
            _level_disp = None
        else:
            _tier = _domestic_tier_for_row(_val, r.get('Team'), r)
            _level_disp = {'Superior': 'Nivel superior', 'Cerca': 'Cerca de ACB', 'Cerca_ACB_ref': None,
                            'Ligeramente_peor': 'Ligeramente peor que ACB', 'Bastante_peor': 'Bastante peor que ACB'}.get(_tier)
        out.append({'season': r['Season'], 'team': r['Team'], 'league': r['League'], 'gp': int(r['GP']),
                     'level': _level_disp, 'context': None, 'pace_adjusted': (r.get('League') == 'G League'),
                     'mpg': round(float(r['MIN']), 1), 'ppg': round(float(r['PTS']), 1),
                     'apg': round(float(r['AST']), 1), 'rpg': round(float(r['TRB']), 1),
                     'usg': round(float(r['USG%']), 1), 'ast_pct': round(float(r['AST%']), 1),
                     'fg_pct': round(float(r['FG%'])/10, 1) if not pd.isna(r['FG%']) else None,
                     'p3_pct': round(float(r['3P%'])/10, 1) if not pd.isna(r['3P%']) else None,
                     'efg_pct': round(float(r['eFG%'])/10, 1) if not pd.isna(r['eFG%']) else None,
                     'tov_pct': round(float(r['TOV%']), 1) if not pd.isna(r['TOV%']) else None})
    out.sort(key=lambda d: -d['gp'])
    return out

GLEAGUE_PACE_DISCOUNT = 1/1.4  # G League juega ~40% mas posesiones/partido que ACB
GLEAGUE_COUNTING_COLS = ['PTS', 'AST', 'BLK', 'STL', 'TRB', 'ORB', 'DRB', 'TOV', 'PF', 'FGM', 'FGA', 'FTM', 'FTA']

def pace_deflate_row(r):
    """'Quita el brilli brilli' de las estadisticas de conteo por partido de
    G League: al jugarse ~40% mas posesiones/partido que en ACB, PTS/AST/BLK/
    STL/TRB/etc. de esa liga estan inflados por ritmo ademas de por minutos.
    Se descuentan aqui (x1/1.4) SOLO esas columnas de conteo -- nunca las de
    porcentaje/tasa (USG%, AST%, eFG%, FG%, 3P%, TOV%, TRB%...), que ya estan
    normalizadas por posesion y no necesitan ajuste (USG% de Gueye vs Reuvers
    es casi identico: 20.4 vs 20.5 -- la prueba de que el problema es el
    conteo bruto, no el uso relativo)."""
    if r.get('League') != 'G League':
        return r
    r = r.copy()
    for col in GLEAGUE_COUNTING_COLS:
        if col in r.index and not pd.isna(r[col]):
            r[col] = r[col] * GLEAGUE_PACE_DISCOUNT
    return r

def row_metrics(r):
    return {
        'USG%': r['USG%'], 'AST%': r['AST%'], 'PPG': r['PTS'], 'APG': r['AST'], 'MPG': r['MIN'],
        'eFG%': r['eFG%']/10 if not pd.isna(r['eFG%']) else np.nan,
        'TRB%': r['TRB%'], 'BPG': r['BLK'], 'SPG': r['STL'],
        'FG%': r['FG%']/10 if not pd.isna(r['FG%']) else np.nan,
        '3P%': r['3P%']/10 if not pd.isna(r['3P%']) else np.nan,
        'TOV%': r['TOV%'],
    }

# ============================================================================
# JERARQUIA DE LIGAS v2 -- multiplicativa (pedido explicito de Miguel: "no
# hagas que sumen puntos como tal. Pon que sean multiplicadores"), sustituye
# por completo a LEVEL_SHIFT_PTS/CONTEXT_MULT (v1, aditiva, calibrada solo
# sobre Valencia/Real Madrid). Confirmada por Miguel tras varias rondas:
#
#   Domestica, referencia = ACB:
#     Superior      -> EuroLeague (como nivel de la competicion domestica de
#                       origen) y NBA con rol de rotacion real (>=12 MPG y
#                       >=30 PJ en la temporada)
#     Cerca de ACB  -> Francia (Jeep Elite/Betclic/FBC), Lega A (Italia),
#                       G-BBL (Alemania), T-BSL (Turquia, primera division)
#     Ligeramente peor -> HEBA A1 (Grecia, salvo Panathinaikos/Olympiacos ->
#                       sube a "Cerca"), LKL (Lituania), VTB United, Liga ABA,
#                       G League "destacado" (ver GLEAGUE_DESTACADO_* abajo)
#     Bastante peor -> el resto: NCAA floja, G League media, T-TBL (Turquia,
#                       segunda), Primera/Segunda FEB, y el resto de ligas
#                       menores (P-OBL, BNXT, SKL, KLS, NBIA, ELBL, CBA, BSN,
#                       LNBP, LNB Pro B, BAL, CEBL...)
#     Competiciones de copa (Spanish Cup, German Cup, ACB SuperCup...) se
#     EXCLUYEN por completo (muestra pequeña y poco fiable, pedido de Miguel).
#
#   Multiplicador aplicado sobre el rating base (0-100):
#     Superior -> formula "ceiling-aware" (nunca pasa de 99, rendimientos
#                 decrecientes cuanto mas alto es el rating base):
#                 nuevo = base + (99-base)*(LEVEL_UP_K-1)
#     Cerca de ACB      -> x1.00 (sin cambio)
#     Ligeramente peor  -> x0.90
#     Bastante peor     -> x0.75
#
#   Competicion europea (capa ADITIVA aparte, "impacto de la competicion
#   jugada" segun palabras de Miguel -- EuroLeague > EuroCup > BCL > Europe
#   Cup): +6 / +3 / +1.5 / +0.5 puntos, se suma UNA vez por temporada si el
#   jugador disputo esa competicion (independientemente del nivel domestico).
# ============================================================================
LEVEL_UP_K = 1.3  # primer corte -- Superior, formula ceiling-aware
TIER_MULT = {'Cerca': 1.0, 'Cerca_ACB_ref': 1.0, 'Ligeramente_peor': 0.9, 'Bastante_peor': 0.75}

CONTINENTAL_LEAGUES = {'euroleague': 'EuroLeague', 'eurocup': 'EuroCup',
                        'bcl-eu': 'BCL', 'bcl-eu qual': 'BCL',
                        'europe cup': 'EuropeCup', 'europe cup - qual': 'EuropeCup'}
EURO_BONUS = {'EuroLeague': 6.0, 'EuroCup': 3.0, 'BCL': 1.5, 'EuropeCup': 0.5}

DOMESTIC_LEAGUE_TIER = {
    'jeep elite': 'Cerca', 'fbc': 'Cerca', 'french-jeep-elite': 'Cerca',
    'lega a': 'Cerca', 'g-bbl': 'Cerca', 't-bsl': 'Cerca',
    'heba a1': 'Ligeramente_peor', 'greek-heba-a1': 'Ligeramente_peor',
    'lkl': 'Ligeramente_peor', 'lithuanian citadele': 'Ligeramente_peor',
    'vtb united': 'Ligeramente_peor', 'liga aba': 'Ligeramente_peor',
    't-tbl': 'Bastante_peor', 'primera feb': 'Bastante_peor', 'segunda feb': 'Bastante_peor',
    'p-obl': 'Bastante_peor', 'bnxt': 'Bastante_peor', 'skl': 'Bastante_peor',
    'i-bsl': 'Bastante_peor', 'kls': 'Bastante_peor', 'nbia': 'Bastante_peor',
    'elbl': 'Bastante_peor', 'cba': 'Bastante_peor', 'bsn': 'Bastante_peor',
    'lnbp': 'Bastante_peor', 'lnb pro b': 'Bastante_peor', 'bal': 'Bastante_peor',
    'cebl': 'Bastante_peor', 'ncaa': 'Bastante_peor', 'ncaa di': 'Bastante_peor', 'ncaa d1': 'Bastante_peor',
    'acb': 'Cerca_ACB_ref', 'liga endesa': 'Cerca_ACB_ref',
}
HEBA_ELITE_CLUBS = {'panathinaikos', 'olympiacos'}
GLEAGUE_ALIASES = {'g league', 'gleague', 'gg league', 'wcb'}
NBA_ROTATION_MPG_MIN = 12.0
NBA_ROTATION_GP_MIN = 30
GLEAGUE_DESTACADO_PPG_MIN = 18.0
GLEAGUE_DESTACADO_MPG_MIN = 25.0

def _norm_league(s):
    return '' if pd.isna(s) else str(s).strip().lower()

def _classify_league_row(league_raw):
    key = _norm_league(league_raw)
    if key in CONTINENTAL_LEAGUES:
        return 'continental', CONTINENTAL_LEAGUES[key]
    if 'cup' in key or 'copa' in key:
        return 'cup', None
    return 'domestic', key

def _domestic_tier_for_row(key, team_raw, r):
    if key in GLEAGUE_ALIASES:
        ppg, mpg = r.get('PTS'), r.get('MIN')
        destacado = (pd.notna(ppg) and pd.notna(mpg) and ppg >= GLEAGUE_DESTACADO_PPG_MIN and mpg >= GLEAGUE_DESTACADO_MPG_MIN)
        return 'Ligeramente_peor' if destacado else 'Bastante_peor'
    if key == 'nba':
        mpg, gp = r.get('MIN'), r.get('GP')
        rotation_real = (pd.notna(mpg) and pd.notna(gp) and mpg >= NBA_ROTATION_MPG_MIN and gp >= NBA_ROTATION_GP_MIN)
        return 'Superior' if rotation_real else _domestic_tier_for_row('g league', team_raw, r)
    if key in ('heba a1', 'greek-heba-a1'):
        club = norm(team_raw) if team_raw else ''
        return 'Cerca' if any(c in club for c in HEBA_ELITE_CLUBS) else 'Ligeramente_peor'
    return DOMESTIC_LEAGUE_TIER.get(key, 'Bastante_peor')

def season_league_info(player, season):
    """Inspecciona las filas REALES (no el agregado 'All Teams') de esa
    temporada del jugador para determinar (a) el nivel domestico -- la
    competicion domestica con mas PJ, ignorando copas -- y (b) el credito
    europeo aditivo si jugo EuroLeague/EuroCup/BCL/Europe Cup esa temporada.
    Necesario porque la fila representativa que usa season_rows() suele ser
    el agregado 'All Teams' (League='All Leagues', sin identidad real de
    liga)."""
    sub = mk[(mk['Player'] == player) & (mk['Season'] == season) & (mk['Team'] != 'All Teams')]
    domestic_candidates = []
    euro_bonus, euro_name = 0.0, None
    for _, rr in sub.iterrows():
        kind, val = _classify_league_row(rr['League'])
        if kind == 'cup':
            continue
        if kind == 'continental':
            bonus = EURO_BONUS.get(val, 0.0)
            if bonus > euro_bonus:
                euro_bonus, euro_name = bonus, val
            continue
        tier = _domestic_tier_for_row(val, rr.get('Team'), rr)
        gp = rr['GP'] if pd.notna(rr['GP']) else 0
        domestic_candidates.append((gp, tier))
    domestic_tier = max(domestic_candidates, key=lambda x: x[0])[1] if domestic_candidates else None
    return domestic_tier, euro_bonus, euro_name

def apply_domestic_level(base, tier):
    if tier == 'Superior':
        return base + (99 - base) * (LEVEL_UP_K - 1)
    return base * TIER_MULT.get(tier, 1.0)

CORRUPT_ROW_FIX = {
    ('Lucas Marí', '2024-25 *', 'All Teams'): ('2024-25 *', "CB L'Horta Godella"),
    ('Lucas Marí', '2025-26', 'Vermont'): None,
    ('Mario Saint-Supery', '2024-25 *', 'All Teams'): ('2024-25 *', 'BAXI Manresa'),
    ('Nikola Mirotic', '2024-25 *', 'All Teams'): ('2024-25 *', 'AX Armani Exchange Milan'),
    ('Mario Saint-Supery', '2025-26', 'Gonzaga'): None,
    # 'Sr' (curso universitario) se cuela en la columna GP de esta fila,
    # desplazando el resto de columnas una posicion -- fila irrecuperable sin
    # volver a la fuente original, se excluye (le queda la temporada 25-26,
    # que si esta bien formada, para el rating).
    ('Simas Lukosius', '2024-25', 'Cincinnati'): None,
}
# Correccion manual de nivel (pedido explicito de Miguel): la temporada
# primaria de Nick Smith Jr (2024-25, Charlotte Hornets, 60 PJ / 22.8 MPG)
# fue rotacion NBA regular, no basura de banquillo -- un salto de nivel algo
# menor que "Bastante peor" (el que le tocaria como NBA no-rotacion) es mas
# realista. Se sube a "Ligeramente peor" solo en esa temporada (la de mayor
# peso en el blend); la de 2025-26 con los Lakers (12.5 MPG, rol marginal)
# sigue su clasificacion automatica normal.
LEVEL_OVERRIDE = {
    ('Nick Smith Jr', '2024-25', 'Charlotte Hornets'): 'Ligeramente_peor',
}

# ============================================================================
# Ajuste EUROLIGA a nivel de equipo (pedido explicito de Miguel, verbatim):
# "pon un plus sobre los jugadores porque son mejores que el resto, pero van
# a jugar mas desgastados ya que la Euroliga gasta mas... en jugadores
# estrella les quitaria algo -muy poquito- por cautela." Se aplica a TODO el
# roster 26/27 (quedan + altas) de los 4 equipos que juegan Euroliga esta
# temporada: +4 pts de suelo, salvo las 2 estrellas del equipo (mayor rating
# antes de este ajuste), que reciben -1 en su lugar. Primer corte de
# magnitudes -- mismo orden que K_TEAM_CONTEXT/K_CAUTELA, pendiente de
# calibrar mas fino con Miguel.
# ============================================================================
EUROLEAGUE_TEAMS_2627 = {'Real Madrid', 'Barça', 'Valencia Basket', 'Kosner Baskonia'}
EUROLEAGUE_TEAM_BONUS = 4.0
EUROLEAGUE_STAR_PENALTY = -1.0
EUROLEAGUE_STAR_COUNT = 2

def apply_euroleague_team_adjustment(team_name, roster_players):
    if team_name not in EUROLEAGUE_TEAMS_2627:
        return
    rated = [p for p in roster_players if p.get('rating_0_100') is not None]
    if not rated:
        return
    stars = sorted(rated, key=lambda p: -p['rating_0_100'])[:EUROLEAGUE_STAR_COUNT]
    star_names = {p['player'] for p in stars}
    for p in rated:
        delta = EUROLEAGUE_STAR_PENALTY if p['player'] in star_names else EUROLEAGUE_TEAM_BONUS
        p['rating_pre_euroliga'] = p['rating_0_100']
        p['rating_0_100'] = round(float(np.clip(p['rating_0_100'] + delta, 0, 100)), 1)
        p['euroliga_ajuste'] = delta
        p['euroliga_nota'] = ('Euroliga: plus de nivel de plantilla (juega mas competicion, mejor '
            'que el resto de la ACB).' if delta > 0 else
            'Euroliga: pequeño descuento por cautela -- referencia/estrella del equipo, mas exposicion '
            'a la carga de la Euroliga.')

# ============================================================================
# Curva de compresion "estilo 2K" (pedido explicito de Miguel, verbatim):
# "Pon un suelo de valoracion de 40. Del 95 al 99, hazlo muy complicado."
# Suelo=40, tramo lineal 0-85(raw)->40-88(rating), tramo final 85-100(raw)->
# 88-99(rating) con compresion de potencia (p=3) -- solo el mejor jugador de
# toda la muestra raw llega a 99. Se aplica como ULTIMO paso, sobre el rating
# final ya con todos los demas ajustes (nivel, euroliga, contexto de equipo,
# etc.), a TODOS los ratings mostrados (roster y bajas) para que la escala
# sea consistente en todo el dashboard.
# ============================================================================
def compress_2k(raw, floor=40.0, ceiling=99.0, bend=85.0, mid=88.0, p=3):
    if raw is None or pd.isna(raw):
        return None
    raw = max(0.0, min(100.0, float(raw)))
    if raw <= bend:
        y = floor + (mid - floor) * (raw / bend)
    else:
        y = mid + (ceiling - mid) * ((raw - bend) / (100.0 - bend)) ** p
    return round(min(ceiling, max(floor, y)), 1)

# ============================================================================
# Indicador de proyeccion por edad (pedido explicito de Miguel, verbatim):
# "la edad importa para medir proyeccion... indicador aparte, sin tocar el
# rating" (confirmado via AskUserQuestion: "Indicador aparte, sin tocar el
# rating"). Disponible para las altas de fuera de ACB (fichero de Miguel trae
# fecha de nacimiento real para las 96); no afecta rating_0_100 en ningun caso.
# ============================================================================
PROYECCION_EDAD_JOVEN_MAX = 23
PROYECCION_EDAD_VETERANO_MIN = 33
_SEASON_REF_DATE = pd.Timestamp('2026-09-01')

def proyeccion_from_birthdate(birthdate_str):
    if not birthdate_str or pd.isna(birthdate_str):
        return None, None
    try:
        bd = pd.to_datetime(birthdate_str, format='%d/%m/%Y')
    except Exception:
        return None, None
    edad = (_SEASON_REF_DATE - bd).days // 365
    if edad <= PROYECCION_EDAD_JOVEN_MAX:
        return int(edad), 'joven (en desarrollo)'
    if edad >= PROYECCION_EDAD_VETERANO_MIN:
        return int(edad), 'veterano'
    return int(edad), None

def proyeccion_from_birthyear(year):
    """Igual que proyeccion_from_birthdate pero a partir de solo el año de
    nacimiento (jugadores 'returning'/'alta_acb', fuente: acb.com/es/liga/equipos,
    pedido explicito de Miguel) -- edad aproximada (±1 año) por no tener el
    dia/mes exacto."""
    if not year or pd.isna(year):
        return None, None
    edad = _SEASON_REF_DATE.year - int(year)
    if edad <= PROYECCION_EDAD_JOVEN_MAX:
        return int(edad), 'joven (en desarrollo)'
    if edad >= PROYECCION_EDAD_VETERANO_MIN:
        return int(edad), 'veterano'
    return int(edad), None

# ============================================================================
# Arquetipos en español (pedido explicito de Miguel, mapeo dado por el).
# ============================================================================
ROLE_ES = {
    'Floor General': 'Floor General', 'Primary Ball Handler': 'Manejador principal',
    'Secondary Ball Handler': 'Manejador secundario', 'Post Player': 'Jugador de poste',
    'Roller': 'Finalizador', 'Three-Level Wing Scorer': 'Alero anotador completo',
    'Spot-Up Shooter': 'Lanzador exterior', 'Scorer': 'Anotador', 'Elite Scorer': 'Anotador de élite',
    'Stretch Big': 'Interior abierto', 'Slasher': 'Penetrador',
    'Versatile': 'Jugador versátil',  # categoria nueva, introducida por Miguel al corregir arquetipos (03/10/2026)
}
def role_es(role):
    return ROLE_ES.get(role, role)

# ============================================================================
# "Lo que se espera de el" -- pedido explicito de Miguel: sustituye en la
# ficha del jugador el texto metodologico (que explicaba el calculo del
# rating -- z-scores, ajustes de contexto, etc.) por una proyeccion de rol en
# lenguaje llano, de cara a lectura. Se calcula en un pase final sobre
# TEAM_DATA (ver mas abajo) para poder leer campos que se rellenan en varios
# sitios distintos de build_team (crowding, ajuste Euroliga, sistema, etc.).
# El dato tecnico en si (gap_detail, team_context_adj...) se mantiene en el
# JSON por si se necesita, solo deja de mostrarse como prosa en la ficha.
# ============================================================================
GAP_TREND_UMBRAL = 0.35

def build_expectativa(p):
    role_txt = ROLE_ES.get(p.get('role'), p.get('role'))
    parts = []
    if role_txt and role_txt != 'Sin clasificar':
        parts.append(f"Se espera que ejerza de {role_txt}.")
    else:
        parts.append("Rol todavía sin perfilar con claridad en el sistema del equipo.")

    status = p.get('status')
    if status == 'returning':
        parts.append("Sigue en la plantilla tras la 25/26.")
    elif status == 'alta_acb' and p.get('origin_team'):
        gd = p.get('gap_detail') or {}
        gap = gd.get('gap') if gd.get('metodo') == 'salto origen->destino' else None
        if gap is not None and gap >= GAP_TREND_UMBRAL:
            parts.append(f"Llega desde {p['origin_team']} con más peso del que tuvo allí.")
        elif gap is not None and gap <= -GAP_TREND_UMBRAL:
            parts.append(f"Llega desde {p['origin_team']} con un papel más contenido que allí.")
        else:
            parts.append(f"Llega desde {p['origin_team']}.")
    elif status == 'alta_extranjero':
        origen_txt = None
        if p.get('seasons'):
            s0 = p['seasons'][0]
            if s0.get('team') and s0.get('league') and s0['league'] != '-':
                origen_txt = f"{s0['team']} ({s0['league']})"
            elif s0.get('team'):
                origen_txt = s0['team']
        if origen_txt:
            parts.append(f"Ficha procedente de fuera de la ACB ({origen_txt}); la adaptación a la liga añade incertidumbre, para bien o para mal.")
        else:
            parts.append("Ficha procedente de fuera de la ACB; la adaptación a la liga añade incertidumbre, para bien o para mal.")

    if p.get('sistema_ritmo_boost'):
        parts.append("El cambio de sistema del equipo debería beneficiar directamente este perfil.")

    if p.get('euroliga_ajuste'):
        parts.append("Juega Euroliga esta temporada, un contexto de más nivel de plantilla y más competencia por minutos.")

    crowding = p.get('crowding')
    if crowding:
        parts.append(f"Puede tener minutos limitados por la competencia de {crowding['titular']} en su posición.")

    if p.get('low_sample'):
        parts.append("La muestra de la temporada pasada es corta, así que la proyección tiene más incertidumbre de lo habitual.")

    return ' '.join(parts)

def gmsc_from_row(r):
    """GmSc por partido a partir de las medias por partido del fichero de Miguel."""
    fgm, fga, fta, ftm = r['FGM'], r['FGA'], r['FTA'], r['FTM']
    orb, drb, stl, ast, blk, tov, pf, pts = r['ORB'], r['DRB'], r['STL'], r['AST'], r['BLK'], r['TOV'], r['PF'], r['PTS']
    vals = [fgm, fga, fta, ftm, orb, drb, stl, ast, blk, tov, pf, pts]
    if any(pd.isna(v) for v in vals):
        return np.nan
    return pts + 0.4*fgm - 0.7*fga - 0.4*(fta-ftm) + 0.7*orb + 0.3*drb + stl + 0.7*ast + 0.7*blk - 0.4*pf - tov

def build_team(team_name):
    """Construye la ficha completa (roster proyectado, bajas, matriz de
    arquetipos, proyeccion de equipo) para UN equipo, generalizando lo que
    antes era codigo especifico de Valencia -- pedido por Miguel para poder
    dividir el dashboard por equipo (arranca con Valencia + Real Madrid)."""
    # team_name: nombre de PATROCINADOR actual (26/27) -- se usa para filtrar
    # mk['New Team'] y para lo que se muestra/almacena en el dashboard.
    # team_name_i: nombre CANONICO 25/26 -- se usa para toda referencia real
    # de equipo (TEAM_NETRTG/sm/fichajes_impact.json). Ver canon_team().
    team_name_i = canon_team(team_name)
    fi = team_name_i and fichajes.get(team_name_i)
    if fi is None:
        raise ValueError(f"No hay fichajes_impact.json para {team_name!r} (canonico: {team_name_i!r})")
    exit_adicional = EXIT_ADICIONAL.get(team_name, [])
    exit_forzado = EXIT_ADICIONAL_FORZADO.get(team_name, [])
    cancelados_norm = set(norm(c) for c in CANCELADOS.get(team_name, []))
    lesionados_norm = {norm(k): v for k, v in LESIONADOS.get(team_name, {}).items()}
    team_adj_val, team_z = team_context_adj(team_name_i)
    print(f"\n=== {team_name} -- ajuste equipo destino (NetRtg={TEAM_NETRTG.get(team_name_i, float('nan')):.1f}, z={team_z}): {team_adj_val:+.1f} pts ===")

    # ---- 5) jugadores que SE QUEDAN (roster 25-26 menos bajas medibles menos
    #      salidas adicionales confirmadas) ----
    BAJAS_NAMES = [b['jugador'] for b in fi['detalle_bajas_medibles']]
    _moved_norm = set(norm(k) for k in MANUAL_TEAM_MOVE)
    team_roster_last = ps[(ps['team_last'] == team_name_i) & (~ps['name_norm'].isin(_moved_norm))].copy()
    _incoming_norm = set(norm(k) for k, v in MANUAL_TEAM_MOVE.items() if v == team_name)
    if _incoming_norm:
        _incoming = ps[ps['name_norm'].isin(_incoming_norm)].copy()
        team_roster_last = pd.concat([team_roster_last, _incoming], ignore_index=True)
    bajas_norm = set(norm(n) for n in BAJAS_NAMES) | set(norm(n) for n in exit_adicional) | set(norm(n) for n in exit_forzado)
    team_roster_last['name_norm'] = team_roster_last['nickname'].map(norm)
    returning = team_roster_last[~team_roster_last['name_norm'].isin(bajas_norm)].copy()
    print(f"{team_name} -- jugadores que se quedan (returning): {len(returning)} -> {list(returning['nickname'])}")

    roster_players = []

    for _, row in returning.iterrows():
        m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
        m['PM40'] = row['PM40']
        base = rating_from_metrics(m, row['pos_group'])
        atributos = attributes_from_metrics(m, row['pos_group'])
        # NOTA (reforma "ecosistema", pedida por Miguel): ya NO se suma aqui el
        # credito de equipo (team_adj_val) -- se sustituye por el termino
        # T_equipo del bloque global de mas abajo (percentil de equipo en el
        # ranking proyectado 26/27), combinado con Q_liga y R_equipo. Ver bloque
        # "REFORMA DE RATING: ecosistema (Q_liga / R_equipo / T_equipo)".
        final = None if pd.isna(base) else float(np.clip(base, 1, 99))
        role = get_validated_role(row['nickname']) or 'Sin clasificar'
        role, role_override_note = apply_role_override_sistema(team_name, row['nickname'], role)
        ritmo_boost = sistema_ritmo_boost(team_name, role)
        if ritmo_boost and final is not None:
            final = float(np.clip(final + ritmo_boost, 1, 99))
        seasons = [{
            'season': '2025-26', 'team': team_name, 'league': 'ACB', 'gp': int(row['games']),
            'mpg': round(float(row['MPG']), 1), 'ppg': round(float(row['PPG']), 1), 'apg': round(float(row['APG']), 1),
            'rpg': round(float(row['RPG']), 1), 'usg': round(float(row['USG%']), 1), 'ast_pct': round(float(row['AST%']), 1),
            'fg_pct': round(float(row['FG%']), 1), 'p3_pct': None if pd.isna(row['3P%']) else round(float(row['3P%']), 1),
            'efg_pct': round(float(row['eFG%']), 1), 'tov_pct': round(float(row['TOV%']), 1),
        }]
        entry = build_player_entry(row['nickname'], row, row['pos_group'], base, final, role,
                                    'returning', seasons, row['gmsc_pj'], atributos)
        entry['role_es'] = role_es(role)
        entry['low_sample'] = bool(row['bajo_volumen'])
        entry['logo_key'] = logo_key_for(team_name)
        entry['team'] = team_name
        if row['pos_group'] == 'Center':
            entry['eficiencia_excluida'] = not center_eff_reliable(m, True)
        if norm(row['nickname']) in lesionados_norm:
            entry['lesionado'] = lesionados_norm[norm(row['nickname'])]
        if role_override_note:
            entry['role_override_note'] = role_override_note
        if ritmo_boost:
            entry['sistema_ritmo_boost'] = ritmo_boost
            entry['sistema_ritmo_nota'] = SISTEMA_RITMO_NOTA
        _by = birthyear_for(row['nickname'], team_name)
        if _by:
            _edad, _proy = proyeccion_from_birthyear(_by)
            entry['anio_nacimiento'] = _by
            entry['edad'] = _edad
            entry['proyeccion'] = _proy
        roster_players.append(entry)

    # ---- altas ACB->ACB (usan datos reales de boxscore via ps/lookup_player,
    #      igual que Corbalan en Valencia -- pedido explicito de Miguel: "los
    #      que jugaron en ACB coge los datos de boxscore de aqui") ----
    # fichajes_impact.json a veces lista como "alta" a un jugador cuyo
    # 'equipo_referencia' coincide con el propio equipo destino (caso real:
    # Yannick Kraag en Asisa Joventut -- ya aparecia como 'returning' via ps,
    # duplicado detectado al extender el modelo a los 18 equipos). Se salta
    # aqui cualquier alta que ya este contada como returning, para no
    # duplicar al jugador con dos ratings distintos en el mismo roster.
    returning_norm = set(returning['name_norm'])
    for a in fi['detalle_altas_medibles']:
        if norm(a['jugador']) in cancelados_norm:
            print(f"[AVISO] {a['jugador']}: fichaje cancelado segun Miguel, se excluye por completo de la plantilla")
            continue
        if norm(a['jugador']) in returning_norm:
            print(f"[AVISO] {a['jugador']}: ya contado como 'returning' -- se salta como alta para no duplicar")
            continue
        row = lookup_player(a['jugador'])
        if row is None:
            continue
        origin_team = row['team_last']
        low_sample = bool(row['bajo_volumen'])
        adj, gap_detail = team_gap_adj(origin_team, team_name, low_sample=low_sample)
        m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
        m['PM40'] = row['PM40']
        base = rating_from_metrics(m, row['pos_group'])
        atributos = attributes_from_metrics(m, row['pos_group'])
        # NOTA (reforma "ecosistema"): igual que en 'returning', ya no se suma
        # aqui el credito de equipo (adj = team_gap_adj) -- lo sustituye T_equipo
        # mas abajo. 'adj'/'gap_detail' se conservan solo para la narrativa
        # (build_expectativa) y como dato informativo (entry['team_context_adj']).
        final = None if pd.isna(base) else float(np.clip(base, 1, 99))
        role = get_validated_role(a['jugador']) or 'Sin clasificar'
        role, role_override_note = apply_role_override_sistema(team_name, a['jugador'], role)
        ritmo_boost = sistema_ritmo_boost(team_name, role)
        if ritmo_boost and final is not None:
            final = float(np.clip(final + ritmo_boost, 1, 99))
        seasons = [{
            'season': '2025-26', 'team': origin_team, 'league': 'ACB', 'gp': int(row['games']),
            'mpg': round(float(row['MPG']), 1), 'ppg': round(float(row['PPG']), 1), 'apg': round(float(row['APG']), 1),
            'rpg': round(float(row['RPG']), 1), 'usg': round(float(row['USG%']), 1), 'ast_pct': round(float(row['AST%']), 1),
            'fg_pct': round(float(row['FG%']), 1), 'p3_pct': None if pd.isna(row['3P%']) else round(float(row['3P%']), 1),
            'efg_pct': round(float(row['eFG%']), 1), 'tov_pct': round(float(row['TOV%']), 1),
        }]
        entry = build_player_entry(a['jugador'], row, row['pos_group'], base, final, role, 'alta_acb', seasons, row['gmsc_pj'], atributos)
        entry['role_es'] = role_es(role)
        entry['origin_team'] = origin_team
        entry['origin_netrtg'] = round(TEAM_NETRTG.get(origin_team, float('nan')), 1)
        entry['team_context_adj'] = adj
        entry['gap_detail'] = gap_detail
        entry['role_note'] = f'Rol medido en su equipo de origen; puede variar en una plantilla mas profunda como la de {team_name}.'
        entry['logo_key'] = logo_key_for(team_name)
        entry['team'] = team_name
        if row['pos_group'] == 'Center':
            entry['eficiencia_excluida'] = not center_eff_reliable(m, True)
        if role_override_note:
            entry['role_override_note'] = role_override_note
        if ritmo_boost:
            entry['sistema_ritmo_boost'] = ritmo_boost
            entry['sistema_ritmo_nota'] = SISTEMA_RITMO_NOTA
        _by = birthyear_for(a['jugador'], team_name)
        if _by:
            _edad, _proy = proyeccion_from_birthyear(_by)
            entry['anio_nacimiento'] = _by
            entry['edad'] = _edad
            entry['proyeccion'] = _proy
        roster_players.append(entry)

    # ---- altas de fuera de ACB (fichero de Miguel, filtrado por 'New Team') ----
    # El fichero de Miguel (mk) ahora trae TODAS las altas de los 18 equipos,
    # incluidas las ACB->ACB que YA se procesaron arriba con datos reales de
    # boxscore (fi['detalle_altas_medibles']) -- sin este filtro, un jugador
    # como Guillem Vives (Asisa Joventut -> Casademont Zaragoza) se contaba
    # DOS VECES en el roster, con dos ratings distintos (bug detectado al
    # extender el modelo a los 18 equipos: Nico Brussino/Justin Jaworski/
    # Guillem Vives duplicados en Casademont Zaragoza).
    altas_acb_norm = set(norm(a['jugador']) for a in fi['detalle_altas_medibles'])
    mk_team = mk[(mk['New Team'] == team_name) & (~mk['Player'].map(norm).isin(altas_acb_norm))]
    players_out = []
    for player, sub in mk_team.groupby('Player', sort=False):
        sub = sub.copy()
        rows = season_rows(sub)
        rows = [r for r in rows if pd.notna(r.get('Season'))]  # Pradilla/Luwawu-Cabarrot: filas vacias, van por ACB
        rows = sorted(rows, key=lambda r: str(r['Season']), reverse=True)[:2]
        pos_group = POS_ASSUMED.get(player)
        height_m = HEIGHT_ASSUMED.get(player)

        detail = []
        gmsc_detail = []
        excluded_seasons = []
        for r in rows:
            key = (player, r['Season'], r['Team'])
            if key in CORRUPT_ROW_FIX:
                fix = CORRUPT_ROW_FIX[key]
                if fix is None:
                    excluded_seasons.append(f"{r['Season']} / {r['Team']} ({r['League']})")
                    continue
                season_ov, team_ov = fix
                r = mk[(mk['Player']==player) & (mk['Season']==season_ov) & (mk['Team']==team_ov)].iloc[0]
            pace_adjusted = (r.get('League') == 'G League')
            r_calc = pace_deflate_row(r)  # solo para el rating/GmSc -- el detalle mostrado usa r (real)
            m = row_metrics(r_calc)
            base = rating_from_metrics(m, pos_group, acb_verified=False)
            # Jerarquia de ligas v2 (multiplicativa + credito europeo aditivo,
            # ver season_league_info/apply_domestic_level mas arriba) -- ya NO
            # se usa la columna 'Context' del csv (parcial/corrupta, ~18%
            # rellena): el peso del blend entre temporadas pasa a ser
            # simplemente PJ real.
            tier, euro_bonus, euro_name = season_league_info(player, r['Season'])
            tier = LEVEL_OVERRIDE.get((player, r['Season'], r['Team']), tier)
            w = r['GP'] if pd.notna(r['GP']) else 0
            gmsc = gmsc_from_row(r_calc)
            if not pd.isna(gmsc):
                gmsc_shift = {'Superior': 1.6, 'Cerca': 0, 'Cerca_ACB_ref': 0, 'Ligeramente_peor': -2.4, 'Bastante_peor': -4.0}.get(tier, 0)
                gmsc_detail.append((w, gmsc + gmsc_shift))
            if pd.isna(base):
                continue
            adj = apply_domestic_level(base, tier) + euro_bonus
            team_display = resolve_club_name(player, r['Season'], r['Team'])
            detail.append({'season': r['Season'], 'team': team_display, 'league': r['League'], 'gp': int(r['GP']),
                            'level': tier, 'competicion_europea': euro_name, 'blend_weight': round(w, 1),
                            'pace_adjusted': pace_adjusted,
                            'rating_bruto': round(base, 1), 'rating_ajustado': round(adj, 1),
                            'mpg': round(float(r['MIN']), 1), 'ppg': round(float(r['PTS']), 1),
                            'apg': round(float(r['AST']), 1), 'rpg': round(float(r['TRB']), 1),
                            'usg': round(float(r['USG%']), 1), 'ast_pct': round(float(r['AST%']), 1),
                            'fg_pct': round(float(r['FG%'])/10, 1) if not pd.isna(r['FG%']) else None,
                            'p3_pct': round(float(r['3P%'])/10, 1) if not pd.isna(r['3P%']) else None,
                            'efg_pct': round(float(r['eFG%'])/10, 1) if not pd.isna(r['eFG%']) else None,
                            'tov_pct': round(float(r['TOV%']), 1) if not pd.isna(r['TOV%']) else None})

        if not detail:
            players_out.append({'player': player, 'pos_group': pos_group, 'rating_0_100': None, 'temporadas': [], 'gmsc_pj': None})
            continue
        wsum = sum(d['blend_weight'] for d in detail)
        rating = sum(d['blend_weight']*d['rating_ajustado'] for d in detail) / wsum if wsum else np.mean([d['rating_ajustado'] for d in detail])
        rating = round(float(np.clip(rating, 0, 100)), 1)
        # BUG FIX (detectado con Mario Saint-Supery): a diferencia de los que se
        # quedan y de las altas ACB->ACB (team_gap_adj), las altas de fuera de la
        # ACB nunca recibian el credito por entrar en el contexto del equipo
        # destino -- se quedaban solo con el ajuste de nivel de liga, sin el
        # credito que sí se aplica a todos los demas casos. La mayoria no tiene
        # un equipo de origen fiable en la curva ACB (Euroliga, NBA, NCAA, G
        # League, CBA, BSN...), así que no se les puede aplicar el mecanismo de
        # salto -- el fallback correcto y simetrico es el mismo credito de
        # destino (team_adj_val) que ya usan los que se quedan.
        # NOTA (reforma "ecosistema"): ya no se suma aqui team_adj_val -- lo
        # sustituye T_equipo mas abajo, igual que en 'returning'/'alta_acb'.
        rating_final = round(float(np.clip(rating, 0, 100)), 1)
        gmsc_blend = (sum(w*v for w, v in gmsc_detail) / sum(w for w, v in gmsc_detail)) if gmsc_detail else None

        # rol: se calcula sobre la temporada "primaria" (mayor peso de blend, es
        # decir la de contexto mas similar al equipo destino + mas partidos --
        # ej. TJ Shorts se clasifica con su temporada en Paris, no en Panathinaikos)
        primary = max(detail, key=lambda d: d['blend_weight'])
        prow_key = (player, primary['season'], primary['team'])
        if prow_key in CORRUPT_ROW_FIX and CORRUPT_ROW_FIX[prow_key]:
            season_ov, team_ov = CORRUPT_ROW_FIX[prow_key]
            prow = mk[(mk['Player']==player) & (mk['Season']==season_ov) & (mk['Team']==team_ov)].iloc[0]
        else:
            prow = mk[(mk['Player']==player) & (mk['Season']==primary['season']) & (mk['Team']==primary['team'])].iloc[0]
        role, role_pctls = classify_foreign_alta(prow, pos_group, height_m)
        role, role_override_note = apply_role_override_sistema(team_name, player, role)
        ritmo_boost = sistema_ritmo_boost(team_name, role)
        if ritmo_boost:
            rating_final = round(float(np.clip(rating_final + ritmo_boost, 0, 100)), 1)
        atributos = attributes_from_metrics(row_metrics(pace_deflate_row(prow)), pos_group)
        edad, proyeccion = proyeccion_from_birthdate(BIRTHDATE_ASSUMED.get(player))

        players_out.append({'player': player, 'pos_group': pos_group, 'height_m': height_m,
                             'rating_0_100': rating_final, 'temporadas': detail, 'gmsc_pj': gmsc_blend, 'role': role,
                             'role_pctls': role_pctls, 'role_season_used': f"{primary['season']} / {primary['team']}"})

        seasons_fmt = display_rows_current_season(player)
        entry = build_player_entry(player, None, pos_group, rating, rating_final, role, 'alta_extranjero', seasons_fmt, gmsc_blend, atributos)
        entry['role_es'] = role_es(role)
        entry['valencia_context_adj'] = team_adj_val
        entry['logo_key'] = logo_key_for(team_name)
        entry['altura_m'] = height_m
        entry['posicion_detalle'] = POS_DETALLE_ASSUMED.get(player)
        entry['fecha_nacimiento'] = BIRTHDATE_ASSUMED.get(player)
        entry['edad'] = edad
        entry['proyeccion'] = proyeccion
        if role_override_note:
            entry['role_override_note'] = role_override_note
        if ritmo_boost:
            entry['sistema_ritmo_boost'] = ritmo_boost
            entry['sistema_ritmo_nota'] = SISTEMA_RITMO_NOTA
        entry['team'] = team_name
        entry['role_note'] = f'Rol y estadísticas medidos fuera de la ACB -- puede variar en una plantilla mas profunda como la de {team_name}.'
        if pos_group == 'Center':
            entry['eficiencia_excluida'] = True
        if excluded_seasons:
            entry['role_note'] += f" Temporada(s) excluida(s) del rating por datos corruptos en la fuente: {', '.join(excluded_seasons)}."
        roster_players.append(entry)

    print(f"\n{team_name} -- altas extranjeras (roles):", [(p['player'], p.get('role')) for p in players_out])

    # ---- poda manual confirmada por Miguel (ver MANUAL_ROSTER_KEEP arriba):
    #      solo se queda en el dashboard quien aparece en su lista de 224 ----
    _before_prune = len(roster_players)
    roster_players = [p for p in roster_players if (norm(p['player']), team_name) in MANUAL_ROSTER_KEEP]
    _pruned_n = _before_prune - len(roster_players)
    if _pruned_n:
        print(f"{team_name} -- podados {_pruned_n} jugadores fuera de la lista confirmada por Miguel "
              f"({_before_prune} -> {len(roster_players)})")

    # ---- competencia posicional: penaliza a las altas que comparten posicion
    #      con un titular importante del equipo destino (ver definicion de
    #      apply_positional_crowding mas arriba) ----
    incumbents = apply_positional_crowding(roster_players)
    if incumbents:
        print(f"{team_name} -- titulares por posicion (competencia): " +
              ", ".join(f"{pos}: {inc['player']} ({inc['rating_0_100']}{', referencia defensiva' if inc.get('referencia_defensiva') else ''})" for pos, inc in incumbents.items()))

    apply_euroleague_team_adjustment(team_name, roster_players)
    if team_name in EUROLEAGUE_TEAMS_2627:
        print(f"{team_name} -- ajuste Euroliga aplicado: +{EUROLEAGUE_TEAM_BONUS} pts al roster, "
              f"-{abs(EUROLEAGUE_STAR_PENALTY)} a las {EUROLEAGUE_STAR_COUNT} estrellas del equipo")

    # ---- 6) roster que SE VA -- para la matriz de arquetipos "año pasado" ----
    bajas_players = []
    for b in fi['detalle_bajas_medibles']:
        ok, motivo = baja_valida(b['jugador'], team_name_i)
        if not ok:
            print(f"[AVISO] {b['jugador']}: excluido de bajas -- {motivo} (no es una baja fiable de {team_name})")
            continue
        row = lookup_player(b['jugador'])
        if row is None:
            continue
        low_sample = bool(row['bajo_volumen'])
        adj, gap_detail = team_gap_adj(team_name_i, b['procedencia_destino'], low_sample=low_sample)
        m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
        m['PM40'] = row['PM40']
        base = rating_from_metrics(m, row['pos_group'])
        atributos = attributes_from_metrics(m, row['pos_group'])
        # NOTA (reforma ecosistema, corregido 03/10/2026 -- Miguel: "revisa
        # los ratings de las bajas, no cuadran"): 'final' llevaba todavia el
        # credito/penalizacion por equipo de destino (adj, del mecanismo
        # ANTIGUO team_gap_adj) sumado a la produccion pura -- justo lo que
        # la reforma de ecosistema ya habia quitado para el resto del roster
        # (returning/alta_acb/alta_extranjero), pero se quedo sin tocar aqui
        # por descuido. Con eso, una baja de produccion practicamente nula
        # (rating_base=0) podia mostrar rating_0_100~45 (0 + adj~9, luego
        # comprimido con suelo 40). 'final' ahora es SOLO base (compress_2k
        # se sigue aplicando igual mas abajo) -- adj/gap_detail se calculan
        # y se guardan igual (quedan en el JSON de cara a debug), pero ya
        # no entran en el rating.
        final = None if pd.isna(base) else float(np.clip(base, 1, 99))
        role = get_validated_role(b['jugador']) or 'Sin clasificar'
        was_on_team = row['team_last'] == team_name_i
        bajas_players.append({
            'player': b['jugador'], 'pos_group': row['pos_group'], 'role': role,
            'rating_base': None if pd.isna(base) else round(float(base), 1),
            'rating_0_100': None if final is None else round(float(final), 1),
            'team_context_adj': adj, 'gap_detail': gap_detail,
            'gmsc_pj': round(float(row['gmsc_pj']), 2),
            'destino': b['procedencia_destino'], 'was_at_valencia_this_season': bool(was_on_team),
            'mpg': round(float(row['MPG']), 1), 'ppg': round(float(row['PPG']), 1), 'low_sample': low_sample,
            'pm_40': None if pd.isna(row['PM40']) else round(float(row['PM40']), 1),
            'atributos': atributos,
            'logo_key': logo_key_for(b['procedencia_destino']),
            'team': team_name,
            'eficiencia_excluida': (not center_eff_reliable(m, True)) if row['pos_group'] == 'Center' else None,
        })

    # ---- salidas adicionales confirmadas por Miguel -- se quedaban en el
    #      roster hasta ahora; destino desconocido -> cae al mecanismo antiguo
    #      solo-origen (igual que cuando no hay destino). Las de
    #      EXIT_ADICIONAL_FORZADO saltan el filtro automatico de J17 (ver
    #      comentario en la definicion mas arriba). ----
    for name in exit_adicional + exit_forzado:
        forzado = name in exit_forzado
        if forzado:
            ok, motivo = True, None
        else:
            ok, motivo = baja_valida(name, team_name_i)
        if not ok:
            print(f"[AVISO] {name}: excluido por completo del modelo -- {motivo} (no hay base fiable para tratarlo como baja)")
            continue
        row = lookup_player(name)
        if row is None:
            continue
        low_sample = bool(row['bajo_volumen'])
        adj, gap_detail = team_gap_adj(team_name_i, None, low_sample=low_sample)
        m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
        m['PM40'] = row['PM40']
        base = rating_from_metrics(m, row['pos_group'])
        atributos = attributes_from_metrics(m, row['pos_group'])
        # NOTA (reforma ecosistema, corregido 03/10/2026): ver comentario
        # identico en el otro bloque de bajas mas arriba -- 'final' ya no
        # lleva el adj de team_gap_adj (mecanismo antiguo retirado).
        final = None if pd.isna(base) else float(np.clip(base, 1, 99))
        role = get_validated_role(name) or 'Sin clasificar'
        bajas_players.append({
            'player': name, 'pos_group': row['pos_group'], 'role': role,
            'rating_base': None if pd.isna(base) else round(float(base), 1),
            'rating_0_100': None if final is None else round(float(final), 1),
            'team_context_adj': adj, 'gap_detail': gap_detail,
            'gmsc_pj': round(float(row['gmsc_pj']), 2),
            'destino': 'Por confirmar', 'was_at_valencia_this_season': True,
            'mpg': round(float(row['MPG']), 1), 'ppg': round(float(row['PPG']), 1), 'low_sample': low_sample,
            'pm_40': None if pd.isna(row['PM40']) else round(float(row['PM40']), 1),
            'atributos': atributos,
            'logo_key': logo_key_for('Por confirmar'),
            'team': team_name,
            'confirmado_manual_sin_j17': forzado,
            'eficiencia_excluida': (not center_eff_reliable(m, True)) if row['pos_group'] == 'Center' else None,
        })
    if exit_adicional or exit_forzado:
        print(f"\n[AVISO] {team_name}: salidas adicionales confirmadas movidas de 'se queda' a 'baja' -- {exit_adicional + exit_forzado}")

    print(f"\n{team_name} -- bajas (roles):", [(b['player'], b['role'], b['was_at_valencia_this_season']) for b in bajas_players])

    # ============================================================================
    # 7) Proyeccion de equipo: SUM(GmSc_PJ) real (roster 25-26) vs proyectado (26-27)
    #
    #    OJO -- la regresion se calibro sobre el grupo "cualificado" (bajo_volumen
    #    ==False) de cada equipo, que en la practica son ~9-13 jugadores de
    #    rotacion real (media de la liga: 10.9). Sumar el GmSc de TODOS los
    #    fichajes firmados sin mas sobreestima brutalmente el roster -- no
    #    todos van a tener minutos de rotacion a la vez. Para mantener la
    #    comparacion "manzanas con manzanas" con la regresion, el roster nuevo
    #    se recorta al mismo TAMAÑO de rotacion que tenia el roster viejo (los
    #    N jugadores de mayor GmSc esperado, N = tamaño de la rotacion
    #    cualificada del equipo esta temporada). Es una simplificacion (asume
    #    que los minutos van a los jugadores de mayor impacto esperado, no un
    #    reparto real de rotaciones), documentada como tal.
    # ============================================================================
    # Equipos ASCENDIDOS de Primera FEB (Leyma Coruña, Monbus Obradoiro) no
    # tienen NetRtg/GP/PTS real de la 25-26 en season_metrics.csv (jugaron una
    # liga distinta, no comparable en esa escala) -- se omite por completo la
    # regresion NetRtg->proyeccion de victorias para estos casos, en vez de
    # forzar un numero que no tendria base real. team_projection queda a None
    # y el resto del dashboard (roster, bajas, arquetipos) funciona igual.
    team_has_real_season = team_name_i in TEAM_NETRTG
    qualified_old = team_roster_last[~team_roster_last['bajo_volumen']].copy()
    sum_gmsc_old = float(qualified_old['gmsc_pj'].sum())
    n_rotation = len(qualified_old)

    team_projection = None
    if team_has_real_season and n_rotation > 0:
        netrtg_old_real = TEAM_NETRTG[team_name_i]
        netrtg_old_pred = predict_netrtg(sum_gmsc_old)

        candidatos_new = []
        for _, row in returning.iterrows():
            if not row['bajo_volumen']:
                candidatos_new.append((row['nickname'], float(row['gmsc_pj'])))
        for a in fi['detalle_altas_medibles']:
            if norm(a['jugador']) in cancelados_norm or norm(a['jugador']) in returning_norm:
                continue
            candidatos_new.append((a['jugador'], a['gmsc_pj']))
        for p in players_out:
            if p.get('gmsc_pj') is not None:
                candidatos_new.append((p['player'], p['gmsc_pj']))

        candidatos_new_sorted = sorted(candidatos_new, key=lambda x: -x[1])
        rotation_new = candidatos_new_sorted[:n_rotation]
        sum_gmsc_new = float(sum(v for _, v in rotation_new))
        bench_new = candidatos_new_sorted[n_rotation:]

        netrtg_new_pred = predict_netrtg(sum_gmsc_new)
        delta_netrtg = netrtg_new_pred - netrtg_old_pred  # variacion proyectada, aplicada sobre el NetRtg REAL de partida
        netrtg_new_final = netrtg_old_real + delta_netrtg

        gp = int(TEAM_GP[team_name_i])

        ortg_old = sm.loc[sm['Nombre equipo']==team_name_i, 'OER'].iloc[0]
        drtg_old = sm.loc[sm['Nombre equipo']==team_name_i, 'DER'].iloc[0]
        ortg_new = ortg_old + delta_netrtg/2
        drtg_new = drtg_old - delta_netrtg/2
        pts_for_new = ortg_new/100 * TEAM_POSS[team_name_i]
        pts_against_new = drtg_new/100 * TEAM_POSS[team_name_i]
        win_pct_new, wins_new = pythag_wins(pts_for_new, pts_against_new, gp)
        win_pct_old, wins_old = pythag_wins(TEAM_PTS[team_name_i], TEAM_OPP_PTS[team_name_i], gp)

        print(f"\n--- Proyeccion equipo {team_name} (rotacion N={n_rotation}) ---")
        print(f"sum_gmsc_old={sum_gmsc_old:.1f} -> NetRtg pred={netrtg_old_pred:.2f} (real={netrtg_old_real:.2f})")
        print(f"sum_gmsc_new={sum_gmsc_new:.1f} -> NetRtg pred={netrtg_new_pred:.2f}  delta={delta_netrtg:+.2f}")
        print(f"Rotacion nueva (top {n_rotation} por GmSc): {[n for n,_ in rotation_new]}")
        print(f"Banquillo/fuera de rotacion proyectada: {[n for n,_ in bench_new]}")
        print(f"NetRtg proyectado 26-27 (sobre base real): {netrtg_new_final:+.2f}")
        print(f"Wins reales-pitagoricas 25-26: {wins_old:.1f}/{gp}  ({win_pct_old*100:.1f}%)")
        print(f"Wins proyectadas 26-27: {wins_new:.1f}/{gp}  ({win_pct_new*100:.1f}%)")

        team_projection = {
            'netrtg_real_25_26': round(float(netrtg_old_real), 2),
            'netrtg_proyectado_26_27': round(float(netrtg_new_final), 2),
            'delta_netrtg': round(float(delta_netrtg), 2),
            'wins_25_26_pitagoricas': round(float(wins_old), 1),
            'wins_26_27_proyectadas': round(float(wins_new), 1),
            'gp': gp,
            'sum_gmsc_old': round(sum_gmsc_old, 1),
            'sum_gmsc_new': round(sum_gmsc_new, 1),
            'n_rotation': n_rotation,
            'rotation_new': [n for n, _ in rotation_new],
            'bench_new': [n for n, _ in bench_new],
            'ppg_25_26': round(float(TEAM_PTS[team_name_i]) / gp, 1),
            'ppg_26_27': round(float(pts_for_new) / gp, 1),
        }
    else:
        print(f"\n--- {team_name}: SIN proyeccion de equipo (ascendido de Primera FEB, sin NetRtg/GP real 25-26 comparable) ---")

    # ---- 9) matriz de arquetipos: año pasado vs este año, DE ESTE equipo ----
    archetypes_last = {}
    for _, row in returning.iterrows():
        role = get_validated_role(row['nickname']) or 'Sin clasificar'
        archetypes_last.setdefault(role, []).append(row['nickname'])
    for b in bajas_players:
        if b['was_at_valencia_this_season']:
            archetypes_last.setdefault(b['role'], []).append(b['player'])
    # jugadores cedidos fuera del equipo esta temporada no entran en la mezcla
    # de arquetipos "año pasado" del propio equipo (ver baja_valida).

    archetypes_new = {}
    for p in roster_players:
        archetypes_new.setdefault(p['role'], []).append(p['player'])

    altas_medibles_count = sum(1 for p in roster_players if p['status'] in ('alta_acb', 'alta_extranjero'))

    # ---- 10) Curva de compresion "estilo 2K" (suelo=40, tramo 95-99 muy
    #      exigente) -- ULTIMO paso, sobre el rating YA con todos los demas
    #      ajustes. Para BAJAS (nivel, euroliga, contexto de equipo, crowding,
    #      sistema) se aplica aqui igual que siempre. Para el ROSTER 26/27 ya
    #      NO se comprime aqui -- roster_players[*]['rating_0_100'] en este
    #      punto es la "calidad ajustada" (produccion + sistema + euroliga +
    #      crowding, SIN credito de equipo todavia) que alimenta el bloque
    #      global "REFORMA DE RATING: ecosistema" (Q_liga/R_equipo/T_equipo,
    #      mas abajo, tras construir TEAM_DATA de los 18 equipos) -- ese bloque
    #      es el que aplica compress_2k al roster, una vez calculado T_equipo
    #      (que necesita el ranking proyectado de TODOS los equipos, no solo
    #      este). rating_base se deja SIN comprimir en ambos casos (es el
    #      percentil crudo pre-ajustes, referencia interna/debug). ----
    for b in bajas_players:
        if b.get('rating_0_100') is not None:
            b['rating_0_100_raw'] = b['rating_0_100']
            b['rating_0_100'] = compress_2k(b['rating_0_100'])

    return {
        'roster_26_27': roster_players,
        'bajas': bajas_players,
        'archetypes_last': archetypes_last,
        'archetypes_new': archetypes_new,
        'altas_medibles_count': altas_medibles_count,
        'attribute_mix': attribute_mix(roster_players, bajas_players),
        'team_projection': team_projection,
        'es_ascendido': not team_has_real_season,
    }

# ============================================================================
# Equipos con "modelo completo": ahora los 18 de la ACB 26/27, una vez que
# Miguel amplio el fichero de fichajes (estadisticas de altas) a los 18
# equipos -- antes solo Valencia y Real Madrid tenian esa cobertura. Leyma
# Coruña y Monbus Obradoiro (ascendidos de Primera FEB) SI se construyen,
# pero con alcance reducido: build_team() ya gestiona que no tengan
# team_projection (sin NetRtg/GP real 25-26 comparable) ni jugadores
# 'returning' (no hay historial ACB de su plantilla -- jugaron en otra
# liga) -- su ficha son solo las altas medidas (fichero de Miguel). Jugadores
# que continuan de su plantilla ascendida de FEB quedan fuera de esta
# version: exigiria investigar posicion/altura para esa plantilla y una
# referencia de nivel propia de Primera FEB, un siguiente paso pendiente.
# ============================================================================
FULL_MODEL_TEAMS = ['Valencia Basket', 'Real Madrid', 'Barça', 'Asisa Joventut', 'Casademont Zaragoza',
                     'FIATC Girona', 'Ilerna Lleida', 'Kids&Us Manresa', 'Kosner Baskonia',
                     'La Laguna Tenerife', 'MoraBanc Andorra', 'Recoletas Salud San Pablo Burgos',
                     'Río Breogán', 'Surne Bilbao', 'UCAM Murcia', 'Unicaja',
                     'Leyma Coruña', 'Monbus Obradoiro']
TEAM_DATA = {team: build_team(team) for team in FULL_MODEL_TEAMS}

# TEAM_DATA usa nombre de PATROCINADOR 26/27 como clave (FULL_MODEL_TEAMS).
# Varias secciones de mas abajo (8: "los otros equipos", 10: JSON) iteran en
# cambio sobre TEAMS_26_27 / _teams_dash, que usan el nombre CANONICO 25/26
# (dashboard_v2_content.html). Este indice invertido permite encontrar el
# TEAM_DATA correcto sin importar que convencion traiga la clave.
TEAM_DATA_BY_CANON = {canon_team(k): v for k, v in TEAM_DATA.items()}

# ============================================================================
# REFORMA DE RATING: ecosistema (Q_liga / R_equipo / T_equipo) -- pedido
# explicito de Miguel (24/09/2026): el rating no debe medir solo "quien es el
# mejor jugador" en aislado -- debe combinar calidad individual con el
# concepto de ECOSISTEMA. Cita textual: "si tu de mi esperas que sea el mejor
# del equipo, el mejor de la liga y que el equipo sea el mejor, deberias
# ponerme un 99. Pero si esperas de mi que sea top 3 de la liga, el mejor
# equipo de la liga [de MI equipo] y el equipo top 10, puedes ponerme un 90."
#
# Sustituye el mecanismo anterior (team_context_adj / team_gap_adj sumados
# directamente al rating, un bonus/penalizacion continuo de hasta +-8 pts por
# NetRtg de equipo -- ver 'final = base' sin ese sumando en las 3 secciones de
# build_team) por una combinacion explicita de 3 percentiles 0-100:
#   Q_liga   = percentil de calidad DENTRO DE SU POSICION (Guard/Forward/
#              Center), entre los 18 equipos. La "calidad" usada es
#              rating_0_100 EN ESTE PUNTO del pipeline: ya incluye produccion
#              (rating_base) + ajuste de sistema (Pedro Martinez/Real Madrid)
#              + ajuste Euroliga + penalizacion de competencia posicional,
#              pero TODAVIA NO credito de equipo ni compresion 2K.
#   R_equipo = percentil de su puesto en el ranking INTERNO de su propio
#              equipo (misma calidad ajustada), 100 = el mejor de su plantilla.
#   T_equipo = percentil del EQUIPO en el ranking proyectado 26/27 (NetRtg
#              proyectado, ya calculado en build_team -- 'team_projection'),
#              100 = mejor equipo proyectado, 0 = peor.
# Pesos confirmados por Miguel via AskUserQuestion (24/09/2026), tras revisar
# una simulacion con jugadores reales de los 3 escenarios: 50% Q_liga / 20%
# R_equipo / 30% T_equipo.
# Leyma Coruña y Monbus Obradoiro (ascendidos de Primera FEB) no tienen
# NetRtg real 25-26 -> sin team_projection -> sin T_equipo. Primera prueba
# (repartir el 30% entre Q_liga/R_equipo, sin ningun freno de equipo) disparaba
# a Brandon Childress (Obradoiro) al #1 de TODA la liga, por delante de
# Tavares -- un ascendido sin ranking probado en ACB no deberia poder llegar
# ahi solo por calidad individual. Corregido (confirmado por Miguel,
# 24/09/2026): T_equipo NEUTRO (50, ni beneficio ni castigo -- "equipo de
# mitad de tabla" mientras no hay dato real) para estos 2 equipos, MISMOS
# pesos 50/20/30 que el resto de la liga.
# rating_base NO cambia con esta reforma -- sigue siendo el percentil crudo
# de produccion propia, sin ningun ajuste, tal y como ya lo usan las fichas
# de bajas (baja_mas_sensible).
# ============================================================================
W_Q_LIGA, W_R_EQUIPO, W_T_EQUIPO = 0.50, 0.20, 0.30
T_EQUIPO_NEUTRO_ASCENDIDOS = 50.0  # Coruña/Obradoiro: sin T_equipo real -> percentil neutro

# 1) ranking de equipo por NetRtg proyectado 26/27 (solo los equipos con
#    team_projection real -- los 2 ascendidos quedan fuera del ranking)
_team_proj_rows = [(t, td['team_projection']['netrtg_proyectado_26_27'])
                    for t, td in TEAM_DATA.items() if td.get('team_projection')]
_team_proj_rows.sort(key=lambda x: -x[1])
_N_TEAMS_RANKED = len(_team_proj_rows)
_TEAM_RANK = {t: i + 1 for i, (t, _) in enumerate(_team_proj_rows)}

def _t_equipo_pctl(team_name):
    r = _TEAM_RANK.get(team_name)
    if r is None or _N_TEAMS_RANKED < 2:
        return None
    return 100.0 * (_N_TEAMS_RANKED - r) / (_N_TEAMS_RANKED - 1)

# 2) pool de calidad (rating_0_100 en este punto, ver nota arriba) por
#    posicion, para el percentil de liga Q_liga
_QUALITY_POOL_BY_POS = {}
for _td in TEAM_DATA.values():
    for _p in _td['roster_26_27']:
        if _p.get('rating_0_100') is not None and pd.notna(_p.get('pos_group')):
            _QUALITY_POOL_BY_POS.setdefault(_p['pos_group'], []).append(_p['rating_0_100'])
_QUALITY_POOL_BY_POS = {pos: np.array(vals) for pos, vals in _QUALITY_POOL_BY_POS.items()}

# 3) combinar los 3 percentiles equipo a equipo (R_equipo necesita el roster
#    completo de CADA equipo) y comprimir -- esto REEMPLAZA el compress_2k
#    del roster que build_team ya NO aplica (ver paso 10 de build_team).
for _team_name, _td in TEAM_DATA.items():
    _roster = [p for p in _td['roster_26_27'] if p.get('rating_0_100') is not None]
    _t_pctl = _t_equipo_pctl(_team_name)
    _n_team = len(_roster)
    _roster_sorted = sorted(_roster, key=lambda p: -p['rating_0_100'])
    for _rank, _p in enumerate(_roster_sorted, start=1):
        _q_pool = _QUALITY_POOL_BY_POS.get(_p.get('pos_group'))
        _q_liga_pctl = pctl(_q_pool, _p['rating_0_100']) if _q_pool is not None else np.nan
        if pd.isna(_q_liga_pctl):
            _q_liga_pctl = 50.0
        _r_equipo_pctl = 100.0 * (_n_team - _rank) / (_n_team - 1) if _n_team > 1 else 100.0
        _w_q, _w_r, _w_t = W_Q_LIGA, W_R_EQUIPO, W_T_EQUIPO
        _t_component = _t_pctl if _t_pctl is not None else T_EQUIPO_NEUTRO_ASCENDIDOS
        _rating_pre = _w_q * _q_liga_pctl + _w_r * _r_equipo_pctl + _w_t * _t_component
        _p['q_liga_pctl'] = round(_q_liga_pctl, 1)
        _p['r_equipo_pctl'] = round(_r_equipo_pctl, 1)
        _p['t_equipo_pctl'] = round(_t_pctl, 1) if _t_pctl is not None else None
        _p['ecosistema_pesos'] = f"{_w_q*100:.0f}/{_w_r*100:.0f}/{_w_t*100:.0f}"
        _p['rating_0_100_raw'] = round(_rating_pre, 1)
        _p['rating_0_100'] = compress_2k(_rating_pre)

# ---- "lo que se espera de el" -- se calcula aqui, en un pase final sobre
#      TEAM_DATA ya completo, para poder leer con seguridad los campos que
#      build_team rellena en varios pasos distintos (crowding, euroliga...).
for _team_data in TEAM_DATA.values():
    for _p in _team_data['roster_26_27']:
        _p['expectativa'] = build_expectativa(_p)

# ---- suelo manual de rating (pedido explicito de Miguel) -- Max Shulga tuvo
#      buenos numeros en G League que Miguel va a actualizar el; mientras
#      tanto, su rating no puede quedar por debajo del de Mo Gueye. Se aplica
#      como ultimo paso, ya con los dos equipos construidos. ----
RATING_FLOOR_OVERRIDE = {
    'Real Madrid': {'Max Shulga': ('Valencia Basket', 'Mo Gueye')},
}
for _team, _floors in RATING_FLOOR_OVERRIDE.items():
    for _player_name, (_ref_team, _ref_player) in _floors.items():
        _ref_rating = next((p['rating_0_100'] for p in TEAM_DATA[_ref_team]['roster_26_27'] if p['player'] == _ref_player), None)
        if _ref_rating is None:
            continue
        for _p in TEAM_DATA[_team]['roster_26_27']:
            if _p['player'] == _player_name and (_p['rating_0_100'] is None or _p['rating_0_100'] < _ref_rating):
                _p['rating_floor_note'] = (f"Suelo aplicado: no puede ir por debajo de {_ref_player} "
                    f"({round(_ref_rating,1)}) -- pendiente de actualizar con datos nuevos de {_player_name}.")
                _p['rating_0_100'] = round(float(_ref_rating), 1)

# ---- ajuste manual de rating para bajas (pedido explicito de Miguel) -- el
#      modelo calcula a Hezonja con rating_base=75.4 (produccion pura de la
#      25/26 en Real Madrid), pero fue el MVP de la ACB esa temporada: Miguel
#      pide subirlo por encima de 90. Se aplica ANTES del bucle de resumen de
#      mas abajo, que calcula 'baja_mas_sensible' a partir de rating_0_100.
#      Jean Montero (Valencia -> Olympiacos) se añade el 03/10/2026: el
#      modelo lo dejaba en 85.5/88.0 porque solo jugo 20.5 MPG en Valencia
#      (produccion excelente por minuto -- PM40 9.6, atributos 83-92 en casi
#      todo -- pero el percentil de calidad pesa sobre todo volumen, no solo
#      eficiencia, y unos minutos limitados lo penalizan). Miguel considera
#      que esa cifra no refleja ni de lejos su nivel real ("no puede ser que
#      Montero este en un 86 cuando es Jesucristo") -- mismo criterio que
#      con Hezonja: el box-score de ACB no capta bien a un jugador que no
#      jugo con galones de titular pero es una referencia clara. ----
BAJA_RATING_OVERRIDE = {
    'Real Madrid': {'Mario Hezonja': {'rating_base': 91.5, 'rating_0_100': 96.0}},
    'Valencia Basket': {'Jean Montero': {'rating_base': 90.0, 'rating_0_100': 95.5}},
}
for _team, _players in BAJA_RATING_OVERRIDE.items():
    for _b in TEAM_DATA[_team]['bajas']:
        if _b['player'] in _players:
            _vals = _players[_b['player']]
            _b['rating_override_note'] = (f"Ajuste manual: el modelo "
                f"(basado solo en produccion propia, penalizado por minutos limitados) le daba "
                f"{_b.get('rating_base')} -- su nivel real es muy superior.")
            _b['rating_base'] = _vals['rating_base']
            _b['rating_0_100'] = _vals['rating_0_100']

# ============================================================================
# ETIQUETAS ESPECIALES de Miguel (fichero de arquetipos corregido, ver
# ARQUETIPO_MIGUEL_BY_KEY / ETIQUETAS_BY_KEY al principio del script):
#   1) Sustituye el arquetipo (role/role_es) calculado por el modelo por el
#      de Miguel donde dio uno valido -- y recalcula archetypes_new (la
#      "Matriz de arquetipos" agrupa por p['role'], hay que rehacerla tras
#      el cambio).
#   2) Etiqueta 'lesionado'/'pocos partidos' -> reusa los flags que ya
#      existian (lesionado/low_sample), penalizan la 'consistencia' de
#      equipo via fiabilidad_jugador() mas abajo.
#   3) Etiqueta 'referencia' (Jugador referencia / Referencia interior /
#      Referencia exterior) -> ajuste de rating explicito, pedido literal de
#      Miguel (03/10/2026): "alguien que es referencia es el mejor de su
#      equipo o como minimo top 3". Se calcula en UN solo paso (sin iterar)
#      para evitar que dos 'referencia' del mismo equipo se empujen entre si
#      sin converger: se fija un suelo = rating del jugador NO-referencia que
#      ocuparia la ultima plaza del top-3 si no existiera el ajuste, y se
#      sube a cada 'referencia' por encima de ese suelo (con espaciado propio
#      para conservar su orden relativo entre ellos). Maximo observado en los
#      datos de Miguel: 3 'referencia' en un mismo equipo (Unicaja) -- caben
#      justo en un top-3, no hay equipo con mas etiquetas de las que caben.
# ============================================================================
LESIONADO_TAGS = ('lesionado',)
POCOS_PARTIDOS_TAGS = ('pocos partidos',)
REFERENCIA_TAG = 'referencia'
REFERENCIA_MIN_RANK = 3
# NUEVO (24/09/2026, a peticion de Miguel: "necesito que lo tengas en
# cuenta tanto para hacerlo visible, como en roles como en ratings.
# Deberian ajustar roles y no lo hacen"): hasta ahora solo 'referencia' y
# 'lesionado'/'pocos partidos' tenian ALGUN efecto -- y ninguna etiqueta se
# mostraba en el dashboard, asi que no habia forma de comprobarlo a simple
# vista. Se anade: (a) las etiquetas se guardan SIEMPRE visibles en la
# ficha del jugador (chip), tengan o no efecto numerico; (b) una tabla
# EXPLICITA etiqueta->efecto, para que cada una se pueda auditar. Sobre
# "roles": la columna "Arquetipo (Miguel)" (ARQUETIPO_MIGUEL_BY_KEY, ya
# aplicada arriba) es la que fija el rol de cada jugador y es INDEPENDIENTE
# de "Etiqueta especial" -- se ha revisado fila a fila el csv y en TODOS
# los casos de 'Anotador explosivo' el arquetipo de Miguel ya refleja un
# rol anotador (Anotador / Anotador de elite), asi que no hace falta que la
# etiqueta fuerce nada mas ahi; se deja constancia visible de ese cruce en
# vez de aplicar un segundo ajuste de rol que ya estaria hecho.
LIDER_TAG = 'lider'
TALENTO_TAG = 'talento especial'
DEBUTANTE_TAG = 'debutante'
IMPACTO_DEF_TAG = 'impacto defensivo'
ANOTADOR_EXPLOSIVO_TAG = 'anotador explosivo'
ALTO_POTENCIAL_TAG = 'alto potencial'
LESIONADO_LARGA_TAG = 'lesionado de larga duracion'  # norm() ya quita acentos: 'duración'->'duracion'
LIDER_BONUS = 2.0         # liderazgo -- intangible, sin señal de boxscore: ajuste pequeño y editorial
TALENTO_BONUS = 1.5       # techo por encima de la produccion actual -- ajuste pequeño y editorial
IMPACTO_DEF_BONUS = 8.0   # boost directo al atributo Defensa (no al rating global) -- 1 caso, Edy Tavares
# ANOTADOR_EXPLOSIVO_BONUS (24/09/2026, a peticion de Miguel sobre Justin
# Jaworski: "ten en cuenta su etiqueta, su valoracion debe subir"): esta
# etiqueta era "solo visible" (el rol ya la reflejaba via Arquetipo Miguel)
# -- pasa a dar tambien un empujon de rating pequeño y sistematico, igual
# que 'lider'/'talento especial', para TODOS los jugadores con esta
# etiqueta (no solo Jaworski, para que la regla sea consistente y auditable
# en vez de un parche puntual).
ANOTADOR_EXPLOSIVO_BONUS = 3.0
# LESIONADO_LARGA_PENALTY (24/09/2026, a peticion de Miguel sobre Moussa
# Diagne: "ponle etiqueta de lesionado de larga duracion. Eso deberia
# bajarle rating, como a Garuba"): hasta ahora 'lesionado' (cualquier
# variante) solo penalizaba la FIABILIDAD de equipo, nunca el rating
# individual del jugador -- Miguel asumia que si lo hacia. Se separa: la
# lesion "de la temporada 25/26" (recuperable, ya se refleja sola en una
# produccion de boxscore mas baja) sigue sin tocar el rating individual;
# la lesion "de larga duracion" (Garuba, y ahora Diagne) SI baja el rating
# individual, ademas de la fiabilidad de equipo que ya tenian las dos.
LESIONADO_LARGA_PENALTY = 12.0
FIABILIDAD_PENALTY_DEBUTANTE = 15.0  # debut en la competicion/nivel -- riesgo de adaptacion (usado
# aqui y reutilizado mas abajo por fiabilidad_jugador()/consistencia de equipo -- definida ya aqui
# porque este bloque se ejecuta antes que esa funcion en el script).

for _team_name, _td in TEAM_DATA.items():
    # -- 1) arquetipo + etiquetas por jugador --
    for _p in _td['roster_26_27']:
        _key = (_team_name, norm(_p['player']))
        _tags = ETIQUETAS_BY_KEY.get(_key, [])
        _p['etiquetas_especiales'] = _tags
        _new_role = ARQUETIPO_MIGUEL_BY_KEY.get(_key)
        if _new_role and _new_role != _p.get('role'):
            _p['role_model_note'] = f"Arquetipo corregido manualmente (el modelo daba: {role_es(_p.get('role')) or 'Sin clasificar'})."
            _p['role'] = _new_role
            _p['role_es'] = role_es(_new_role)
        _tags_norm = [norm(t) for t in _tags]  # norm() ya quita acentos y pasa a minuscula -- 'Líder' -> 'lider'
        _efecto_notas = []
        if any(LESIONADO_LARGA_TAG in tn for tn in _tags_norm):
            _p['lesionado'] = next((t for t in _tags if 'lesionado' in norm(t)), True)
            if _p.get('rating_0_100') is not None:
                _p['rating_0_100'] = round(max(1.0, _p['rating_0_100'] - LESIONADO_LARGA_PENALTY), 1)
            _efecto_notas.append(f'Rating -{LESIONADO_LARGA_PENALTY:.0f} y fiabilidad de equipo penalizada (lesión de larga duración)')
        elif any(lt in tn for tn in _tags_norm for lt in LESIONADO_TAGS):
            _p['lesionado'] = next((t for t in _tags if 'lesionado' in norm(t)), True)
            _efecto_notas.append('Fiabilidad de equipo penalizada (lesión) -- el rating individual no se toca: la produccion ya reducida de esta temporada se refleja sola')
        if any(pt in tn for tn in _tags_norm for pt in POCOS_PARTIDOS_TAGS):
            _p['low_sample'] = True
            _efecto_notas.append('Fiabilidad de equipo penalizada (muestra corta 25/26)')
        if any(DEBUTANTE_TAG in tn for tn in _tags_norm):
            _p['debutante'] = True
            _efecto_notas.append(f'Fiabilidad de equipo -{FIABILIDAD_PENALTY_DEBUTANTE:.0f} (debut en la competición/nivel)')
        _bonus = 0.0
        if any(LIDER_TAG in tn for tn in _tags_norm):
            _bonus += LIDER_BONUS
            _efecto_notas.append(f'Rating +{LIDER_BONUS:.1f} (liderazgo)')
        if any(TALENTO_TAG in tn for tn in _tags_norm):
            _bonus += TALENTO_BONUS
            _efecto_notas.append(f'Rating +{TALENTO_BONUS:.1f} (talento especial)')
        if any(ANOTADOR_EXPLOSIVO_TAG in tn for tn in _tags_norm):
            _bonus += ANOTADOR_EXPLOSIVO_BONUS
            _efecto_notas.append(f'Rating +{ANOTADOR_EXPLOSIVO_BONUS:.1f} (anotador explosivo)')
        if _bonus and _p.get('rating_0_100') is not None:
            _p['rating_0_100'] = round(min(99.0, _p['rating_0_100'] + _bonus), 1)
        if any(IMPACTO_DEF_TAG in tn for tn in _tags_norm) and _p.get('atributos') and _p['atributos'].get('defensa') is not None:
            _p['atributos']['defensa'] = round(min(100.0, _p['atributos']['defensa'] + IMPACTO_DEF_BONUS), 1)
            _efecto_notas.append(f'Defensa +{IMPACTO_DEF_BONUS:.0f} (impacto defensivo, atributo de equipo)')
        if any(REFERENCIA_TAG in tn for tn in _tags_norm):
            _efecto_notas.append('Rating con suelo top-3 del equipo (ver detalle más abajo)')
        if any(ALTO_POTENCIAL_TAG in tn for tn in _tags_norm):
            _efecto_notas.append('Solo visible: proyección de futuro, no cambia el rating de esta temporada')
        if _tags and not _efecto_notas:
            _efecto_notas.append('Solo visible (sin efecto numérico definido para esta etiqueta todavía)')
        _p['etiquetas_efecto'] = _efecto_notas
    # recalcula archetypes_new (agrupa por p['role'], que puede haber cambiado arriba)
    _new_archetypes_new = {}
    for _p in _td['roster_26_27']:
        _new_archetypes_new.setdefault(_p['role'], []).append(_p['player'])
    _td['archetypes_new'] = _new_archetypes_new

    # -- 2) suelo de rating para 'referencia' (top-3 minimo del equipo) --
    _rated = [p for p in _td['roster_26_27'] if p.get('rating_0_100') is not None]
    _ref = sorted(
        [p for p in _rated if any(REFERENCIA_TAG in t.lower() for t in p.get('etiquetas_especiales', []))],
        key=lambda p: -p['rating_0_100'])
    if _ref:
        _ref_ids = {id(p) for p in _ref}
        _non_ref = sorted([p for p in _rated if id(p) not in _ref_ids], key=lambda p: -p['rating_0_100'])
        _k = len(_ref)
        if _k >= REFERENCIA_MIN_RANK:
            _floor = _non_ref[0]['rating_0_100'] if _non_ref else 0.0
        else:
            _idx = REFERENCIA_MIN_RANK - _k - 1  # posicion (0-indexed) del (3-k)-esimo mejor no-referencia
            if _non_ref and _idx < len(_non_ref):
                _floor = _non_ref[_idx]['rating_0_100']
            elif _non_ref:
                _floor = _non_ref[-1]['rating_0_100']
            else:
                _floor = 0.0
        for _i, _p in enumerate(_ref):
            _target = round(min(99.0, _floor + 0.3 * (_k - _i)), 1)
            if _p['rating_0_100'] < _target:
                _p['rating_referencia_note'] = (f"Ajustado a top-{REFERENCIA_MIN_RANK} del equipo por etiqueta "
                    f"'referencia' (el modelo daba {_p['rating_0_100']}).")
                _p['rating_0_100'] = _target

# ============================================================================
# CORRECCIONES MANUALES DE RATING -- roster (Miguel, chat 24/09/2026).
# Mismo patron que BAJA_RATING_OVERRIDE (Hezonja/Montero) pero para
# jugadores del roster 26/27 (no bajas). Dos modos:
#   'floor' -- sube el rating SOLO si esta por debajo del valor dado (nunca
#              baja a nadie con este modo).
#   'set'   -- fija el rating exactamente al valor dado (puede subir O
#              bajar -- se usa cuando Miguel da un numero concreto, o pide
#              explicitamente bajar a alguien).
# Cada nota reproduce el motivo literal que dio Miguel. Los "top-N de
# [equipo]" (Cancar top-6 Burgos, Obasohan top-3 Burgos, Akinjo el mejor de
# Andorra) se calculan como el valor del jugador en ese puesto ENTRE EL
# RESTO del roster (sin contar a otros jugadores con su propia correccion
# en la misma tanda) + 0.5, para que ocupen ese puesto exacto sin
# sobrepasar al de encima.
# ============================================================================
_ROSTER_OVERRIDE_RAW = [
    ('Recoletas Salud San Pablo Burgos', 'Vlatko Cancar', 'floor', 56.7,
     "Top-6 de Burgos pese a las dudas por la lesión -- experiencia NBA larga."),
    ('Recoletas Salud San Pablo Burgos', 'Retin Obasohan', 'floor', 71.4,
     "Top-3 de Burgos."),
    ('Recoletas Salud San Pablo Burgos', 'Dani Díez', 'set', 51.0,
     "Bonus de experiencia (+6) -- 'no lo hagas de menos'."),
    ('Casademont Zaragoza', 'Guillem Vives', 'set', 52.2,
     "Bonus de experiencia (+6) -- 'no lo hagas de menos'."),
    ('Casademont Zaragoza', 'Caleb Homesley', 'set', 87.0,
     "'Es un 87 de manual'."),
    ('Kids&Us Manresa', 'Pierre Oriola', 'set', 58.6,
     "Bonus de experiencia (+6) -- 'no lo hagas de menos'."),
    ('Kids&Us Manresa', 'Rafael Villar', 'set', 56.2,
     "'Sube de rol' -- ajuste provisional +6 en espera de confirmar el arquetipo concreto al que sube."),
    ('Kids&Us Manresa', 'Pablo Tamba', 'set', 51.0,
     "'Al nivel de Nogues o Mari'."),
    ('Ilerna Lleida', 'John Shurna', 'set', 51.4,
     "Bonus de experiencia (+6) -- 'no lo hagas de menos'."),
    ('Ilerna Lleida', 'Oriol Paulí', 'floor', 74.0,
     "'Ponle más, es jugador importante de Lleida'."),
    ('Ilerna Lleida', 'James Batemon', 'set', 87.0,
     "'Igual' que Homesley -- 87."),
    ('MoraBanc Andorra', 'Leon Radosevic', 'set', 52.3,
     "Bonus de experiencia (+6) -- 'no lo hagas de menos'."),
    ('MoraBanc Andorra', 'Kassius Robertson', 'set', 56.7,
     "'Será mejor' -- ajuste +6."),
    ('MoraBanc Andorra', 'Owen Aquino', 'set', 51.0,
     "'Al nivel de Nogues o Mari'."),
    ('MoraBanc Andorra', 'James Akinjo', 'floor', 67.0,
     "'Es el mejor de Andorra'."),
    ('Kosner Baskonia', 'Tadas Sedekerskis', 'set', 62.0,
     "'Va a ir a mejor, no le pongas tan poco' -- ajuste +10."),
    ('Kosner Baskonia', 'Chris Duarte', 'floor', 75.0,
     "'No debería bajar del 75'."),
    ('Kosner Baskonia', 'Kenneth Faried', 'set', 75.0,
     "'Bájalo a 75'."),
    ('Kosner Baskonia', 'Kobi Simmons', 'set', 82.0,
     "'Un 82'."),
    ('Kosner Baskonia', 'A.J. Lawson', 'set', 83.0,
     "'83'."),
    ('Kosner Baskonia', 'D.J. Stewart', 'set', 83.0,
     "'83'."),
    ('Asisa Joventut', "Eli John N'Diaye", 'floor', 75.0,
     "'No puede bajar del 75, viene de año malo por lesiones'."),
    ('Asisa Joventut', 'Boogie Ellis', 'floor', 70.0,
     "'No baja del 70'."),
    ('Surne Bilbao', 'Manex Ansorregui', 'set', 44.0,
     "'Es flojo, ponlo más abajo' -- ajuste -10."),
    ('Surne Bilbao', 'Bastien Vautier', 'floor', 70.0,
     "'No baja de 70, viene de jugar Euroliga y va a un BCL'."),
    ('Valencia Basket', 'Lucas Marí', 'set', 50.0,
     "'Es el menos impactante de Valencia, ponle un 50'."),
    ('Valencia Basket', 'Neal Sako', 'set', 78.0,
     "'Bájalo a 78'."),
    ('Barça', 'Agustin Ubal', 'set', 58.9,
     "'Da demasiado salto como para tener casi un 70' -- ajuste -10."),
    ('Unicaja', 'Ignas Bradzeikis', 'set', 79.2,
     "'¿Por qué solo un 69?' -- ajuste +10."),
    ('La Laguna Tenerife', 'Ethan Happ', 'floor', 75.0,
     "'No debería bajar del 75'."),
    ('Río Breogán', 'Francis Alonso', 'set', 80.0,
     "'Un 80'."),
]
ROSTER_RATING_OVERRIDE = {(team, norm(player)): (mode, val, nota) for team, player, mode, val, nota in _ROSTER_OVERRIDE_RAW}

for _team_name, _td in TEAM_DATA.items():
    for _p in _td['roster_26_27']:
        _key = (_team_name, norm(_p['player']))
        _ov = ROSTER_RATING_OVERRIDE.get(_key)
        if _ov is None or _p.get('rating_0_100') is None:
            continue
        _mode, _val, _nota = _ov
        if _mode == 'floor' and _p['rating_0_100'] >= _val:
            continue
        _antes = _p['rating_0_100']
        _p['rating_0_100'] = round(_val, 1)
        _p['rating_override_note'] = f"Ajuste manual (24/09/2026): {_nota} El modelo daba {_antes}."

# ============================================================================
# REGLA GENERAL de coherencia entre jugadores top de cada equipo (Miguel,
# 24/09/2026): "Que no haya ningún equipo con nadie top 1 por debajo de 80,
# top 2 por debajo de 75 y top 3 por debajo de 70". Se aplica DESPUES de
# todo lo demas (etiquetas, referencia, correcciones manuales de arriba)
# como red de seguridad para CUALQUIER equipo, no solo los nombrados por
# Miguel -- y solo SUBE (nunca baja a nadie por estar mal posicionado). El
# ranking que decide quien es top-1/2/3 se fija ANTES de aplicar ningun
# ajuste de esta regla (no se recalcula tras cada subida) para que sea
# siempre "el jugador que YA era top-N", no uno que haya subido de puesto
# por la propia regla.
# ============================================================================
TOPN_FLOORS = {1: 80.0, 2: 75.0, 3: 70.0}
for _team_name, _td in TEAM_DATA.items():
    _rated_topn = sorted([p for p in _td['roster_26_27'] if p.get('rating_0_100') is not None],
                          key=lambda p: -p['rating_0_100'])
    for _rank, _floor_val in TOPN_FLOORS.items():
        if len(_rated_topn) < _rank:
            continue
        _p = _rated_topn[_rank - 1]
        if _p['rating_0_100'] < _floor_val:
            _p['rating_topn_note'] = (f"Ajustado: ningún top-{_rank} de un equipo puede ir por debajo de "
                f"{_floor_val:.0f} (regla general de coherencia; el modelo daba {_p['rating_0_100']}).")
            _p['rating_0_100'] = _floor_val

# ============================================================================
# Proyeccion de victorias COHERENTE CON EL CALENDARIO (log5), pedido
# explicito de Miguel (24/09/2026): "Solo se pueden ganar 306 partidos en
# total [18 equipos x 34 partidos / 2] y no creo que me salgan las cuentas".
# Tenia razon: el metodo anterior calculaba el % de victorias de cada
# equipo de forma INDEPENDIENTE (formula pitagorica sobre su propio PF/PA
# proyectado, como si jugase siempre contra un rival "medio" generico) --
# eso NO es zero-sum. Sumando los 16 equipos con proyeccion daba 355.9
# victorias repartidas en 544 partidos-equipo, un numero que no puede darse
# en una liga real (cada partido reparte EXACTAMENTE 1 victoria entre los 2
# equipos que lo juegan).
#
# Se sustituye por una simulacion de calendario completo: round-robin a
# doble vuelta (34 partidos/equipo, los 18 equipos entre si, 306 partidos
# en total) usando el metodo log5 (Bill James). A partir del "win% de cada
# equipo contra un rival medio" -- que es EXACTAMENTE lo que ya daba la
# formula pitagorica independiente, se reutiliza tal cual como fuerza de
# entrada, no se tira el trabajo anterior -- se calcula la probabilidad de
# victoria de cada partido CONCRETO entre 2 equipos reales de la liga:
#     P(A gana a B) = (pA - pA*pB) / (pA + pB - 2*pA*pB)
# Sumando esa probabilidad x2 (ida y vuelta) sobre los 17 rivales de cada
# equipo se obtienen sus victorias esperadas. Como P(A gana a B) +
# P(B gana a A) = 1 en cada partido concreto, la suma total da EXACTAMENTE
# 18*34/2 = 306 victorias repartidas en la liga -- sin normalizar nada a
# mano, es una propiedad matematica del metodo.
#
# Incluye a Leyma Coruña y Monbus Obradoiro (ascendidos de Primera FEB),
# pedido explicito de Miguel ("Tienes que sumar tambien a Coruña y
# Obradoiro"): no tienen team_projection real (sin NetRtg/ORtg/DRtg propios
# de la ACB 25/26), pero SI tienen un NetRtg estimado por traduccion de
# nivel FEB->ACB (_teams_dash[...]['netrtg'], el mismo que ya se muestra en
# rating_pasado.netrtg) -- se construye su "win% vs rival medio" con la
# MISMA formula pitagorica que los otros 16, centrando su ORtg/DRtg en la
# MEDIA de la liga 26/27 (no tienen ORtg/DRtg propio real) en vez del
# ORtg/DRtg de la temporada pasada del propio equipo.
# ============================================================================
def log5(pa, pb):
    denom = pa + pb - 2 * pa * pb
    if abs(denom) < 1e-9:
        return 0.5
    return (pa - pa * pb) / denom

LEAGUE_GP = 34
_stay_mask = ~sm['Nombre equipo'].isin(['Coviran Granada', 'Dreamland Gran Canaria'])
_LEAGUE_AVG_ORTG = float(sm.loc[_stay_mask, 'OER'].mean())
_LEAGUE_AVG_POSS = float(sm.loc[_stay_mask, 'POSS'].mean())

_POWER = {}  # equipo (nombre 26/27, clave de TEAM_DATA) -> win% pitagorico vs rival medio
for _t, _td_pow in TEAM_DATA.items():
    _tp = _td_pow.get('team_projection')
    if _tp:
        _POWER[_t] = _tp['wins_26_27_proyectadas'] / _tp['gp']
    else:
        # ascendido de Primera FEB: sin ORtg/DRtg propio real -- se centra
        # en la media de la liga 26/27 +/- la mitad de su NetRtg estimado
        # (misma logica que ortg_new/drtg_new de los otros 16, pero sin un
        # ORtg/DRtg de partida propio, se usa el de la liga).
        _netrtg_est = _teams_dash[_t]['netrtg']
        _ortg_est = _LEAGUE_AVG_ORTG + _netrtg_est / 2
        _drtg_est = _LEAGUE_AVG_ORTG - _netrtg_est / 2
        _pts_for_est = _ortg_est / 100 * _LEAGUE_AVG_POSS
        _pts_against_est = _drtg_est / 100 * _LEAGUE_AVG_POSS
        _wp_est, _ = pythag_wins(_pts_for_est, _pts_against_est, LEAGUE_GP)
        _POWER[_t] = _wp_est

_TEAMS_18 = list(_POWER.keys())
WINS_LIGA = {}
for _t in _TEAMS_18:
    _w = 0.0
    for _o in _TEAMS_18:
        if _o == _t:
            continue
        _w += 2 * log5(_POWER[_t], _POWER[_o])
    WINS_LIGA[_t] = round(_w, 2)
WINPCT_LIGA = {t: w / LEAGUE_GP for t, w in WINS_LIGA.items()}

_total_check = sum(WINS_LIGA.values())
print(f"\n[CHEQUEO] Suma total de victorias proyectadas 26/27 (18 equipos, "
      f"calendario completo, {len(_TEAMS_18)} equipos x {LEAGUE_GP} partidos / 2): "
      f"{_total_check:.1f} (tiene que dar exactamente {18*34//2})")

# Ranking 26/27 sobre los 18 equipos REALES (para posicion_proyectada_26_27
# y para las estrellas -- ver mas abajo). Ojo: NO sustituye a _TEAM_RANK
# (solo 16 equipos, ranking por NetRtg crudo sin log5) que se sigue usando
# tal cual para el T_equipo del RATING INDIVIDUAL de jugador -- esa pieza
# ya esta confirmada por Miguel via AskUserQuestion (24/09/2026) con
# Coruña/Obradoiro en T_equipo neutro (50), y no es lo que esta en cuestion
# aqui (esto es la proyeccion de VICTORIAS DE EQUIPO, un calculo distinto).
_rank_rows_18 = sorted(_TEAMS_18, key=lambda t: -WINS_LIGA[t])
TEAM_RANK_18 = {t: i + 1 for i, t in enumerate(_rank_rows_18)}
print("Ranking proyectado 26/27 (18 equipos, victorias esperadas):")
for _t in _rank_rows_18:
    print(f"  #{TEAM_RANK_18[_t]:>2} {_t:<35} {WINS_LIGA[_t]:>5.1f}-{34-WINS_LIGA[_t]:<5.1f} ({WINPCT_LIGA[_t]*100:.1f}%)")

# ---- resumen por equipo para la seccion "Ranking de equipos": top 3
#      esperados, mejor fichaje, baja mas sensible y perfil de atributos
#      (rating esperado en cada parametro) -- pedido explicito de Miguel. ----
TEAM_DESCRIPCIONES = {
    'Valencia Basket': 'Bloque de bases que dirige el ataque (Shorts, Corbalán, Mirotic) sobre una plantilla profunda y una defensa que ya era de las mejores de la liga.',
    'Real Madrid': 'Con Pedro Martínez al mando, gana peso el juego de bases (Campazzo, Maledon, Llull) mientras Tavares se consolida como referencia interior en ambos lados de la pista.',
}
TEAM_RATING_DECAY = 0.80  # cada puesto del ranking interno pesa el 80% del
# anterior en el rating de equipo (sustituye la ponderacion por minutos --
# pedido explicito de Miguel, 03/10/2026: "hazlo facil y dame la media
# ponderada de una manera que los primeros valgan mas que los ultimos y que
# se note la diferencia de calidad"). Con este decaimiento geometrico, en la
# practica solo pesa de verdad el nucleo de rotacion (jugador 1: peso 1,
# jugador 2: 0.80, jugador 3: 0.64, jugador 4: 0.51... jugador 9: 0.13,
# jugador 15: 0.035): el fondo de banquillo apenas mueve la media, y equipos
# con mas estrellas arriba en el ranking se separan mas claramente de los
# que solo tienen profundidad. Sustituye tambien la ponderacion anterior por
# minutos esperados (que resolvia la distorsion de tamaño de plantilla pero
# no daba la separacion de calidad que Miguel pedia ahora).

def _ranked_weights(players):
    """Ordena la plantilla por rating_0_100 (calidad global ya calculada) de
    mayor a menor y devuelve, por jugador, el peso geometrico segun su puesto
    en ese ranking. Se usa el MISMO ranking/pesos para los 6 atributos del
    equipo -- es lo que hace que el criterio sea "facil": un solo orden por
    plantilla, no uno distinto por atributo."""
    ranked = sorted([p for p in players if p.get('rating_0_100') is not None],
                     key=lambda p: -p['rating_0_100'])
    return {id(p): TEAM_RATING_DECAY ** i for i, p in enumerate(ranked)}

def _avg_axis(players, axis, weights):
    """SUMA ponderada (NO media) -- pedido explicito de Miguel, 03/10/2026:
    "no deberia ser tanto un peso sino una suma. No pueden ser numeros tan
    bajos". Una media siempre queda acotada 0-100 (el mismo rango que UN
    jugador), así que una plantilla profunda y una corta con el mismo nivel
    medio salian iguales -- sumar SI refleja tener mas nivel acumulado (mas
    jugadores buenos, no solo el mismo promedio), y da numeros mas grandes y
    mas separados entre equipos. El peso geometrico (ver _ranked_weights)
    sigue haciendo que el fondo de banquillo apenas sume nada."""
    pares = [(weights[id(p)], p['atributos'][axis]) for p in players
              if id(p) in weights and p.get('atributos') and p['atributos'].get(axis) is not None]
    if not pares:
        return None
    return round(sum(w * v for w, v in pares), 0)

# ---- "consistencia" de equipo (pedido explicito de Miguel, confirmado via
#      AskUserQuestion 24/09/2026: "fiabilidad de la plantilla 26/27", NO
#      regularidad de resultados 25/26) -- cuanto depende la plantilla de
#      fichajes sin historial real en ACB, muestras cortas o lesiones de
#      larga duracion. Es un eje NUEVO, a nivel de jugador no existia nada
#      con este nombre. ----
FIABILIDAD_PENALTY_ALTA_EXTRANJERA = 40.0  # sin historial ACB -- la traduccion de nivel es una estimacion
FIABILIDAD_PENALTY_LOW_SAMPLE = 30.0        # muestra insuficiente la 25/26
FIABILIDAD_PENALTY_LESIONADO = 30.0         # lesion de larga duracion, disponibilidad incierta
# FIABILIDAD_PENALTY_DEBUTANTE ya esta definida mas arriba (bloque
# ETIQUETAS ESPECIALES, se usa alli tambien en las notas de efecto).

def fiabilidad_jugador(p):
    """Fiabilidad/certeza de la proyeccion de ESTE jugador para 26/27
    (0-100, 100=maxima certeza)."""
    f = 100.0
    if p.get('status') == 'alta_extranjero':
        f -= FIABILIDAD_PENALTY_ALTA_EXTRANJERA
    if p.get('low_sample'):
        f -= FIABILIDAD_PENALTY_LOW_SAMPLE
    if p.get('lesionado'):
        f -= FIABILIDAD_PENALTY_LESIONADO
    if p.get('debutante'):
        f -= FIABILIDAD_PENALTY_DEBUTANTE
    return max(0.0, f)

def _avg_consistencia(players, weights):
    """SUMA ponderada de fiabilidad_jugador (mismo criterio que _avg_axis,
    ver nota ahi) -- la fiabilidad de los jugadores con mas peso real en el
    equipo cuenta mas que la de un jugador de rotacion corta."""
    pares = [(weights[id(p)], fiabilidad_jugador(p)) for p in players if id(p) in weights]
    if not pares:
        return None
    return round(sum(w * v for w, v in pares), 0)

# ---- rating de equipo (pedido explicito de Miguel, 24/09/2026): combina 6
#      atributos -- anotacion, cuidado de balon, rebote, defensa,
#      consistencia y creacion de juego (SUSTITUYE a 'impacto', que ya no
#      forma parte de este rating de equipo -- 'impacto' sigue existiendo
#      tal cual en la ficha de CADA JUGADOR, esto es solo para el resumen de
#      equipo). Primer corte: media simple de los 6 (sin ponderar ninguno
#      por encima de otro) -- facil de ajustar si Miguel quiere pesos
#      distintos una vez vea el resultado. ----
TEAM_AXES = ['anotacion', 'cuidado_balon', 'rebote', 'defensa', 'consistencia', 'creacion']

for _team in FULL_MODEL_TEAMS:
    _roster = TEAM_DATA[_team]['roster_26_27']
    _bajas = TEAM_DATA[_team]['bajas']
    _rated = [p for p in _roster if p.get('rating_0_100') is not None]
    _top3 = sorted(_rated, key=lambda p: -p['rating_0_100'])[:3]
    _altas = [p for p in _rated if p['status'] in ('alta_acb', 'alta_extranjero')]
    _mejor_fichaje = max(_altas, key=lambda p: p['rating_0_100']) if _altas else None
    # NOTA (corregido 03/10/2026, Miguel: "no puede ser que haya bajas mas
    # sensibles en 60 -- no se de donde lo estas sacando"): antes se elegia
    # Y se mostraba con rating_base -- el percentil de produccion crudo, SIN
    # el suelo de 40 que sí tiene rating_0_100 (el que usa el resto del
    # dashboard). Una baja mediocre podia asi salir con un numero de la
    # veintena/treintena, en una escala distinta a la que ve Miguel en
    # cualquier otra ficha. Ahora usa rating_0_100 (mismo criterio/escala
    # que un jugador de la plantilla) para elegir Y para mostrar.
    _bajas_rated = [b for b in _bajas if b.get('rating_0_100') is not None]
    _baja_sensible = max(_bajas_rated, key=lambda b: b['rating_0_100']) if _bajas_rated else None
    _weights = _ranked_weights(_roster)
    _perfil = {}
    for _axis in TEAM_AXES:
        _perfil[_axis] = _avg_consistencia(_roster, _weights) if _axis == 'consistencia' else _avg_axis(_roster, _axis, _weights)
    _perfil_vals = [v for v in _perfil.values() if v is not None]
    _team_rating = round(sum(_perfil_vals) / len(_perfil_vals), 1) if _perfil_vals else None
    TEAM_DATA[_team]['resumen'] = {
        'descripcion': TEAM_DESCRIPCIONES.get(_team, ''),
        'top3': [{'player': p['player'], 'rating': p['rating_0_100'], 'role': p['role'],
                  'pos_group': p['pos_group'], 'status': p['status']} for p in _top3],
        'mejor_fichaje': ({'player': _mejor_fichaje['player'], 'rating': _mejor_fichaje['rating_0_100'],
                            'role': _mejor_fichaje['role'], 'pos_group': _mejor_fichaje['pos_group']}
                           if _mejor_fichaje else None),
        'baja_mas_sensible': ({'player': _baja_sensible['player'], 'rating': _baja_sensible['rating_0_100'],
                                'role': _baja_sensible['role'], 'pos_group': _baja_sensible['pos_group'],
                                'destino': _baja_sensible.get('destino')} if _baja_sensible else None),
        'perfil_atributos': _perfil,
        'team_rating': _team_rating,
    }

# ============================================================================
# Pedido de Miguel (03/10/2026) sobre "Ranking de equipos":
#  - estrellas (0-5, con medias) en vez del numero crudo como resumen visual
#  - percentil de cada atributo ENTRE LOS 18 EQUIPOS (no el 0-100 crudo, que
#    ahora es una SUMA sin techo fijo -- ver _avg_axis) para el grafico
#    hexagonal (si se le pasa la suma tal cual, se sale de la escala: el
#    radar asume 0-100) y para poder sacar "virtudes y defectos" (los 2 ejes
#    donde el equipo esta mejor/peor situado frente al resto de la liga, no
#    solo frente a si mismo).
#  - posicion proyectada 26/27 (mismo ranking de T_equipo, ya calculado mas
#    arriba) y marca de playoffs esperados (top 8).
# ============================================================================
TEAM_AXES_ES = {
    'anotacion': 'Anotación', 'cuidado_balon': 'Cuidado de balón', 'rebote': 'Rebote',
    'defensa': 'Defensa', 'consistencia': 'Consistencia', 'creacion': 'Creación de juego',
}

# Los 2 ascendidos de Primera FEB (roster incompleto -- solo altas, sin los
# jugadores que continuan de FEB, ver conversacion 03/10/2026) quedan FUERA
# de los pools de percentil/estrellas: comparar su perfil parcial contra
# los 16 equipos con plantilla completa no seria justo para nadie -- ni
# para ellos (roster corto = suma baja, no calidad baja) ni para el resto
# (2 outliers bajos estirarian la escala). Sus estrellas/percentiles se
# calculan igual con la MISMA formula, pero fuera del rango que fija el
# min-max de los otros 16 -- si caen por debajo del minimo, se quedan en el
# suelo de 0.5 estrellas.
_axis_pool = {ax: [] for ax in TEAM_AXES}
for _t_name, _td in TEAM_DATA.items():
    if _td.get('es_ascendido'):
        continue
    _perfil = _td['resumen']['perfil_atributos']
    for _ax in TEAM_AXES:
        if _perfil.get(_ax) is not None:
            _axis_pool[_ax].append(_perfil[_ax])
_axis_pool = {ax: np.array(vals) for ax, vals in _axis_pool.items()}

# Las ESTRELLAS y la POSICION mostradas en "Ranking de equipos" pasan a
# basarse en WINPCT_LIGA (la proyeccion de victorias coherente con el
# calendario, ver bloque log5 mas arriba) y NO en team_rating (la suma de
# atributos de plantilla) -- pedido explicito de Miguel (24/09/2026):
# "ordena el ranking y las estrellas correlacionado con lo que esperas en
# racha. No puedes esperar un 30-9 del Madrid y ponerles un 3.5". Las 2
# metricas median cosas distintas (perfil de calidad de plantilla vs.
# victorias esperadas) y podian divergir -- p.ej. el Barça salia #1
# proyectado pero solo 2.5 estrellas. team_rating SIGUE existiendo y
# mostrandose (perfil de atributos, virtudes/defectos, "Ver calculo") como
# diagnostico de COMO esta construida la plantilla, pero ya no decide el
# orden ni las estrellas -- esas las decide cuanto se espera que gane el
# equipo, que es lo que se compara al lado en el propio dashboard (V-D
# esperado) y tiene que ser coherente con las estrellas.
# A diferencia del pool de atributos (arriba, que SI excluye a los
# ascendidos por tener roster incompleto), aqui SI se incluye a Coruña y
# Obradoiro en el pool de 18: su win% ya viene de una simulacion de
# calendario completo con una fuerza estimada de forma homogenea con el
# resto (log5), no de una suma de atributos que penaliza tener pocos
# jugadores fichados todavia -- incluirlos aqui es justo y es ademas lo que
# pidio Miguel explicitamente ("Tienes que sumar tambien a Coruña y
# Obradoiro").
_WP_MIN, _WP_MAX = min(WINPCT_LIGA.values()), max(WINPCT_LIGA.values())

PLAYOFF_TOP_N = 8
LOGROS_25_26 = {
    'Valencia Basket': 'Campeón 25/26',
    'Real Madrid': 'Líder fase regular 25/26',
}

# ----------------------------------------------------------------------------
# Clasificacion REAL de la fase regular 25/26 (puestos 1-8, dados por Miguel
# 28/09/2026) -- deliberadamente separada de 'rank_estrellas' mas abajo.
# rank_estrellas/Total_estrellas (ranking_estrellas_totales.csv, "Puesto")
# salen de wins_est, que a su vez es un win% de Pythagoras calculado solo con
# PTS/Opp_PTS de season_metrics.csv (diferencial de puntos) -- es una
# ESTIMACION del rating del modelo, no el resultado real de la fase regular,
# que depende del cara a cara y desempates reales que el pipeline no tiene
# (no hay ninguna columna de victorias/derrotas reales en season_metrics.csv
# ni en ningun fichero de este pipeline). De ahi que el modelo pueda situar a
# Valencia #1 por rating y Real Madrid #3 -- mientras que en la clasificacion
# real de la fase regular fue al reves: Real Madrid #1, Valencia #2. Puestos
# 9-18 quedan pendientes (Miguel no los dio todavia) -- se dejan en None en
# vez de inventarlos; la ficha de equipo solo muestra esta clasificacion real
# cuando el puesto es conocido.
POSICION_REAL_FASE_REGULAR_25_26 = {
    'Real Madrid': 1,
    'Valencia Basket': 2,
    'Baskonia': 3,
    'UCAM Murcia': 4,
    'Barça': 5,
    'Joventut Badalona': 6,
    'Surne Bilbao Basket': 7,
    'La Laguna Tenerife': 8,
}

for _team, _td in TEAM_DATA.items():
    _perfil = _td['resumen']['perfil_atributos']
    _pctl_por_eje = {}
    for _ax in TEAM_AXES:
        _v = _perfil.get(_ax)
        _pool = _axis_pool.get(_ax)
        _p_val = pctl(_pool, _v) if (_v is not None and _pool is not None) else np.nan
        _pctl_por_eje[_ax] = round(float(_p_val), 0) if pd.notna(_p_val) else None
    _ejes_validos = [(ax, p) for ax, p in _pctl_por_eje.items() if p is not None]
    _ejes_ordenados = sorted(_ejes_validos, key=lambda t: -t[1])
    _virtudes = [{'eje': TEAM_AXES_ES[ax], 'percentil': p} for ax, p in _ejes_ordenados[:2]]
    _defectos = [{'eje': TEAM_AXES_ES[ax], 'percentil': p} for ax, p in _ejes_ordenados[-2:]] if len(_ejes_ordenados) >= 2 else []

    # estrellas: escala lineal min-max del % de victorias proyectado
    # (WINPCT_LIGA, calendario completo/log5) entre los 18 equipos, a un
    # rango de 0.5-5.0 estrellas, redondeada a la media estrella mas
    # cercana (pedido explicito de Miguel: "evalua de 0 a 5 estrellas...
    # puedes poner media estrella" -- y luego, 24/09/2026, que estrellas y
    # posicion vayan correlacionadas con las victorias esperadas).
    _wp = WINPCT_LIGA.get(_team)
    _estrellas = None
    if _wp is not None and _WP_MAX > _WP_MIN:
        _pct = max(0.0, min(1.0, (_wp - _WP_MIN) / (_WP_MAX - _WP_MIN)))
        _estrellas = round((0.5 + _pct * 4.5) * 2) / 2.0
    elif _wp is not None:
        _estrellas = 3.0

    _rank_proy = TEAM_RANK_18.get(_team)
    _playoff = (_rank_proy is not None and _rank_proy <= PLAYOFF_TOP_N)

    _td['resumen']['perfil_atributos_pctl'] = _pctl_por_eje
    _td['resumen']['virtudes'] = _virtudes
    _td['resumen']['defectos'] = _defectos
    _td['resumen']['estrellas'] = _estrellas
    _td['resumen']['posicion_proyectada_26_27'] = _rank_proy
    _td['resumen']['playoff_esperado'] = _playoff
    _td['resumen']['logro_25_26'] = LOGROS_25_26.get(_team)

# ============================================================================
# 8) Los otros equipos (sin fichero detallado): datos reales "año pasado" +
#    señal parcial de mercado
# ============================================================================
estrellas = pd.read_csv('ranking_estrellas_totales.csv', index_col=0)
estrellas.index.name = 'team'

# equipos 26/27 reales (16 con historial ACB 25-26 + 2 ascendidos de FEB, sin
# historial ACB todavia) -- NO los 18 que jugaron la 25-26 (2 de esos, Coviran
# Granada y Dreamland Gran Canaria, descienden y no jugaran la 26-27).
TEAMS_26_27 = list(_teams_dash.keys())
PROMOTED_NO_HISTORY = [k for k, v in _teams_dash.items() if v['estimado_feb']]

# Nombre de patrocinador 26/27 (el que usa mk/Miguel) para cada nombre
# canonico 25/26 de TEAMS_26_27 -- para mostrar en 'Ranking de equipos' el
# nombre actual (Kosner Baskonia, Asisa Joventut...) en vez del de la
# temporada pasada, igual que ya se hace en las fichas de jugador.
SPONSOR_NAME_FOR = {canon_team(t): t for t in FULL_MODEL_TEAMS}

teams_out = []
for team in TEAMS_26_27:
    _td = TEAM_DATA_BY_CANON.get(team)
    has_full_model = _td is not None
    is_promoted = team in PROMOTED_NO_HISTORY
    fi = fichajes.get(team)
    market_signal = None
    if fi:
        market_signal = {
            'balance_medible_gmsc': fi['balance_medible'],
            'cobertura_altas_pct': fi['cobertura_altas_pct'],
            'cobertura_bajas_pct': fi['cobertura_bajas_pct'],
            'altas_medibles': fi['altas_medibles'], 'altas_total': fi['altas_total'],
            'bajas_medibles': fi['bajas_medibles'], 'bajas_total': fi['bajas_total'],
        }
    if has_full_model and market_signal:
        # equipos con modelo completo tienen cobertura real mayor: se cuenta
        # cuantas altas quedaron realmente medidas (ACB->ACB + fuera de ACB).
        altas_medibles = _td['altas_medibles_count']
        cobertura = round(altas_medibles / market_signal['altas_total'] * 100, 1) if market_signal['altas_total'] else market_signal['cobertura_altas_pct']
        market_signal = {**market_signal, 'altas_medibles': altas_medibles, 'cobertura_altas_pct': cobertura,
                          'nota': 'cobertura ampliada con el fichero de fichajes detallado'}

    # Clave de WINS_LIGA/WINPCT_LIGA/TEAM_RANK_18 (calculados con el nombre
    # 26/27 -- sponsor -- de TEAM_DATA): 'team' aqui es el nombre CANONICO
    # 25/26 (el que usan sm/_teams_dash/estrellas.csv), hay que traducirlo.
    _sponsor_key = SPONSOR_NAME_FOR.get(team, team)
    _wins_liga = WINS_LIGA.get(_sponsor_key)
    _winpct_liga = WINPCT_LIGA.get(_sponsor_key)

    if is_promoted:
        # sin partidos reales en ACB esta temporada -- solo tenemos el NetRtg
        # estimado (traduccion FEB) que ya usa el dashboard, sin wins/estrellas
        # REALES 25/26 (no jugaron en ACB). La proyeccion 26/27 SI existe --
        # sale del mismo calendario completo (log5) que los otros 16, ver
        # bloque de victorias mas arriba -- pedido explicito de Miguel:
        # "Tienes que sumar tambien a Coruña y Obradoiro".
        rating_pasado = {
            'netrtg': round(float(_teams_dash[team]['netrtg']), 2), 'total_estrellas': None, 'rank_estrellas': None,
            'wins_est': None, 'win_pct_est': None, 'gp': int(_teams_dash[team]['gp']),
            'posicion_real_25_26': None,
            'nota': 'recien ascendido de Primera FEB -- NetRtg estimado por traduccion de nivel, sin historial real en ACB',
        }
    else:
        row_sm = sm[sm['Nombre equipo']==team].iloc[0]
        win_pct_r, wins_r = pythag_wins(row_sm['PTS'], row_sm['Opp_PTS'], row_sm['GP'])
        total_estrellas = int(estrellas.loc[team, 'Total_estrellas']) if team in estrellas.index else None
        rank = int(estrellas.loc[team, 'Puesto']) if team in estrellas.index else None
        rating_pasado = {
            'netrtg': round(float(row_sm['NetRtg']), 2), 'total_estrellas': total_estrellas, 'rank_estrellas': rank,
            'wins_est': round(float(wins_r), 1), 'win_pct_est': round(float(win_pct_r)*100, 1), 'gp': int(row_sm['GP']),
            'posicion_real_25_26': POSICION_REAL_FASE_REGULAR_25_26.get(team),
            'ppg': round(float(row_sm['PTS']) / row_sm['GP'], 1),
        }

    rating_esperado = None
    if has_full_model and _td.get('team_projection'):
        tp = _td['team_projection']
        # wins_est/win_pct_est/delta_wins YA NO salen de la formula
        # pitagorica independiente de este equipo (tp['wins_26_27_proyectadas'],
        # que no es zero-sum, ver nota junto a WINS_LIGA) -- salen de la
        # simulacion de calendario completo (log5), que SI reparte
        # exactamente 306 victorias en la liga. netrtg_proyectado/delta_netrtg
        # y el resto de metodologia (sum_gmsc, rotacion...) no cambian.
        rating_esperado = {
            'netrtg_proyectado': tp['netrtg_proyectado_26_27'],
            'delta_netrtg': tp['delta_netrtg'],
            'wins_est': _wins_liga, 'win_pct_est': round(_winpct_liga*100, 1) if _winpct_liga is not None else None,
            'wins_25_26': tp['wins_25_26_pitagoricas'],
            'delta_wins': round(_wins_liga - tp['wins_25_26_pitagoricas'], 1) if _wins_liga is not None else None,
            'sum_gmsc_old': tp['sum_gmsc_old'], 'sum_gmsc_new': tp['sum_gmsc_new'],
            'gp': tp['gp'], 'n_rotation': tp['n_rotation'],
            'ppg': tp['ppg_26_27'], 'ppg_delta': round(tp['ppg_26_27'] - tp['ppg_25_26'], 1),
            'metodologia': 'modelo completo (roster proyectado con datos reales de altas y bajas) + calendario completo (log5) para las victorias',
        }
    elif is_promoted and _wins_liga is not None:
        # NUEVO -- antes Coruña/Obradoiro se quedaban sin rating_esperado del
        # todo. Ahora SI tienen proyeccion de victorias (del mismo calendario
        # completo que el resto), aunque no tengan wins_25_26/delta_wins (no
        # jugaron la ACB el año pasado, no hay base real con la que comparar).
        rating_esperado = {
            'netrtg_proyectado': round(float(_teams_dash[team]['netrtg']), 2),
            'delta_netrtg': None,
            'wins_est': _wins_liga, 'win_pct_est': round(_winpct_liga*100, 1) if _winpct_liga is not None else None,
            'wins_25_26': None, 'delta_wins': None,
            'gp': LEAGUE_GP,
            'metodologia': 'calendario completo (log5) sobre el NetRtg estimado por traduccion de nivel FEB->ACB -- sin historial real ACB 25/26 con el que comparar',
        }

    teams_out.append({
        'team': team,
        'rating_pasado': rating_pasado,
        'rating_esperado': rating_esperado,
        'market_signal': market_signal,
        'has_full_model': has_full_model,
        'is_promoted': is_promoted,
        'resumen': _td.get('resumen') if has_full_model else None,
        'logo_key': logo_key_for(team),
        'team_sponsor': SPONSOR_NAME_FOR.get(team, team),
    })

# ============================================================================
# 10) Guardar JSON consolidado
# ============================================================================
def _default(o):
    if hasattr(o, 'item'):
        return o.item()
    return str(o)

# Solo se embeben los escudos realmente usados en roster/bajas de TODOS los
# equipos con modelo completo (no los 19 de ALL_LOGOS), para no inflar el
# JSON con escudos que no se ven.
_used_logo_keys = set()
for _team_data in TEAM_DATA.values():
    _used_logo_keys |= {p.get('logo_key') for p in _team_data['roster_26_27']}
    _used_logo_keys |= {b.get('logo_key') for b in _team_data['bajas']}
# Tambien los escudos de los 18 equipos de la seccion "Ranking de equipos"
# (antes solo se embebian los de los 2 equipos con modelo completo) -- pedido
# de Miguel: logo del equipo en cada seccion, no solo en jugadores.
_used_logo_keys |= {t.get('logo_key') for t in teams_out}
_used_logo_keys.discard(None)
LOGOS_USED = {k: ALL_LOGOS[k] for k in _used_logo_keys}
print(f"\nEscudos incluidos: {sorted(_used_logo_keys)}")

output = {
    'logos': LOGOS_USED,
    'meta': {
        'k_team_context': K_TEAM_CONTEXT, 'k_cautela': K_CAUTELA,
        'weights_by_pos': {'Guard': POS_WEIGHTS['Guard'], 'Forward': POS_WEIGHTS['Forward'], 'Center': CENTER_WEIGHTS},
        'pm_coverage': {'con_dato': int(ps['PM40'].notna().sum()), 'total': int(len(ps))},
        'team_regression': {'slope': round(slope, 4), 'intercept': round(intercept, 2), 'r2': round(R2, 3), 'n': int(len(merged)), 'p_value': round(p_value, 5)},
        'net_mean': round(float(NET_MEAN), 2), 'net_std': round(float(NET_STD), 2),
        'full_model_teams': FULL_MODEL_TEAMS,
    },
    'equipos': TEAM_DATA,
    'valencia': TEAM_DATA['Valencia Basket'],  # compat -- el dashboard ya no lo usa, se deja por si acaso
    'teams': teams_out,
}

with open('roster_dashboard_data.json', 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=1, default=_default)

print("\nOK -> roster_dashboard_data.json")
for _team, _data in TEAM_DATA.items():
    print(f"{_team} -- roster_26_27: {len(_data['roster_26_27'])} jugadores, bajas: {len(_data['bajas'])}")

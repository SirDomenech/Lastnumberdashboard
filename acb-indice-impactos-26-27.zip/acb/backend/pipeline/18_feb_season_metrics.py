import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

tgf = pd.read_csv('feb_team_game_full.csv')

agg_cols = ['PTS', 'FTM', 'FTA', 'P2M', 'P2A', 'P3M', 'P3A', 'FGM', 'FGA', 'AST',
            'OREB', 'DREB', 'TRB', 'STL', 'TOV', 'BLK', 'BLK_against', 'PF', 'FoulsDrawn']
opp_cols = [f'Opp_{c}' for c in agg_cols]

sm = tgf.groupby('team', as_index=False).agg(
    **{c: (c, 'sum') for c in agg_cols},
    **{c: (c, 'sum') for c in opp_cols},
    POSS=('POSS_game', 'sum'),
    GP=('game_id', 'nunique'),
)

G = sm['GP']
sm['Pace'] = sm['POSS'] / G

sm['OER'] = 100 * sm['PTS'] / sm['POSS']
sm['DER'] = 100 * sm['Opp_PTS'] / sm['POSS']
sm['NetRtg'] = sm['OER'] - sm['DER']

sm['ORB%'] = 100 * sm['OREB'] / (sm['OREB'] + sm['Opp_DREB'])
sm['DRB%'] = 100 * sm['DREB'] / (sm['DREB'] + sm['Opp_OREB'])
sm['TRB%'] = 100 * sm['TRB'] / (sm['TRB'] + sm['Opp_TRB'])

sm['TOV%'] = 100 * sm['TOV'] / sm['POSS']
sm['AST/TOV'] = sm['AST'] / sm['TOV']
sm['AST%'] = 100 * sm['AST'] / sm['FGM']

sm['eFG%'] = 100 * (sm['FGM'] + 0.5 * sm['P3M']) / sm['FGA']
sm['TS%'] = 100 * sm['PTS'] / (2 * (sm['FGA'] + 0.44 * sm['FTA']))
sm['FG%'] = 100 * sm['FGM'] / sm['FGA']
sm['3PAr'] = 100 * sm['P3A'] / sm['FGA']
sm['3P%'] = 100 * sm['P3M'] / sm['P3A']
sm['2P%'] = 100 * sm['P2M'] / sm['P2A']
sm['FTr'] = 100 * sm['FTA'] / sm['FGA']

sm['STL%'] = 100 * sm['STL'] / sm['POSS']
sm['BLK%'] = 100 * sm['BLK'] / sm['Opp_P2A']

sm['Opp_2P%'] = 100 * sm['Opp_P2M'] / sm['Opp_P2A']
sm['Opp_eFG%'] = 100 * (sm['Opp_FGM'] + 0.5 * sm['Opp_P3M']) / sm['Opp_FGA']
sm['Opp_TOV%'] = 100 * sm['Opp_TOV'] / sm['POSS']
sm['Opp_AST%'] = 100 * sm['Opp_AST'] / sm['Opp_FGM']
sm['Opp_3PAr'] = 100 * sm['Opp_P3A'] / sm['Opp_FGA']
sm['Opp_FTr'] = 100 * sm['Opp_FTA'] / sm['Opp_FGA']

# proxy de "concentracion de anotacion" (Top3_share/HHI) a nivel jugador-temporada FEB
box = pd.read_csv("/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/f15db639-Box_Scores_FEB_Completo.csv")
box = box.rename(columns={'TEAM NAME': 'team', 'PUNTOS': 'PTS', 'JUGADOR': 'player'})
NAME_MAP = {'CLUB OURENSE BALONCESTO': 'Ourense Baloncesto', 'CLOUD.GAL OURENSE BALONCESTO ': 'Ourense Baloncesto'}
box['team'] = box['team'].map(lambda x: NAME_MAP.get(x, x))
psum = box.groupby(['team', 'player'], as_index=False)['PTS'].sum()

def top3share(g):
    tot = g['PTS'].sum()
    top3 = g.nlargest(3, 'PTS')['PTS'].sum()
    return top3 / tot if tot else np.nan

def hhi(g):
    tot = g['PTS'].sum()
    if tot == 0:
        return np.nan
    shares = g['PTS'] / tot
    return (shares ** 2).sum()

conc = psum.groupby('team').apply(lambda g: pd.Series({'Top3_share': top3share(g), 'HHI': hhi(g)})).reset_index()
sm = sm.merge(conc, on='team', how='left')

sm.to_csv('feb_season_metrics.csv', index=False)
print(sm[['team', 'GP', 'Pace', 'OER', 'DER', 'NetRtg', 'AST%', 'TOV%', 'Top3_share']].round(2).to_string(index=False))

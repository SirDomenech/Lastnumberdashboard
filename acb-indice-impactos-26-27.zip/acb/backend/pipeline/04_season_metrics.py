import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

mg = pd.read_csv('team_game_full.csv')

sum_cols = ['PTS','FTM','FTA','P2M','P2A','P3M','P3A','AST','OREB','DREB','TRB','STL','TOV','BLK',
            'BLK_against','PF','FoulsDrawn','FGM','FGA','POSS_game',
            'Opp_PTS','Opp_FTM','Opp_FTA','Opp_P2M','Opp_P2A','Opp_P3M','Opp_P3A','Opp_AST','Opp_OREB',
            'Opp_DREB','Opp_TRB','Opp_STL','Opp_TOV','Opp_BLK','Opp_FGM','Opp_FGA']

season = mg.groupby('Nombre equipo')[sum_cols].sum()
season['GP'] = mg.groupby('Nombre equipo').size()
season = season.rename(columns={'POSS_game': 'POSS'})

# ---- Ritmo (contextual) ----
season['Pace'] = season['POSS'] / season['GP']  # posesiones por partido (40 min)

# ---- Ataque / Defensa ----
season['OER'] = season['PTS'] / season['POSS'] * 100      # puntos anotados por 100 posesiones
season['DER'] = season['Opp_PTS'] / season['POSS'] * 100  # puntos encajados por 100 posesiones
season['NetRtg'] = season['OER'] - season['DER']

# ---- Rebote ----
season['ORB%'] = season['OREB'] / (season['OREB'] + season['Opp_DREB']) * 100
season['DRB%'] = season['DREB'] / (season['DREB'] + season['Opp_OREB']) * 100
season['TRB%'] = season['TRB'] / (season['TRB'] + season['Opp_TRB']) * 100

# ---- Control y cuidado de balon ----
season['TOV%'] = season['TOV'] / season['POSS'] * 100
season['AST/TOV'] = season['AST'] / season['TOV']

# ---- Generacion (compuesto: OER + AST% + AST/TOV) ----
season['AST%'] = season['AST'] / season['FGM'] * 100  # % de canastas asistidas

# ---- Eficiencia anotacion ----
season['eFG%'] = (season['FGM'] + 0.5*season['P3M']) / season['FGA'] * 100
season['TS%'] = season['PTS'] / (2*(season['FGA'] + 0.44*season['FTA'])) * 100
season['FG%'] = season['FGM'] / season['FGA'] * 100

# ---- Tiro exterior ----
season['3PAr'] = season['P3A'] / season['FGA'] * 100
season['3P%'] = season['P3M'] / season['P3A'] * 100
season['2P%'] = season['P2M'] / season['P2A'] * 100

# ---- Facilidad para sacar faltas ----
season['FTr'] = season['FTA'] / season['FGA'] * 100

# ---- Defensa sobre balon (compuesto: DER + STL%) ----
season['STL%'] = season['STL'] / season['Opp_POSS_placeholder'] if False else None
season['STL%'] = season['STL'] / season['POSS'] * 100  # posesiones rival ~= posesiones propias (misma cantidad de posesiones en el partido)

# ---- Proteccion de aro (compuesto: BLK% + eficiencia rival tiro de 2) ----
season['BLK%'] = season['BLK'] / season['Opp_P2A'] * 100
season['Opp_2P%'] = season['Opp_P2M'] / season['Opp_P2A'] * 100
season['Opp_eFG%'] = (season['Opp_FGM'] + 0.5*season['Opp_P3M']) / season['Opp_FGA'] * 100
season['Opp_TOV%'] = season['Opp_TOV'] / season['POSS'] * 100
season['Opp_AST%'] = season['Opp_AST'] / season['Opp_FGM'] * 100
season['Opp_3PAr'] = season['Opp_P3A'] / season['Opp_FGA'] * 100
season['Opp_FTr'] = season['Opp_FTA'] / season['Opp_FGA'] * 100

season = season.round(2)
season = season.sort_index()

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 100)
cols_show = ['GP','Pace','OER','DER','NetRtg','ORB%','DRB%','TRB%','TOV%','AST/TOV','AST%',
             'eFG%','TS%','FG%','3PAr','3P%','FTr','STL%','BLK%','Opp_2P%']
print(season[cols_show])

season.to_csv('season_metrics.csv')
print("\nsaved season_metrics.csv")

# sanity checks
print("\nLeague avg pace:", season['Pace'].mean().round(2))
print("League avg OER (should ~= avg DER):", season['OER'].mean().round(2), season['DER'].mean().round(2))
print("Sum NetRtg*POSS approx 0 check (weighted):", (season['NetRtg']).mean().round(3))

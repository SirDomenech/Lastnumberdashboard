# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Rating de jugador v3 -- Valencia Basket. Tercera vuelta tras feedback directo de
Miguel sobre v2 (25/26_valencia_player_impact/rating_v2):

- Métricas: USG%, AST%, eFG%, TRB%, MPG, GP (fiabilidad de muestra), BLK, AST,
  PPG, FG%, 3P%, TOV%. Prioridad a USG%, AST% y minutos.
- Percentil (no z-score) para que un jugador realmente elite pueda acercarse a
  la parte alta de la escala.
- Blend de las 2 últimas temporadas por CONTEXTO (similar pesa más que distinto)
  y por partidos jugados, no por recencia.

Hallazgo importante (ver mensaje a Miguel): con una media ponderada de
percentiles, un jugador excelente pero no top-3-de-la-liga-en-todo (caso
Montero: élite en uso/creación/anotación, normal en rebote y minutos porque
es su rol) no puede matemáticamente superar ~80-90, aunque se cargue casi
todo el peso en USG%/AST%. Superar 95 exigiría un diseño donde 1-2 métricas
determinen casi en solitario la nota. Este script implementa la versión
"equilibrada" (no la extrema) -- ver nota final.

Estructura del rating (0-100):
  0.55 x media percentil liga completa de (USG%, AST%, PPG, APG)   [núcleo de
        importancia ofensiva -- se compara contra toda la liga porque el uso y
        la responsabilidad de anotar/asistir no dependen de la posición]
  0.25 x percentil liga completa de MPG                             [minutos:
        prioridad pedida por Miguel]
  0.20 x media percentil DENTRO DE SU POSICIÓN de (eFG%, TRB%, BLK/PG, FG%,
        3P%, TOV% invertido)                                        [resto:
        se compara dentro de la posición para no penalizar a un base por no
        rebotear como un pívot, ni premiar a un pívot por no asistir como base]
"""
import pandas as pd
import numpy as np
from scipy import stats as sps
import json
import unicodedata

def norm(s):
    if pd.isna(s):
        return ''
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode('ascii')
    return ' '.join(s.lower().strip().split())

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 60)
pd.set_option('display.max_rows', 200)

# ============================================================================
# 1) referencia ACB
# ============================================================================
ps = pd.read_csv('player_season.csv')
rm = pd.read_csv('roster_matched.csv')
POS_MAP = {'G':'Guard','PG':'Guard','SG':'Guard','F':'Forward','SF':'Forward','PF':'Forward',
           'GF':'Forward','C':'Center','FC':'Center','-':None}
rm['pos_group'] = rm['Pos'].map(POS_MAP)
pos_by_id = rm.dropna(subset=['id']).drop_duplicates('id').set_index('id')['pos_group']
ps['pos_group'] = ps['id'].map(pos_by_id)

tg = pd.read_csv('team_game_full.csv')
team_trb = tg.groupby('Nombre equipo', as_index=False).agg(Team_TRB_season=('TRB','sum'), Opp_TRB_season=('Opp_TRB','sum'))
ps = ps.merge(team_trb, left_on='team_last', right_on='Nombre equipo', how='left')
MP = ps['MP_sec']/60; T_MP = ps['T_MPsec']/60
ps['eFG%'] = 100*(ps['FGM'] + 0.5*ps['P3M']) / ps['FGA']
ps['TRB%'] = 100*ps['TRB']*(T_MP/5) / (MP*(ps['Team_TRB_season']+ps['Opp_TRB_season']))
ps['BPG'] = ps['BLK']/ps['games']
ps['FG%'] = 100*ps['FGM']/ps['FGA']

qualified = ps[~ps['bajo_volumen']].copy()
ps['name_norm'] = ps['nickname'].map(norm)
ps_by_name = ps.set_index('name_norm')

def lookup_player(name):
    key = norm(name)
    if key not in ps_by_name.index:
        return None
    row = ps_by_name.loc[key]
    if isinstance(row, pd.DataFrame):
        row = row.sort_values('games', ascending=False).iloc[0]
    return row

CORE = ['USG%', 'AST%', 'PPG', 'APG']
SEC = {'eFG%': 1, 'TRB%': 1, 'BPG': 1, 'FG%': 1, '3P%': 1, 'TOV%': -1}
REF_WHOLE = {m: qualified[m].dropna().values for m in CORE + ['MPG']}
REF_POS = {grp: {m: qualified[qualified['pos_group']==grp][m].dropna().values for m in SEC}
           for grp in ['Guard', 'Forward', 'Center']}

def pctl(ref, value, invert=False):
    if value is None or pd.isna(value) or len(ref) < 5:
        return np.nan
    p = sps.percentileofscore(ref, value, kind='mean')
    return 100 - p if invert else p

def rating_from_metrics(m, pos_group):
    """m: dict con USG%, AST%, PPG, APG, MPG, eFG%, TRB%, BPG, FG%, 3P%, TOV%"""
    core_p = [pctl(REF_WHOLE[k], m[k]) for k in CORE]
    core_avg = np.nanmean(core_p) if not all(pd.isna(x) for x in core_p) else np.nan
    mpg_p = pctl(REF_WHOLE['MPG'], m['MPG'])
    if pos_group in REF_POS:
        sec_p = [pctl(REF_POS[pos_group][k], m[k], invert=(d==-1)) for k, d in SEC.items()]
        sec_avg = np.nanmean(sec_p) if not all(pd.isna(x) for x in sec_p) else np.nan
    else:
        sec_avg = np.nan
    parts = [(0.55, core_avg), (0.25, mpg_p), (0.20, sec_avg)]
    parts = [(w, v) for w, v in parts if not pd.isna(v)]
    if not parts:
        return np.nan
    wsum = sum(w for w, v in parts)
    return sum(w*v for w, v in parts) / wsum

# ============================================================================
# 2) BAJAS de Valencia -- rating directo (1 temporada, ya en ACB)
# ============================================================================
with open('fichajes_impact.json', encoding='utf-8') as f:
    fichajes = json.load(f)
valencia = fichajes['Valencia Basket']

bajas_out = []
for b in valencia['detalle_bajas_medibles']:
    row = lookup_player(b['jugador'])
    if row is None:
        bajas_out.append({**b, 'rating_0_100': None, 'pos_group': None})
        continue
    m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
    r = rating_from_metrics(m, row['pos_group'])
    bajas_out.append({**b, 'rating_0_100': round(r,1) if not pd.isna(r) else None,
                       'pos_group': row['pos_group']})

print("=== BAJAS de Valencia (rating v3) ===")
for b in sorted(bajas_out, key=lambda x: -(x['rating_0_100'] or 0)):
    print(f"  -{b['jugador']:20s} pos={str(b['pos_group']):8s} Rating={b['rating_0_100']}/100  -> {b['procedencia_destino']}")

# ============================================================================
# 3) ALTAS ya medidas vía ACB->ACB (Corbalán, Valtonen)
# ============================================================================
altas_acb_out = []
for a in valencia['detalle_altas_medibles']:
    row = lookup_player(a['jugador'])
    if row is None:
        altas_acb_out.append({**a, 'rating_0_100': None, 'pos_group': None})
        continue
    m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
    r = rating_from_metrics(m, row['pos_group'])
    altas_acb_out.append({**a, 'rating_0_100': round(r,1) if not pd.isna(r) else None,
                           'pos_group': row['pos_group']})

print("\n=== ALTAS ya medidas ACB->ACB (rating v3) ===")
for a in sorted(altas_acb_out, key=lambda x: -(x['rating_0_100'] or 0)):
    print(f"  +{a['jugador']:20s} pos={str(a['pos_group']):8s} Rating={a['rating_0_100']}/100  <- {a['procedencia_destino']}")

# ============================================================================
# 4) ALTAS del fichero nuevo (7 jugadores, con nivel de liga + contexto)
# ============================================================================
mk = pd.read_csv('/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/92425b6a-Fichajes_-_ACB_-_Hoja_1.csv')

def season_rows(df_player):
    out = []
    for season, sub in df_player.groupby('Season', sort=False):
        agg = sub[sub['Team'] == 'All Teams']
        if len(agg) == 1:
            out.append(agg.iloc[0])
        elif len(sub) == 1:
            out.append(sub.iloc[0])
        else:
            out.append(sub.sort_values('GP', ascending=False).iloc[0])
    return out

def row_metrics(r):
    return {
        'USG%': r['USG%'], 'AST%': r['AST%'], 'PPG': r['PTS'], 'APG': r['AST'], 'MPG': r['MIN'],
        'eFG%': r['eFG%']/10 if not pd.isna(r['eFG%']) else np.nan,
        'TRB%': r['TRB%'], 'BPG': r['BLK'],
        'FG%': r['FG%']/10 if not pd.isna(r['FG%']) else np.nan,
        '3P%': r['3P%']/10 if not pd.isna(r['3P%']) else np.nan,
        'TOV%': r['TOV%'],
    }

LEVEL_SHIFT_PTS = {'Higher': +8, 'Same': 0, 'Lower level': -12, 'Much lower': -20}
CONTEXT_MULT = {'Similar': 1.0, 'Slower': 0.4, 'Other context': 0.4}

CORRUPT_ROW_FIX = {
    ('Lucas Marí', '2024-25 *', 'All Teams'): ('2024-25 *', "CB L'Horta Godella"),
    ('Lucas Marí', '2025-26', 'Vermont'): None,
    ('Mario Saint-Supery', '2024-25 *', 'All Teams'): ('2024-25 *', 'BAXI Manresa'),
    ('Nikola Mirotic', '2024-25 *', 'All Teams'): ('2024-25 *', 'AX Armani Exchange Milan'),
    ('Mario Saint-Supery', '2025-26', 'Gonzaga'): None,
}
POS_ASSUMED = {
    'TJ Shorts': 'Guard', 'Armoni Brooks': 'Guard', 'Mo Gueye': 'Center', 'Lucas Marí': 'Forward',
    'Nikola Mirotic': 'Forward', 'Dylan Osetkowski': 'Forward', 'Mario Saint-Supery': 'Guard',
}

players_out = []
for player, sub in mk.groupby('Player', sort=False):
    sub = sub.copy()
    rows = season_rows(sub)
    rows = sorted(rows, key=lambda r: str(r['Season']), reverse=True)[:2]
    pos_group = POS_ASSUMED.get(player)

    detail = []
    for r in rows:
        key = (player, r['Season'], r['Team'])
        if key in CORRUPT_ROW_FIX:
            fix = CORRUPT_ROW_FIX[key]
            if fix is None:
                continue
            season_ov, team_ov = fix
            r = mk[(mk['Player']==player) & (mk['Season']==season_ov) & (mk['Team']==team_ov)].iloc[0]

        m = row_metrics(r)
        base = rating_from_metrics(m, pos_group)
        if pd.isna(base):
            continue
        level, context = r['Level'], r['Context']
        adj = base + LEVEL_SHIFT_PTS.get(level, 0)
        w = r['GP'] * CONTEXT_MULT.get(context, 0.4)
        detail.append({'season': r['Season'], 'team': r['Team'], 'league': r['League'], 'gp': int(r['GP']),
                        'level': level, 'context': context, 'blend_weight': round(w,1),
                        'rating_bruto': round(base,1), 'rating_ajustado': round(adj,1)})

    if not detail:
        players_out.append({'player': player, 'rating_0_100': None, 'pos_group': pos_group, 'temporadas': []})
        continue
    wsum = sum(d['blend_weight'] for d in detail)
    rating = sum(d['blend_weight']*d['rating_ajustado'] for d in detail) / wsum
    rating = round(float(np.clip(rating, 1, 99)), 1)
    players_out.append({'player': player, 'rating_0_100': rating, 'pos_group': pos_group, 'temporadas': detail})

print("\n=== ALTAS nuevas (rating v3, fichero con histórico + nivel + contexto) ===")
for p in sorted(players_out, key=lambda x: -(x['rating_0_100'] or 0)):
    print(f"\n{p['player']} ({p['pos_group']}): Rating = {p['rating_0_100']}/100")
    for d in p['temporadas']:
        print(f"   {d['season']}  {d['team']} ({d['league']})  GP={d['gp']}  nivel={d['level']}  contexto={d['context']}  "
              f"peso={d['blend_weight']}  bruto={d['rating_bruto']}  ajustado={d['rating_ajustado']}")

with open('valencia_player_ratings_v3.json', 'w', encoding='utf-8') as f:
    def _default(o):
        return o.item() if hasattr(o,'item') else str(o)
    json.dump({'altas_nuevas': players_out, 'bajas': bajas_out, 'altas_ya_medidas_acb': altas_acb_out},
              f, ensure_ascii=False, indent=1, default=_default)

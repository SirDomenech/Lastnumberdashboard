# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Modelo de arquetipado entrenado con la logica extraida de las correcciones
manuales de Miguel (fichero devuelto 03/10/2026, 223/224 jugadores del
roster 26/27). Sustituye la pregunta "seria capaz de elaborar un modelo de
arquetipado basado en los datos que tenemos" por una respuesta concreta:
se entrena, se valida con cross-validation y se reportan metricas reales
(no solo la promesa).

Features: los 6 percentiles ya calculados en el pipeline (perfil_atributos
por jugador: anotacion, creacion, cuidado_balon, defensa, rebote, impacto)
+ pos_group (Guard/Forward/Center, one-hot). Son features limpias porque
YA estan en la misma escala 0-100 para cualquier jugador, sea 'returning',
alta ACB->ACB o alta extranjera -- a diferencia de las stats crudas (USG%,
AST%...), que vienen de ligas/fuentes distintas y no son directamente
comparables sin la traduccion de nivel que ya hace el pipeline.

Target: 'role' (clave interna en ingles) tal y como quedo en el JSON tras
aplicar ARQUETIPO_MIGUEL_BY_KEY en 29_valencia_dashboard_data.py -- es
literalmente la correccion de Miguel para 221 de los 223 jugadores que
devolvio (2 etiquetas ambiguas/typos -- 'Jugador', 'Manejador exterior' --
se excluyen del entrenamiento, ver AMBIGUOS mas abajo).
"""
import json
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

AMBIGUOS = {('Vince Hunter', 'La Laguna Tenerife'), ('Andrés Feliz', 'Real Madrid')}

with open('roster_dashboard_data.json', encoding='utf-8') as f:
    data = json.load(f)

rows = []
for team, eq in data['equipos'].items():
    for p in eq['roster_26_27']:
        if (p['player'], team) in AMBIGUOS:
            continue
        if not p.get('etiquetas_especiales') and not p.get('role_model_note'):
            # sigue sin corregir explicitamente por Miguel en este pase --
            # de todas formas los incluimos: 'role' ya es su valor (corregido
            # o, si coincidia con el modelo, confirmado tal cual).
            pass
        atr = p.get('atributos') or {}
        if not atr or not p.get('pos_group'):
            continue
        rows.append({
            'player': p['player'], 'team': team, 'pos_group': p['pos_group'],
            'role': p['role'],
            'anotacion': atr.get('anotacion'), 'creacion': atr.get('creacion'),
            'cuidado_balon': atr.get('cuidado_balon'), 'defensa': atr.get('defensa'),
            'rebote': atr.get('rebote'), 'impacto': atr.get('impacto'),
        })

df_raw = pd.DataFrame(rows)
# 'impacto' (plus-minus normalizado) falta en 96/224 jugadores -- casi
# siempre altas de fuera de la ACB, donde no hay +/- real de boxscore.
# Se entrena SIN ese atributo (5 features en vez de 6) para no perder ~43%
# de la muestra -- la perdida de accuracy por quitarlo es pequeña (~33% vs
# ~40% de CV accuracy con impacto incluido, ver commit/registro de esta
# sesion) frente a la ganancia de cobertura (217 jugadores en vez de 126).
FEATS = ['anotacion', 'creacion', 'cuidado_balon', 'defensa', 'rebote']
df = df_raw[['player', 'team', 'pos_group', 'role'] + FEATS].dropna()
n_incompletos = len(df_raw) - len(df)
print(f"n={len(df)} jugadores usados para entrenar (de 224 en el roster, "
      f"{n_incompletos} excluidos por tener 1+ de los {len(FEATS)} atributos sin calcular).")
print(df['role'].value_counts())
print()
X_num = df[FEATS].astype(float)
X_pos = pd.get_dummies(df['pos_group'], prefix='pos')
X = pd.concat([X_num, X_pos], axis=1)
y = df['role']

class_counts = y.value_counts()
min_class = class_counts.min()
n_splits = min(5, min_class)
print(f"Clases: {len(class_counts)} -- la mas pequena tiene {min_class} ejemplo(s) "
      f"({class_counts.idxmin()}) -> cross-validation con {n_splits} folds.")
print()

skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

# ---- Modelo 1: arbol de decision (interpretable -- da "la logica") ----
tree = DecisionTreeClassifier(max_depth=4, min_samples_leaf=4, random_state=42)
if n_splits >= 2:
    pred_tree = cross_val_predict(tree, X, y, cv=skf)
    acc_tree = accuracy_score(y, pred_tree)
else:
    pred_tree = None
    acc_tree = None

# ---- Modelo 2: regresion logistica multinomial (features estandarizadas) ----
scaler = StandardScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)
logreg = LogisticRegression(max_iter=2000)
if n_splits >= 2:
    pred_lr = cross_val_predict(logreg, X_scaled, y, cv=skf)
    acc_lr = accuracy_score(y, pred_lr)
else:
    pred_lr = None
    acc_lr = None

print("=" * 70)
print(f"Accuracy cross-validada ({n_splits} folds):")
print(f"  Arbol de decision:       {acc_tree:.1%}" if acc_tree is not None else "  Arbol: N/A (muy pocos folds)")
print(f"  Regresion logistica:     {acc_lr:.1%}" if acc_lr is not None else "  LogReg: N/A")
n_classes = len(class_counts)
print(f"  (referencia: azar entre {n_classes} clases = {1/n_classes:.1%}; "
      f"clase mayoritaria sola = {class_counts.max()/len(y):.1%})")
print("=" * 70)
print()

# ---- confusiones mas frecuentes (con el arbol, que es el mejor / mas simple) ----
if pred_tree is not None:
    cm = confusion_matrix(y, pred_tree, labels=class_counts.index)
    print("Confusiones mas frecuentes (arbol, fuera de la diagonal):")
    confusions = []
    for i, a in enumerate(class_counts.index):
        for j, b in enumerate(class_counts.index):
            if i != j and cm[i, j] > 0:
                confusions.append((cm[i, j], a, b))
    confusions.sort(reverse=True)
    for n, a, b in confusions[:12]:
        print(f"  {n}x  '{a}' predicho como '{b}'")
    print()

# ---- entrena el arbol final (TODO el dataset) para extraer "la logica" ----
tree_final = DecisionTreeClassifier(max_depth=4, min_samples_leaf=4, random_state=42)
tree_final.fit(X, y)
print("Reglas del arbol final (entrenado con los 221 jugadores, todas las clases):")
print(export_text(tree_final, feature_names=list(X.columns), max_depth=4))

# feature importance
print("Importancia de cada atributo en el arbol final:")
for feat, imp in sorted(zip(X.columns, tree_final.feature_importances_), key=lambda t: -t[1]):
    if imp > 0:
        print(f"  {feat:16} {imp:.2f}")
print()

# guarda el detalle de clasificacion (precision/recall por clase) a un csv para revision
report = classification_report(y, pred_tree, output_dict=True, zero_division=0) if pred_tree is not None else {}
rep_df = pd.DataFrame(report).T
rep_df.to_csv('archetype_classifier_report.csv')
print("Detalle precision/recall por arquetipo -> archetype_classifier_report.csv")

# guarda predicciones para los 2 jugadores ambiguos, con el arbol final
amb_rows = []
for team, eq in data['equipos'].items():
    for p in eq['roster_26_27']:
        if (p['player'], team) in AMBIGUOS:
            atr = p.get('atributos') or {}
            row = {f: atr.get(f) for f in FEATS}
            row_df = pd.DataFrame([row])
            for c in X_pos.columns:
                row_df[c] = 1 if c == f"pos_{p.get('pos_group')}" else 0
            row_df = row_df[X.columns]
            pred = tree_final.predict(row_df)[0]
            proba = tree_final.predict_proba(row_df)[0]
            top_p = max(proba)
            amb_rows.append((p['player'], team, p['role'], pred, round(top_p, 2)))
print()
print("Prediccion del modelo para los 2 jugadores con etiqueta ambigua (no entrenados con ellos):")
for player, team, modelo_hoy, pred, conf in amb_rows:
    print(f"  {player} ({team}): modelo actual='{modelo_hoy}' -> arbol predice '{pred}' (confianza {conf:.0%})")

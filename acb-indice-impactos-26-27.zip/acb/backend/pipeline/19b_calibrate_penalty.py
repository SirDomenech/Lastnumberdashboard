import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 100)

COEF = 0.30
NEW_TEAMS = ['LEYMA CORUÑA', 'MONBUS OBRADOIRO']
OUT_TEAMS = ['Coviran Granada', 'Dreamland Gran Canaria']

acb = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
acb_full = acb.join(track, how='left')
acb_full['PF_per100'] = acb_full['PF'] / acb_full['POSS'] * 100
acb_full['Top3_share'] = pd.read_csv('scoring_top3share.csv', index_col=0)['share']
acb_cont = acb_full.drop(index=[t for t in OUT_TEAMS if t in acb_full.index])

feb = pd.read_csv('feb_season_metrics.csv', index_col='team')
feb['PF_per100'] = feb['PF'] / feb['POSS'] * 100

QUALITY_METRICS = ['OER', 'DER', 'TRB%', 'ORB%', 'DRB%', 'TOV%', 'AST/TOV', 'AST%',
                    'eFG%', 'TS%', 'FG%', '3P%', '3PAr', 'FTr', 'STL%', 'BLK%',
                    'Opp_2P%', 'Opp_TOV%', 'Opp_FTr', 'PF_per100', 'Top3_share']

# +1 = mas alto es mejor ; -1 = mas bajo es mejor ; 0 = neutro/descriptivo (no se penaliza)
DIRECTION = {
    'OER': 1, 'DER': -1, 'TRB%': 1, 'ORB%': 1, 'DRB%': 1, 'TOV%': -1, 'AST/TOV': 1,
    'AST%': 1, 'eFG%': 1, 'TS%': 1, 'FG%': 1, '3P%': 1, '3PAr': 1, 'FTr': 1,
    'STL%': 1, 'BLK%': 1, 'Opp_2P%': -1, 'Opp_TOV%': 1, 'Opp_FTr': -1,
    'PF_per100': 0, 'Top3_share': 0,
}

feb_mean = feb[QUALITY_METRICS].mean()
feb_std = feb[QUALITY_METRICS].std(ddof=0)
acb_mean = acb_cont[QUALITY_METRICS].mean()
acb_std = acb_cont[QUALITY_METRICS].std(ddof=0)

NEEDED_STARS = ['Pace', 'OER', 'DER', 'TRB%', 'ORB%', 'DRB%', 'TOV%', 'AST/TOV', 'AST%',
                'eFG%', 'TS%', 'FG%', '3P%', '3PAr', 'FTr', 'STL%', 'BLK%', 'Opp_2P%']

def z(df, col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def stars(zseries):
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    s = pd.cut(zseries, bins=bins, labels=labels).astype(float)
    s[zseries <= -2.5] = 0
    return s.astype(int)

def stars_neutral(df, col):
    x = df[col]
    zc = (x - x.mean()) / x.std(ddof=0)
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    return pd.cut(zc, bins=bins, labels=labels).astype(float).astype(int)

def translate(pen):
    translated = {}
    for team in NEW_TEAMS:
        row = {}
        z_feb = (feb.loc[team, QUALITY_METRICS] - feb_mean) / feb_std
        z_pen = z_feb * COEF - pen * pd.Series(DIRECTION)
        raw_acb_equiv = acb_mean + z_pen * acb_std
        for m in QUALITY_METRICS:
            row[m] = raw_acb_equiv[m]
        row['Pace'] = feb.loc[team, 'Pace']
        translated[team] = row
    return pd.DataFrame(translated).T

def total_stars(trans_df):
    trans_df = trans_df.copy()
    trans_df.index = ['Leyma Coruña', 'Monbus Obradoiro']
    df = pd.concat([acb_cont[NEEDED_STARS], trans_df[NEEDED_STARS]])

    out = pd.DataFrame(index=df.index)
    out['Ritmo_perfil'] = stars_neutral(df, 'Pace')
    out['Ataque_estrellas'] = stars(z(df, 'OER'))
    out['Defensa_estrellas'] = stars(z(df, 'DER', invert=True))
    out['Rebote_estrellas'] = stars(z(df, 'TRB%'))
    z_control = (z(df, 'TOV%', invert=True) + z(df, 'AST/TOV')) / 2
    out['Control_estrellas_global'] = stars(z_control)
    z_gen = (z(df, 'OER') + z(df, 'AST%') + z(df, 'AST/TOV')) / 3
    out['Generacion_estrellas'] = stars(z_gen)
    z_efi = (z(df, 'eFG%') + z(df, 'TS%') + z(df, 'FG%')) / 3
    out['Eficiencia_estrellas'] = stars(z_efi)
    z_ext = (z(df, '3P%') + z(df, '3PAr')) / 2
    out['Exterior_estrellas'] = stars(z_ext)
    out['Faltas_estrellas'] = stars(z(df, 'FTr'))
    z_defbalon = (z(df, 'DER', invert=True) + z(df, 'STL%')) / 2
    out['DefBalon_estrellas'] = stars(z_defbalon)
    z_aro = (z(df, 'BLK%') + z(df, 'Opp_2P%', invert=True)) / 2
    out['Aro_estrellas'] = stars(z_aro)

    cols = ['Ritmo_perfil', 'Ataque_estrellas', 'Defensa_estrellas', 'Rebote_estrellas',
            'Control_estrellas_global', 'Generacion_estrellas', 'Eficiencia_estrellas',
            'Exterior_estrellas', 'Faltas_estrellas', 'DefBalon_estrellas', 'Aro_estrellas']
    out['Total_estrellas'] = out[cols].sum(axis=1)
    ranking = out.sort_values('Total_estrellas', ascending=False)
    ranking.insert(0, 'Puesto', range(1, len(ranking) + 1))
    return ranking

for pen in [0.0, 0.5, 0.8, 1.0, 1.2, 1.5, 1.8, 2.0, 2.3, 2.6, 3.0]:
    trans = translate(pen)
    rk = total_stars(trans)
    pc = rk.loc['Leyma Coruña', 'Puesto']
    po = rk.loc['Monbus Obradoiro', 'Puesto']
    tc = rk.loc['Leyma Coruña', 'Total_estrellas']
    to = rk.loc['Monbus Obradoiro', 'Total_estrellas']
    print(f"PEN={pen:.2f}  Coruña: puesto {pc} ({tc} estr.)   Obradoiro: puesto {po} ({to} estr.)")

import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 100)

season = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
df = season.join(track, how='left')
df['PF_per100'] = df['PF'] / df['POSS'] * 100
df['Top3_share'] = pd.read_csv('scoring_top3share.csv', index_col=0)['share']

def zg(col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def tertile(col, invert=False):
    r = df[col].rank(ascending=invert)
    n = len(df)
    return pd.cut(r, bins=[0, n/3, 2*n/3, n], labels=['Alto', 'Medio', 'Bajo'])

df['Pace_tier'] = tertile('Pace')

TARGET = 1.4

# =========================================================================
# OFFENSE v3
# Regla 1: indice combinado ritmo+3PAr (media de z) en el tercio superior -> Pace & Space
# Regla 2: ritmo bajo (tercil) -> Baloncesto de Control
# Regla 3: resto -> nearest-fit RMS entre Coral / Interior / Talento Individual
#          (Coral excluido si el equipo tiene ritmo Alto, para respetar "solo si ritmo medio")
# =========================================================================
df['z_pacespace_idx'] = (zg('Pace') + zg('3PAr')) / 2
n = len(df)
r_idx = df['z_pacespace_idx'].rank(ascending=False)
df['PaceSpace_idx_tier'] = pd.cut(r_idx, bins=[0, n/3, 2*n/3, n], labels=['Alto', 'Medio', 'Bajo'])

REMAINING_ARCHETYPES = {
    'Juego Coral (Pase y Corte)': {'AST%': False, 'AST/TOV': False},
    'Juego Interior y Físico': {'ORB%': False, 'FTr': False, 'ptsPIN_per100pos': False, 'ptsRO_per100pos': False},
    'Talento Individual (1c1)': {'Top3_share': False, 'AST%': True},
}

def best_fit(team, candidates):
    dists = {}
    for arch, metrics in candidates.items():
        vals = [(zg(m, invert=inv)[team] - TARGET) ** 2 for m, inv in metrics.items()]
        dists[arch] = np.sqrt(np.mean(vals))
    return min(dists, key=dists.get), dists

ataque, ataque_reason = {}, {}
for team in df.index:
    if df.loc[team, 'PaceSpace_idx_tier'] == 'Alto':
        ataque[team] = 'Ritmo y Espacio'
        ataque_reason[team] = f"Regla 1: indice ritmo+3PAr en tercio superior (idx z={df.loc[team,'z_pacespace_idx']:.2f})"
    elif df.loc[team, 'Pace_tier'] == 'Bajo':
        ataque[team] = 'Baloncesto de Control'
        ataque_reason[team] = 'Regla 2: ritmo bajo'
    else:
        candidates = dict(REMAINING_ARCHETYPES)
        if df.loc[team, 'Pace_tier'] == 'Alto':
            candidates = {k: v for k, v in candidates.items() if k != 'Juego Coral (Pase y Corte)'}
        best, dists = best_fit(team, candidates)
        ataque[team] = best
        ataque_reason[team] = f"Regla 3 nearest-fit: {[(k, round(v,2)) for k,v in dists.items()]}"

# =========================================================================
# DEFENSE v3: Presion (esquema de equipo) vs Agresividad sobre balon (individual)
# =========================================================================
DEFENSE_ARCHETYPES = {
    'Cierre de Pintura (Contención)': {'DRB%': False, 'Opp_2P%': True, 'r_ptsPIN_per100pos': True, 'Opp_FTr': True},
    'Presión y Agresividad (esquema)': {'Opp_TOV%': False},
    'Agresividad sobre balón (individual)': {'STL%': False, 'PF_per100': False},
    'Balance Defensivo y Equilibrio': {'r_ptsCA_per100pos': True, 'DRB%': False, 'PF_per100': True},
}

def best_fit_all(team, block):
    dists = {}
    for arch, metrics in block.items():
        vals = [(zg(m, invert=inv)[team] - TARGET) ** 2 for m, inv in metrics.items()]
        dists[arch] = np.sqrt(np.mean(vals))
    best = min(dists, key=dists.get)
    second = sorted(dists, key=dists.get)[1]
    return best, dists[best], second, dists[second], dists

defensa, def_dist_full = {}, {}
for team in df.index:
    best, bd, second, sd, dists = best_fit_all(team, DEFENSE_ARCHETYPES)
    defensa[team] = (best, bd, second, sd)
    def_dist_full[team] = dists

result = pd.DataFrame(index=df.index)
result['Ataque_arquetipo_v3'] = pd.Series(ataque)
result['Ataque_motivo'] = pd.Series(ataque_reason)
result['Defensa_arquetipo_v3'] = pd.Series({k: v[0] for k, v in defensa.items()})
result['Defensa_dist'] = pd.Series({k: round(v[1],2) for k, v in defensa.items()})
result['Defensa_secundario'] = pd.Series({k: v[2] for k, v in defensa.items()})

print(result[['Ataque_arquetipo_v3','Defensa_arquetipo_v3']].to_string())
print()
print("Ataque counts:\n", result['Ataque_arquetipo_v3'].value_counts())
print()
print("Defensa counts:\n", result['Defensa_arquetipo_v3'].value_counts())
print()
print("--- Distancias completas defensa ---")
print(pd.DataFrame(def_dist_full).T.round(2).to_string())
print()
for team in df.index:
    print(team, '|', ataque_reason[team])

result.to_csv('team_archetypes_v3.csv')

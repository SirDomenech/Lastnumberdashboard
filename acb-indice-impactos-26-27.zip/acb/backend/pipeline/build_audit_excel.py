# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""Excel de auditoria: TODOS los jugadores que contempla el dashboard (roster
26/27 proyectado, los 18 equipos), con Jugador/Equipo/Posicion primaria/
Posicion secundaria/Altura/Edad, para que Miguel pode la lista a mano."""
import json
import unicodedata
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

def norm(s):
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return ''
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode('ascii')
    return ' '.join(s.lower().strip().split())

with open('roster_dashboard_data.json', encoding='utf-8') as f:
    data = json.load(f)

mig = pd.read_csv('jugadores_miguel_completado.csv')
mig['name_norm'] = mig['Jugador'].map(norm)
mig_by_norm = mig.set_index('name_norm').to_dict('index')

rm = pd.read_csv('roster_matched.csv')
rm['name_norm'] = rm['Player'].map(norm)
# si hay varias filas para el mismo jugador (varias temporadas/matches), nos
# quedamos con la de mas partidos jugados (mas fiable)
rm_sorted = rm.sort_values('games', ascending=False, na_position='last')
rm_by_norm = rm_sorted.drop_duplicates('name_norm').set_index('name_norm').to_dict('index')

POS_GROUP_ES = {'Guard': 'Base/Escolta', 'Forward': 'Alero/Ala-Pívot', 'Center': 'Pívot'}

def ht_to_m(ht):
    """'6-9' (pies-pulgadas) -> metros. None si no se puede parsear."""
    if ht is None or (isinstance(ht, float) and pd.isna(ht)) or '-' not in str(ht):
        return None
    try:
        feet, inches = str(ht).split('-')
        return round((int(feet) * 12 + int(inches)) * 0.0254, 2)
    except Exception:
        return None

STATUS_ES = {'returning': 'Se queda', 'alta_acb': 'Alta (ACB->ACB)', 'alta_extranjero': 'Alta (fuera ACB / confirmada)'}

rows = []
for team, eq in data['equipos'].items():
    for p in eq['roster_26_27']:
        player = p['player']
        nn = norm(player)
        pos_group = p.get('pos_group')
        status = p['status']

        pos_primaria = None
        pos_secundaria = None
        altura = None
        edad = None
        fuente = None

        if status == 'alta_extranjero' and nn in mig_by_norm:
            mrow = mig_by_norm[nn]
            pos_primaria = mrow.get('Posición primaria')
            pos_secundaria = mrow.get('Posición en detalle')
            altura = p.get('altura_m')
            edad = p.get('edad')
            fuente = 'Confirmado (Excel de Miguel / investigación)'
        else:
            pos_primaria = POS_GROUP_ES.get(pos_group, pos_group)
            if nn in rm_by_norm:
                r = rm_by_norm[nn]
                pos_secundaria = r.get('Pos')  # codigo ACB crudo (GF, PF, SF...), no confirmado
                altura = ht_to_m(r.get('HT'))
            edad = None  # sin fuente de fecha de nacimiento para jugadores ya en ACB
            fuente = 'Datos de referencia ACB (roster_matched) -- sin fecha de nacimiento disponible'

        rows.append({
            'Jugador': player, 'Equipo': team, 'Estado': STATUS_ES.get(status, status),
            'Posición primaria': pos_primaria, 'Posición secundaria': pos_secundaria,
            'Altura (m)': altura, 'Edad': edad, 'Rating actual': p.get('rating_0_100'),
            'Fuente de posición/altura/edad': fuente,
        })

df = pd.DataFrame(rows).sort_values(['Equipo', 'Jugador'])
print(f"{len(df)} jugadores totales | con edad: {df['Edad'].notna().sum()} | con altura: {df['Altura (m)'].notna().sum()} | con pos. secundaria: {df['Posición secundaria'].notna().sum()}")

wb = openpyxl.Workbook()
ws = wb.active
ws.title = 'Jugadores dashboard 26-27'
headers = list(df.columns)
ws.append(headers)
FONT = 'Arial'
header_fill = PatternFill('solid', fgColor='1F2937')
header_font = Font(name=FONT, bold=True, color='FFFFFF', size=11)
normal_font = Font(name=FONT, size=10)
missing_fill = PatternFill('solid', fgColor='FCE4E4')
thin = Side(style='thin', color='D9D9D9')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
for c in range(1, len(headers) + 1):
    cell = ws.cell(row=1, column=c)
    cell.font = header_font; cell.fill = header_fill
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.border = border
for _, row in df.iterrows():
    ws.append(list(row))
edad_col = headers.index('Edad') + 1
for i in range(2, ws.max_row + 1):
    edad_missing = ws.cell(row=i, column=edad_col).value is None
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=i, column=c)
        cell.font = normal_font; cell.border = border
        cell.alignment = Alignment(vertical='center', wrap_text=True)
        if edad_missing:
            cell.fill = missing_fill
widths = [24, 26, 22, 18, 18, 12, 8, 12, 46]
for i, w in enumerate(widths[:len(headers)], start=1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = 'A2'
ws.auto_filter.ref = f'A1:{get_column_letter(len(headers))}{ws.max_row}'

ws2 = wb.create_sheet('Léeme')
ws2.column_dimensions['A'].width = 105
lines = [
    f'{len(df)} JUGADORES -- todos los que contempla el dashboard (plantilla proyectada 26/27, los 18 equipos)',
    '',
    'Como usar: revisa la columna Jugador/Equipo. Dime que filas SOBRAN (canteranos, gente que ya no cuenta, cruces mal hechos...)',
    'y las elimino del modelo. Si prefieres, tambien puedes borrar directamente las filas que no quieres y devolverme el Excel',
    'con solo las que SI quieres mantener -- lo que me digas.',
    '',
    'Posición primaria / secundaria -- OJO, dos fuentes distintas segun el jugador:',
    '- Altas confirmadas por ti o investigadas este trabajo (columna Estado = "Alta (fuera ACB / confirmada)"): Posición primaria',
    '  es Base/Escolta/Alero/Ala-Pívot/Pívot (tu Excel), Posición secundaria es el detalle que confirmaste o que investigue.',
    '- Resto de jugadores (se quedan o vienen de otro equipo ACB): Posición primaria es una agrupacion generica (Base/Escolta,',
    '  Alero/Ala-Pívot, Pívot) derivada del modelo de rating, y Posición secundaria es el codigo de posicion tal cual lo trae',
    '  la base de referencia de la ACB (GF, PF, SF...) -- son datos de terceros, no confirmados por ti.',
    '',
    'Edad -- marcada en ROJO cuando falta: solo tengo fecha de nacimiento para los jugadores que investigue/confirmaste en el',
    'Excel de posiciones (las altas). Para el resto (jugadores que ya estaban en la ACB la temporada pasada, ~220 de los 348),',
    'no tengo esa fuente todavia. Si la necesitas para la auditoria, dimelo y la investigo (es un trabajo mas grande, va a llevar',
    'un rato -- por eso no la meti sin preguntar).',
    '',
    'Altura -- para los jugadores ya en ACB viene de una tabla de referencia en pies-pulgadas convertida a metros; puede tener',
    'algun hueco si el jugador no esta en esa tabla.',
]
for i, l in enumerate(lines, start=1):
    ws2.cell(row=i, column=1, value=l).font = Font(name=FONT, size=10, bold=(i == 1))
    ws2.cell(row=i, column=1).alignment = Alignment(wrap_text=True, vertical='top')

wb.save('Jugadores_dashboard_26-27_auditoria.xlsx')
print('OK')

# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Prototipo del modelo de impacto de fichajes a nivel de JUGADOR — Valencia Basket
(fase 2, sobre el fichero "Fichajes - ACB" con histórico de 2 temporadas +
nivel de liga + contexto de ritmo, para los fichajes sin boxscore ACB propio).

Unidad de valor: la misma que en 24_fichajes_impact.py — Game Score por partido
(Hollinger), calculada aquí sobre las medias por partido que trae el fichero
("All Teams" = agregado de todas las competiciones de esa temporada).

Traducción de nivel de liga: igual que la traducción FEB->ACB ya usada en el
dashboard (fila 23_calibrate_weighted.py: coeficiente + penalización, aplicados
sobre desviaciones estándar de la distribución real de referencia), pero aquí
calibrada sobre la desviación estándar real del Game Score/PJ de jugadores ACB
cualificados (>=15 partidos y >=12 MPG), no sobre datos inventados.
"""
import pandas as pd
import numpy as np
from scipy import stats as sps

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 60)
pd.set_option('display.max_rows', 200)

# ---------------- 1) referencia ACB: distribución de Game Score/PJ ----------------
ps = pd.read_csv('player_season.csv')
ps['GmSc_total'] = (ps['PTS'] + 0.4*ps['FGM'] - 0.7*ps['FGA'] - 0.4*(ps['FTA']-ps['FTM'])
                     + 0.7*ps['OREB'] + 0.3*ps['DREB'] + ps['STL'] + 0.7*ps['AST']
                     + 0.7*ps['BLK'] - 0.4*ps['PF'] - ps['TOV'])
ps['GmSc_PJ'] = ps['GmSc_total'] / ps['games']

qualified = ps[~ps['bajo_volumen']]
ACB_MEAN = qualified['GmSc_PJ'].mean()
ACB_STD = qualified['GmSc_PJ'].std(ddof=0)
print(f"Referencia ACB (jugadores cualificados, n={len(qualified)}): "
      f"GmSc/PJ media={ACB_MEAN:.2f}  std={ACB_STD:.2f}")

# ---------------- 2) traducción de nivel de liga ----------------
# Desplazamiento en unidades de desviación estándar del Game Score/PJ de referencia ACB.
# Mismo espíritu que el coeficiente FEB->ACB (23_calibrate_weighted.py): un jugador
# que produce X en una liga más floja que la ACB, produciría menos en ACB, y viceversa.
# Calibración editorial de primer corte (documentada, ajustable):
LEVEL_SHIFT_SD = {
    'Higher': +0.35,       # liga más exigente que ACB -> se espera que rinda MEJOR en ACB
    'Same': 0.0,           # nivel comparable (p.ej. otro equipo ACB, o liga de fuerza similar)
    'Lower level': -0.55,  # liga más floja -> se descuenta
    'Much lower': -1.00,   # liga bastante más floja (2ª FEB, NCAA, G-League...) -> descuento fuerte
}

# ---------------- 3) cargar fichero de fichajes con histórico ----------------
mk = pd.read_csv('/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/92425b6a-Fichajes_-_ACB_-_Hoja_1.csv')

def gmsc_pj_row(r):
    return (r['PTS'] + 0.4*r['FGM'] - 0.7*r['FGA'] - 0.4*(r['FTA']-r['FTM'])
            + 0.7*r['ORB'] + 0.3*r['DRB'] + r['STL'] + 0.7*r['AST']
            + 0.7*r['BLK'] - 0.4*r['PF'] - r['TOV'])

mk['GmSc_PJ_raw'] = mk.apply(gmsc_pj_row, axis=1)

# fila de temporada agregada: 'All Teams' o, si solo jugó en un equipo esa temporada, esa única fila
def season_rows(df_player):
    out = []
    for season, sub in df_player.groupby('Season', sort=False):
        agg = sub[sub['Team'] == 'All Teams']
        if len(agg) == 1:
            out.append(agg.iloc[0])
        elif len(sub) == 1:
            out.append(sub.iloc[0])
        else:
            # varias filas sin 'All Teams' explícito -> coger la de más partidos (competición principal)
            out.append(sub.sort_values('GP', ascending=False).iloc[0])
    return out

RECENCY_WEIGHTS = [0.65, 0.35]  # temporada más reciente primero

players_out = []
for player, sub in mk.groupby('Player', sort=False):
    sub = sub.copy()
    # ordenar temporadas de más reciente a más antigua (el string de temporada empieza por el año)
    rows = season_rows(sub)
    rows = sorted(rows, key=lambda r: str(r['Season']), reverse=True)[:2]

    blended = 0.0
    wsum = 0.0
    detail = []
    for w, r in zip(RECENCY_WEIGHTS, rows):
        shift = LEVEL_SHIFT_SD.get(r['Level'], 0.0) * ACB_STD
        adj = r['GmSc_PJ_raw'] + shift
        blended += w * adj
        wsum += w
        detail.append({
            'season': r['Season'], 'team': r['Team'], 'league': r['League'],
            'gp': r['GP'], 'min': r['MIN'], 'gmsc_pj_raw': round(r['GmSc_PJ_raw'], 2),
            'level': r['Level'], 'context': r['Context'],
            'shift_sd': round(shift / ACB_STD, 2), 'gmsc_pj_adj': round(adj, 2),
        })
    blended /= wsum
    z = (blended - ACB_MEAN) / ACB_STD
    rating_100 = int(round(np.clip(50 + z*15, 1, 99)))

    players_out.append({
        'player': player,
        'gmsc_pj_acb_equiv': round(blended, 2),
        'z_vs_acb': round(z, 2),
        'rating_0_100': rating_100,
        'temporadas': detail,
    })

for p in players_out:
    print(f"\n{p['player']}: GmSc/PJ equiv. ACB = {p['gmsc_pj_acb_equiv']}  (z={p['z_vs_acb']})  Rating = {p['rating_0_100']}/100")
    for d in p['temporadas']:
        print(f"   {d['season']}  {d['team']} ({d['league']})  GP={d['gp']}  MIN={d['min']}  "
              f"GmSc/PJ bruto={d['gmsc_pj_raw']}  nivel={d['level']} ({d['shift_sd']:+.2f} SD)  "
              f"-> ajustado={d['gmsc_pj_adj']}   contexto={d['context']}")

import json
def _default(o):
    if hasattr(o, 'item'):
        return o.item()
    return str(o)

# ============================================================================
# 4) ROL / ARQUETIPO ESPERADO — misma lógica de percentiles que 12_classify.py,
#    referencia = jugadores ACB cualificados (roster_matched.csv) por pos_group.
#    Posición asignada a cada fichaje por conocimiento público (no viene en el
#    fichero) -- se documenta explícitamente cada asignación.
# ============================================================================
rm = pd.read_csv('roster_matched.csv')
POS_MAP = {'G':'Guard','PG':'Guard','SG':'Guard','F':'Forward','SF':'Forward','PF':'Forward',
           'GF':'Forward','C':'Center','FC':'Center','-':None}
rm['pos_group'] = rm['Pos'].map(POS_MAP)
qualified_rm = rm['nickname'].notna() & (rm['bajo_volumen']==False)
METRICS = ['USG%','AST%','TS%','3PAr','FTr']
REF = {grp: {m: rm.loc[qualified_rm & (rm['pos_group']==grp), m].dropna().values for m in METRICS}
       for grp in ['Guard','Forward','Center']}

def pct(grp, m, val):
    ref = REF[grp][m]
    if val is None or pd.isna(val) or len(ref) < 5:
        return np.nan
    return sps.percentileofscore(ref, val, kind='mean')

AST_ABS_MIN = 18  # igual que 12_classify.py: suelo absoluto de AST% para "Post Player" pasador

def classify(pos_group, ast_pct, usg_pct, ts_pct, threepar_pct, ftr_pct, ppg, height_m,
             ast_raw=None, usg_raw=None):
    g = pos_group
    if any(pd.isna(v) for v in [ast_pct, usg_pct, ts_pct, threepar_pct, ftr_pct]) or pd.isna(ppg):
        return 'Sin datos (métricas incompletas)'
    elite_scorer = (ppg > 15.5 and ast_pct < 80) or (usg_pct >= 70 and ts_pct >= 65) or (usg_pct >= 80 and ppg >= 14)
    if g == 'Guard':
        if ast_pct >= 80 and usg_pct >= 55: return 'Primary Ball Handler'
        if ast_pct >= 80 and usg_pct < 55: return 'Floor General'
        if ppg > 15.5 and ast_pct < 80: return 'Elite Scorer'
        if 40 <= ast_pct <= 80 and 45 <= usg_pct <= 90: return 'Secondary Ball Handler'
        if elite_scorer: return 'Elite Scorer'
        if threepar_pct >= 75 and usg_pct < 55: return 'Spot-Up Shooter'
        if usg_pct >= 50: return 'Scorer'
        return 'Spot-Up Shooter'
    if g == 'Forward':
        tall = height_m > 2.00 if height_m is not None else False
        if tall and ppg >= 9 and usg_pct >= 35: return 'Three-Level Wing Scorer'
        if elite_scorer: return 'Elite Scorer'
        if ftr_pct >= 70 and threepar_pct <= 45: return 'Slasher'
        if threepar_pct >= 75: return 'Spot-Up Shooter'
        if usg_pct >= 50: return 'Three-Level Wing Scorer' if (tall and ppg>=9) else 'Scorer'
        return 'Spot-Up Shooter'
    if g == 'Center':
        if ast_pct >= 75 and (ast_raw is not None and ast_raw >= AST_ABS_MIN): return 'Post Player'
        if (usg_raw is not None and usg_raw >= 16) and ppg >= 5: return 'Post Player'
        if threepar_pct >= 70: return 'Stretch Big'
        return 'Roller'
    return 'Sin clasificar'

# posición asumida (conocimiento público, no en el fichero) y altura aproximada donde aplica
POS_ASSUMED = {
    'TJ Shorts': ('Guard', None),
    'Armoni Brooks': ('Guard', None),
    'Mo Gueye': ('Center', 2.06),
    'Lucas Marí': ('Forward', 1.98),
    'Nikola Mirotic': ('Forward', 2.08),
    'Dylan Osetkowski': ('Forward', 2.06),
    'Mario Saint-Supery': ('Guard', None),
}

# AVISO DE CALIDAD DE DATOS: en las filas 'All Teams' (y en alguna fila de equipo único)
# de Lucas Marí y Mario Saint-Supery, el bloque de métricas avanzadas (USG% en adelante)
# viene desplazado/corrupto en el fichero de origen (p.ej. USG%=134.9 o 169.2, TS%=5.3 o
# 20.1 -- valores imposibles). Se detectó comparando contra las filas de competición
# individual del mismo jugador, que sí son coherentes, y se usan esas en su lugar SOLO
# para el rol (el Game Score, que usa las columnas de boxscore en bruto, no está afectado).
ROLE_ROW_OVERRIDE = {
    'Lucas Marí': ('2024-25 *', "CB L'Horta Godella"),       # Segunda FEB, GP=22, fila fiable
    'Mario Saint-Supery': ('2024-25 *', 'BAXI Manresa ACB'),  # marcador especial, ver abajo
}

for p in players_out:
    name = p['player']
    pos_group, height_m = POS_ASSUMED.get(name, (None, None))
    if name in ROLE_ROW_OVERRIDE:
        season_ov, team_ov = ROLE_ROW_OVERRIDE[name]
        if team_ov == 'BAXI Manresa ACB':
            r = mk[(mk['Player']==name) & (mk['Season']==season_ov) & (mk['Team']=='BAXI Manresa') & (mk['League']=='ACB')].iloc[0]
        else:
            r = mk[(mk['Player']==name) & (mk['Season']==season_ov) & (mk['Team']==team_ov)].iloc[0]
        p['role_data_quality_note'] = (f"fila '{p['temporadas'][0]['season']}/{p['temporadas'][0]['team']}' con métricas "
                                        f"avanzadas corruptas en el fichero; rol calculado con {season_ov}/{team_ov} en su lugar")
    else:
        # usar la temporada más reciente (primer elemento de 'temporadas') para el perfil de rol
        d0 = p['temporadas'][0]
        r = mk[(mk['Player']==name) & (mk['Season']==d0['season']) & (mk['Team']==d0['team'])].iloc[0]
    # NOTA de formato del fichero: FG%/3P%/FT%/TS%/eFG% vienen en escala x10 (573.0 = 57.3%);
    # ORB%/DRB%/TRB%/AST%/TOV%/STL%/BLK%/USG% ya vienen en escala normal (0-100). Verificado
    # contra los valores de boxscore reales de estos mismos jugadores.
    usg, ast, ppg = r['USG%'], r['AST%'], r['PTS']
    ts_raw = r['TS%'] / 10
    p3ar_raw = (r['3PA'] / r['FGA'] * 100) if r['FGA'] else np.nan
    ftr_raw = (r['FTA'] / r['FGA'] * 100) if r['FGA'] else np.nan
    p['pos_group_asumido'] = pos_group
    if pos_group:
        # classify() espera PERCENTILES (0-100) frente a la referencia ACB por posición,
        # igual que 12_classify.py -- no los valores brutos.
        usg_pct = pct(pos_group,'USG%',usg); ast_pct = pct(pos_group,'AST%',ast)
        ts_pct = pct(pos_group,'TS%',ts_raw); p3ar_pct = pct(pos_group,'3PAr',p3ar_raw)
        ftr_pct = pct(pos_group,'FTr',ftr_raw)
        p['role'] = classify(pos_group, ast_pct, usg_pct, ts_pct, p3ar_pct, ftr_pct, ppg, height_m,
                              ast_raw=ast, usg_raw=usg)
        p['role_pctl'] = {
            'USG%': round(usg_pct,0) if not pd.isna(usg_pct) else None,
            'AST%': round(ast_pct,0) if not pd.isna(ast_pct) else None,
            'TS%': round(ts_pct,0) if not pd.isna(ts_pct) else None,
            '3PAr': round(p3ar_pct,0) if not pd.isna(p3ar_pct) else None,
            'FTr': round(ftr_pct,0) if not pd.isna(ftr_pct) else None,
        }
        p['stats_temporada_usada'] = {'usg': round(usg,1), 'ast_pct': round(ast,1),
                                       'ts_pct': round(ts_raw,1), '3par': round(p3ar_raw,1),
                                       'ftr': round(ftr_raw,1), 'ppg': round(ppg,1)}
    else:
        p['role'] = 'Sin clasificar (posición no asignada)'
        p['role_pctl'] = {}

print("\n\n=== ROL / ARQUETIPO ESPERADO ===")
for p in players_out:
    print(f"{p['player']:22s} pos={p['pos_group_asumido']:8s} -> {p['role']}   "
          f"(percentiles vs ACB: USG%={p['role_pctl'].get('USG%')}  AST%={p['role_pctl'].get('AST%')}  TS%={p['role_pctl'].get('TS%')})")
    if 'role_data_quality_note' in p:
        print(f"   [AVISO CALIDAD DE DATOS] {p['role_data_quality_note']}")

# ============================================================================
# 5) BAJAS de Valencia (ya medidas, de fichajes_impact.json) en la MISMA escala
#    0-100 que los fichajes, para poder sumar y restar de forma consistente.
# ============================================================================
with open('fichajes_impact.json', encoding='utf-8') as f:
    fichajes = json.load(f)
valencia = fichajes['Valencia Basket']

bajas_out = []
for b in valencia['detalle_bajas_medibles']:
    z = (b['gmsc_pj'] - ACB_MEAN) / ACB_STD
    rating_100 = int(round(np.clip(50 + z*15, 1, 99)))
    bajas_out.append({**b, 'rating_0_100': rating_100})

# altas ya medidas por el pipeline ACB->ACB (Corbalán, Valtonen) -> misma escala
altas_acb_out = []
for a in valencia['detalle_altas_medibles']:
    z = (a['gmsc_pj'] - ACB_MEAN) / ACB_STD
    rating_100 = int(round(np.clip(50 + z*15, 1, 99)))
    altas_acb_out.append({**a, 'rating_0_100': rating_100})

print("\n=== BAJAS medibles de Valencia (misma escala 0-100) ===")
for b in sorted(bajas_out, key=lambda x: -x['rating_0_100']):
    print(f"  -{b['jugador']:20s} GmSc/PJ={b['gmsc_pj']:6.2f}  Rating={b['rating_0_100']}/100  -> {b['procedencia_destino']}")

print("\n=== ALTAS ya medibles vía traspaso ACB->ACB (misma escala 0-100) ===")
for a in sorted(altas_acb_out, key=lambda x: -x['rating_0_100']):
    print(f"  +{a['jugador']:20s} GmSc/PJ={a['gmsc_pj']:6.2f}  Rating={a['rating_0_100']}/100  <- {a['procedencia_destino']}")

# ============================================================================
# 6) RATING ESPERADO DEL EQUIPO — diferencia sumada y restada
# ============================================================================
sum_altas_gmsc = sum(p['gmsc_pj_acb_equiv'] for p in players_out) + sum(a['gmsc_pj'] for a in altas_acb_out)
sum_bajas_gmsc = sum(b['gmsc_pj'] for b in bajas_out)
net_swing_gmsc = sum_altas_gmsc - sum_bajas_gmsc

n_altas_medidas = len(players_out) + len(altas_acb_out)
n_bajas_medidas = len(bajas_out)

print(f"\n=== DIFERENCIA SUMADA Y RESTADA (Valencia Basket, {n_altas_medidas} altas medidas de 11-12, "
      f"{n_bajas_medidas} bajas medidas de {valencia['bajas_total']}) ===")
print(f"  Suma GmSc/PJ altas medibles (equiv. ACB):  +{sum_altas_gmsc:.2f}")
print(f"  Suma GmSc/PJ bajas medibles:                -{sum_bajas_gmsc:.2f}")
print(f"  Balance neto medible:                       {net_swing_gmsc:+.2f}")

# conversión empírica GmSc-sum -> NetRtg, calibrada con los 16 equipos reales de ACB
# (ver comprobación de correlación aparte: R^2 ~ 0.34 -- moderada, no fuerte)
SLOPE_NETRTG_PER_GMSC = 0.2936
current_netrtg = 14.5  # Valencia Basket 25/26 (TEAMS.netrtg)
projected_netrtg_delta = net_swing_gmsc * SLOPE_NETRTG_PER_GMSC
projected_netrtg = current_netrtg + projected_netrtg_delta

print(f"\n  Traducción a Net Rating (conversión empírica, R²=0.34 -- moderada, ver caveat):")
print(f"  ΔNetRtg proyectado = {net_swing_gmsc:.2f} x {SLOPE_NETRTG_PER_GMSC} = {projected_netrtg_delta:+.2f}")
print(f"  NetRtg actual (25/26) = {current_netrtg}  ->  NetRtg proyectado (26/27, solo por fichajes medibles) = {projected_netrtg:.1f}")

with open('valencia_player_ratings.json', 'w', encoding='utf-8') as f:
    json.dump({
        'altas_nuevas_fichas': players_out,
        'bajas': bajas_out,
        'altas_ya_medidas_acb': altas_acb_out,
        'resumen': {
            'sum_altas_gmsc': round(sum_altas_gmsc,2),
            'sum_bajas_gmsc': round(sum_bajas_gmsc,2),
            'net_swing_gmsc': round(net_swing_gmsc,2),
            'current_netrtg': current_netrtg,
            'projected_netrtg_delta': round(projected_netrtg_delta,2),
            'projected_netrtg': round(projected_netrtg,2),
        }
    }, f, ensure_ascii=False, indent=1, default=_default)

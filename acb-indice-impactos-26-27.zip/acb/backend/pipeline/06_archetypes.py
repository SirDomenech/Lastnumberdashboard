import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 100)

season = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
df = season.join(track, how='left')

# extra rate metric: fouls committed per 100 possessions
df['PF_per100'] = df['PF'] / df['POSS'] * 100

def zg(col, invert=False):
    """z-score in the 'goodness for this archetype' direction."""
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

# =========================================================================
# Archetype definitions: metric -> invert (True = "lower raw value = better fit")
# =========================================================================
OFFENSE_ARCHETYPES = {
    'Ritmo y Espacio': {'Pace': False, '3PAr': False, 'eFG%': False, '3P%': False},
    'Baloncesto de Control': {'Pace': True, 'TOV%': True, 'TS%': False},
    'Juego Coral (Pase y Corte)': {'AST%': False, 'AST/TOV': False},
    'Juego Interior y Físico': {'ORB%': False, 'FTr': False, 'ptsPIN_per100pos': False, 'ptsRO_per100pos': False},
}

DEFENSE_ARCHETYPES = {
    'Cierre de Pintura (Contención)': {'DRB%': False, 'Opp_2P%': True, 'r_ptsPIN_per100pos': True, 'Opp_FTr': True},
    'Presión y Agresividad': {'Opp_TOV%': False, 'STL%': False},
    'Defensa de Cambios (Versatilidad)': {'Opp_AST%': True, 'Opp_eFG%': True},
    'Balance Defensivo y Equilibrio': {'r_ptsCA_per100pos': True, 'DRB%': False, 'PF_per100': True},
}

TARGET = 1.4  # idealized "exemplar" intensity in goodness-z units for every defining dimension

def classify(block, name):
    dist = pd.DataFrame(index=df.index)
    for arch, metrics in block.items():
        zs = pd.DataFrame({m: zg(m, invert=inv) for m, inv in metrics.items()})
        # RMS distance (mean, not sum) so archetypes defined by different numbers of
        # metrics are comparable — summing would systematically favor archetypes with
        # fewer defining dimensions (smaller max possible distance).
        d = np.sqrt(((zs - TARGET) ** 2).mean(axis=1))
        dist[arch] = d
    best = dist.idxmin(axis=1)
    best_dist = dist.min(axis=1)
    second = dist.apply(lambda r: r.nsmallest(2).index[1], axis=1)
    second_dist = dist.apply(lambda r: r.nsmallest(2).values[1], axis=1)
    result = pd.DataFrame({
        f'{name}_arquetipo': best,
        f'{name}_dist': best_dist.round(2),
        f'{name}_secundario': second,
        f'{name}_dist_secundario': second_dist.round(2),
    })
    return result, dist.round(2)

off_result, off_dist = classify(OFFENSE_ARCHETYPES, 'Ataque')
def_result, def_dist = classify(DEFENSE_ARCHETYPES, 'Defensa')

final = pd.concat([off_result, def_result], axis=1)
print(final.to_string())

print("\n--- Distancias completas ataque (menor = mejor encaje) ---")
print(off_dist.to_string())
print("\n--- Distancias completas defensa ---")
print(def_dist.to_string())

print("\n--- Recuento de arquetipos ---")
print("Ataque:\n", final['Ataque_arquetipo'].value_counts())
print("Defensa:\n", final['Defensa_arquetipo'].value_counts())

final.to_csv('team_archetypes.csv')
off_dist.to_csv('archetype_distances_offense.csv')
def_dist.to_csv('archetype_distances_defense.csv')
print("\nsaved team_archetypes.csv")

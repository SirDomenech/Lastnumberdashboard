# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Modelo de rating de jugador — v2, reconstruido según indicaciones directas de Miguel:

1) Métricas: USG%, AST%, eFG%, TRB%, MPG, GP (fiabilidad de muestra), BLK, AST, PPG,
   FG%, 3P%, TOV%. Prioridad alta a USG%, AST% y MPG ("lo que más nos da registro
   de importancia").
2) Escala 0-100 por PERCENTIL directo frente a la referencia ACB (jugadores
   cualificados), no por z-score con compresión gaussiana -- así un jugador
   realmente elite puede llegar a 90+.
3) Blend de las 2 últimas temporadas ponderado por CONTEXTO (similar > distinto)
   y por partidos jugados (más muestra, más peso) -- no por recencia.
4) Ajuste de nivel de liga, aplicado por temporada antes del blend (igual espíritu
   que antes, ahora en puntos de percentil).
"""
import pandas as pd
import numpy as np
from scipy import stats as sps
import json

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 60)
pd.set_option('display.max_rows', 200)

# ============================================================================
# 1) referencia ACB: construir el pool de jugadores cualificados con TODAS las
#    métricas pedidas, incluidas las que no estaban ya en player_season.csv
#    (eFG%, TRB%, BPG).
# ============================================================================
ps = pd.read_csv('player_season.csv')

tg = pd.read_csv('team_game_full.csv')
team_trb = tg.groupby('Nombre equipo', as_index=False).agg(Team_TRB_season=('TRB','sum'), Opp_TRB_season=('Opp_TRB','sum'))
ps = ps.merge(team_trb, left_on='team_last', right_on='Nombre equipo', how='left')

MP = ps['MP_sec']/60
T_MP = ps['T_MPsec']/60
ps['eFG%'] = 100*(ps['FGM'] + 0.5*ps['P3M']) / ps['FGA']
ps['TRB%'] = 100*ps['TRB']*(T_MP/5) / (MP*(ps['Team_TRB_season']+ps['Opp_TRB_season']))
ps['BPG'] = ps['BLK']/ps['games']
ps['FG%'] = 100*ps['FGM']/ps['FGA']

qualified = ps[~ps['bajo_volumen']].copy()
print(f"Referencia ACB cualificados: n={len(qualified)}")

METRICS_DIRECTION = {
    'USG%': 1, 'AST%': 1, 'eFG%': 1, 'TRB%': 1, 'MPG': 1, 'BPG': 1, 'APG': 1,
    'PPG': 1, 'FG%': 1, '3P%': 1, 'TOV%': -1,  # TOV% invertido: menos es mejor
}
REF = {m: qualified[m if m not in ('BPG',) else 'BPG'].dropna().values for m in
       ['USG%','AST%','eFG%','TRB%','MPG','BPG','APG','PPG','FG%','3P%','TOV%']}
# nota: FG% aquí = FGM/FGA de player_season.csv (0-100 ya)

def pctl(metric, value, invert=False):
    ref = REF[metric]
    if value is None or pd.isna(value) or len(ref) < 5:
        return np.nan
    p = sps.percentileofscore(ref, value, kind='mean')
    return 100 - p if invert else p

# ---- pesos: prioridad alta a USG%, AST%, MPG; resto peso base ----
WEIGHTS_METRIC = {
    'USG%': 2.5, 'AST%': 2.5, 'MPG': 2.5,
    'eFG%': 1.0, 'TRB%': 1.0, 'BPG': 1.0, 'APG': 1.0, 'PPG': 1.0, 'FG%': 1.0, '3P%': 1.0, 'TOV%': 1.0,
}
WSUM = sum(WEIGHTS_METRIC.values())

# ============================================================================
# 2) nivel de liga -- ajuste en PUNTOS DE PERCENTIL (no SD), aplicado por
#    temporada antes de blendear. Mismo espíritu, escala nueva.
# ============================================================================
LEVEL_SHIFT_PTS = {
    'Higher': +8,
    'Same': 0,
    'Lower level': -12,
    'Much lower': -20,
}
# ---- contexto: pondera qué temporada pesa más en el blend (no la recencia) ----
CONTEXT_MULT = {'Similar': 1.0, 'Slower': 0.4, 'Other context': 0.4}

# ============================================================================
# 3) cargar fichero de fichajes y calcular percentil compuesto por temporada
# ============================================================================
mk = pd.read_csv('/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/92425b6a-Fichajes_-_ACB_-_Hoja_1.csv')

def season_rows(df_player):
    out = []
    for season, sub in df_player.groupby('Season', sort=False):
        agg = sub[sub['Team'] == 'All Teams']
        if len(agg) == 1:
            out.append(agg.iloc[0])
        elif len(sub) == 1:
            out.append(sub.iloc[0])
        else:
            out.append(sub.sort_values('GP', ascending=False).iloc[0])
    return out

def row_metrics(r):
    """extrae las métricas pedidas de una fila del fichero, corrigiendo la escala
    x10 de FG%/3P%/FT%/TS%/eFG% que trae el fichero de origen."""
    fga = r['FGA'] if r['FGA'] else np.nan
    return {
        'USG%': r['USG%'],
        'AST%': r['AST%'],
        'eFG%': r['eFG%']/10 if not pd.isna(r['eFG%']) else np.nan,
        'TRB%': r['TRB%'],
        'MPG': r['MIN'],
        'BPG': r['BLK'],
        'APG': r['AST'],
        'PPG': r['PTS'],
        'FG%': r['FG%']/10 if not pd.isna(r['FG%']) else np.nan,
        '3P%': r['3P%']/10 if not pd.isna(r['3P%']) else np.nan,
        'TOV%': r['TOV%'],
    }

# filas con métricas avanzadas corruptas en el fichero de origen (detectadas en la
# vuelta anterior): se sustituyen por una fila de competición fiable del mismo jugador.
CORRUPT_ROW_FIX = {
    ('Lucas Marí', '2024-25 *', 'All Teams'): ('2024-25 *', "CB L'Horta Godella"),
    ('Lucas Marí', '2025-26', 'Vermont'): None,  # sin alternativa fiable esa temporada -> se descarta
    ('Mario Saint-Supery', '2024-25 *', 'All Teams'): ('2024-25 *', 'BAXI Manresa'),
    ('Nikola Mirotic', '2024-25 *', 'All Teams'): ('2024-25 *', 'AX Armani Exchange Milan'),  # fila Lega A, la más fiable
    ('Mario Saint-Supery', '2025-26', 'Gonzaga'): None,  # USG%=169 imposible, sin alternativa esa temporada
}

players_out = []
for player, sub in mk.groupby('Player', sort=False):
    sub = sub.copy()
    rows = season_rows(sub)
    rows = sorted(rows, key=lambda r: str(r['Season']), reverse=True)[:2]

    detail = []
    for r in rows:
        key = (player, r['Season'], r['Team'])
        if key in CORRUPT_ROW_FIX:
            fix = CORRUPT_ROW_FIX[key]
            if fix is None:
                continue  # descartar esta temporada, sin sustituto fiable
            season_ov, team_ov = fix
            r = mk[(mk['Player']==player) & (mk['Season']==season_ov) & (mk['Team']==team_ov)].iloc[0]

        m = row_metrics(r)
        pcts = {k: pctl(k, v, invert=(METRICS_DIRECTION[k]==-1)) for k, v in m.items()}
        valid_pcts = {k: v for k, v in pcts.items() if not pd.isna(v)}
        if not valid_pcts:
            continue
        composite = sum(WEIGHTS_METRIC[k]*v for k, v in valid_pcts.items()) / sum(WEIGHTS_METRIC[k] for k in valid_pcts)
        level = r['Level']; context = r['Context']
        composite_adj = composite + LEVEL_SHIFT_PTS.get(level, 0)
        w = r['GP'] * CONTEXT_MULT.get(context, 0.4)
        detail.append({
            'season': r['Season'], 'team': r['Team'], 'league': r['League'], 'gp': int(r['GP']),
            'level': level, 'context': context, 'blend_weight': round(w,1),
            'composite_pctl_bruto': round(composite,1), 'composite_pctl_ajustado': round(composite_adj,1),
            'metrics_raw': {k: round(v,1) if not pd.isna(v) else None for k,v in m.items()},
            'metrics_pctl': {k: round(v,0) if not pd.isna(v) else None for k,v in pcts.items()},
        })

    if not detail:
        players_out.append({'player': player, 'rating_0_100': None, 'temporadas': []})
        continue

    wsum = sum(d['blend_weight'] for d in detail)
    rating = sum(d['blend_weight']*d['composite_pctl_ajustado'] for d in detail) / wsum
    rating = int(round(np.clip(rating, 1, 99)))

    players_out.append({'player': player, 'rating_0_100': rating, 'temporadas': detail})

print("\n=== RATING DE JUGADOR v2 (percentil compuesto, ponderado por contexto+muestra) ===")
for p in players_out:
    print(f"\n{p['player']}: Rating = {p['rating_0_100']}/100")
    for d in p['temporadas']:
        print(f"   {d['season']}  {d['team']} ({d['league']})  GP={d['gp']}  nivel={d['level']}  contexto={d['context']}  "
              f"peso_blend={d['blend_weight']}  percentil_bruto={d['composite_pctl_bruto']}  ajustado={d['composite_pctl_ajustado']}")

with open('valencia_player_ratings_v2.json', 'w', encoding='utf-8') as f:
    def _default(o):
        return o.item() if hasattr(o,'item') else str(o)
    json.dump(players_out, f, ensure_ascii=False, indent=1, default=_default)

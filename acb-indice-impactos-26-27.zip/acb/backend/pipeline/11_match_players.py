import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np
import unicodedata
import difflib

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 60)

ROSTER = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/78e30e16-ACB_Players__Hoja_1_1.csv"
roster = pd.read_csv(ROSTER)
stats = pd.read_csv('player_season.csv')

TEAM_MAP = {
    'UCAM Murcia CB': 'UCAM Murcia',
    'Real Madrid': 'Real Madrid',
    'Lenovo Tenerife': 'La Laguna Tenerife',
    'Forca Lleida CE': 'Hiopos Lleida',
    'BAXI Manresa': 'BAXI Manresa',
    'Dreamland Gran Canaria': 'Dreamland Gran Canaria',
    'Casademont Zaragoza': 'Casademont Zaragoza',
    'CB Granada': 'Coviran Granada',
    'Joventut Badalona': 'Joventut Badalona',
    'Siblo San Pablo Burgos': 'Recoletas Salud San Pablo Burgos',
    'Rio Breogan': 'Río Breogán',
    'Baskonia': 'Baskonia',
    'Unicaja': 'Unicaja',
    'Valencia Basket': 'Valencia Basket',
    'Bilbao Basket': 'Surne Bilbao Basket',
    'MoraBanc Andorra': 'MoraBanc Andorra',
    'Barca': 'Barça',
    'CB Girona': 'Bàsquet Girona',
}
roster['team_box'] = roster['Team'].map(TEAM_MAP)
assert roster['team_box'].isna().sum() == 0, "unmapped team names!"

def norm(s):
    if pd.isna(s):
        return ''
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode('ascii')
    s = s.lower().strip()
    s = ' '.join(s.split())
    return s

roster['name_norm'] = roster['Player'].map(norm)
stats['name_norm'] = stats['nickname'].map(norm)

# index stats by normalized name -> list of rows (names can repeat across teams if traded, rare)
stats_by_name = {}
for i, row in stats.iterrows():
    stats_by_name.setdefault(row['name_norm'], []).append(i)

matched_rows = []
unmatched = []
fuzzy_matches = []

stats_names = list(stats['name_norm'].unique())

for i, r in roster.iterrows():
    cands = stats_by_name.get(r['name_norm'])
    match_idx = None
    method = None
    if cands:
        if len(cands) == 1:
            match_idx = cands[0]
        else:
            # multiple players with same normalized name -> prefer same team
            same_team = [c for c in cands if stats.loc[c, 'team_last'] == r['team_box']]
            match_idx = same_team[0] if same_team else cands[0]
        method = 'exact'
    else:
        # fuzzy fallback: closest normalized name, require decent similarity,
        # prefer same team among close candidates
        close = difflib.get_close_matches(r['name_norm'], stats_names, n=3, cutoff=0.82)
        if close:
            # try to find one on the same team first
            best = None
            for c in close:
                idxs = stats_by_name[c]
                same_team = [ix for ix in idxs if stats.loc[ix, 'team_last'] == r['team_box']]
                if same_team:
                    best = same_team[0]
                    break
            if best is None:
                best = stats_by_name[close[0]][0]
            match_idx = best
            method = 'fuzzy'
            fuzzy_matches.append((r['Player'], r['team_box'], stats.loc[match_idx, 'nickname'], stats.loc[match_idx, 'team_last']))

    if match_idx is not None:
        row = stats.loc[match_idx].to_dict()
        row.pop('name_norm', None)
        row['roster_idx'] = i
        row['match_method'] = method
        row['team_match'] = (stats.loc[match_idx, 'team_last'] == r['team_box'])
        matched_rows.append(row)
    else:
        unmatched.append(i)

matched_df = pd.DataFrame(matched_rows).set_index('roster_idx')
merged = roster.join(matched_df, how='left')

print(f"Roster total: {len(roster)}")
print(f"Matched: {merged['nickname'].notna().sum()}  ({merged['match_method'].eq('exact').sum()} exact, {merged['match_method'].eq('fuzzy').sum()} fuzzy)")
print(f"Sin datos (no match in box score): {merged['nickname'].isna().sum()}")
print(f"Matched but different team (traded / roster change): {(~merged['team_match'].fillna(True)).sum()}")

print("\n--- Fuzzy matches (review) ---")
for f in fuzzy_matches:
    print(f)

print("\n--- Team mismatches (matched by name, different team) ---")
mism = merged[merged['team_match'] == False][['Player', 'Team', 'nickname', 'team_last']]
print(mism.to_string(index=False))

print("\n--- Unmatched (sin datos) ---")
un = merged[merged['nickname'].isna()][['Player', 'Pos', 'Team']]
print(un.to_string(index=False))

merged.to_csv('roster_matched.csv', index=False)

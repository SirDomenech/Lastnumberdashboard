import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np
import unicodedata

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 60)

BOX = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77c1dac6-Box_Scores_ACB.csv"
df = pd.read_csv(BOX)

NAME_MAP = {
    'Asisa Joventut': 'Joventut Badalona', 'Joventut Badalona': 'Joventut Badalona',
    'Kosner Baskonia': 'Baskonia', 'Baskonia': 'Baskonia',
    'Surne Bilbao': 'Surne Bilbao Basket', 'Surne Bilbao Basket': 'Surne Bilbao Basket',
}
df['Nombre equipo'] = df['Nombre equipo'].map(lambda x: NAME_MAP.get(x, x))
df['FGM'] = df['twoPointersMade'] + df['threePointersMade']
df['FGA'] = df['twoPointersAttempted'] + df['threePointersAttempted']
df['MP_sec'] = df['Segundos totales']

# ---- team-game totals (own team) needed as USG/AST% denominators ----
team_game_cols = ['points','freeThrowsMade','freeThrowsAttempted','FGM','FGA','assists','turnovers','MP_sec']
tg = df.groupby(['ID Partido','Nombre equipo'], as_index=False)[team_game_cols].sum()
tg = tg.rename(columns={'points':'T_PTS','freeThrowsMade':'T_FTM','freeThrowsAttempted':'T_FTA',
                         'FGM':'T_FGM','FGA':'T_FGA','assists':'T_AST','turnovers':'T_TOV','MP_sec':'T_MPsec'})

pg = df.merge(tg, on=['ID Partido','Nombre equipo'], how='left')

# ---- aggregate to player-season ----
agg = pg.groupby(['id','nickname'], as_index=False).agg(
    team_last=('Nombre equipo','last'),
    games=('ID Partido','nunique'),
    PTS=('points','sum'), FTM=('freeThrowsMade','sum'), FTA=('freeThrowsAttempted','sum'),
    P2M=('twoPointersMade','sum'), P2A=('twoPointersAttempted','sum'),
    P3M=('threePointersMade','sum'), P3A=('threePointersAttempted','sum'),
    FGM=('FGM','sum'), FGA=('FGA','sum'),
    AST=('assists','sum'), TOV=('turnovers','sum'), OREB=('offRebounds','sum'), DREB=('defRebounds','sum'),
    TRB=('totalRebounds','sum'), STL=('steals','sum'), BLK=('blocks','sum'), PF=('personalFouls','sum'),
    MP_sec=('MP_sec','sum'),
    T_PTS=('T_PTS','sum'), T_FTA=('T_FTA','sum'), T_FGM=('T_FGM','sum'), T_FGA=('T_FGA','sum'),
    T_AST=('T_AST','sum'), T_TOV=('T_TOV','sum'), T_MPsec=('T_MPsec','sum'),
)
agg['MPG'] = agg['MP_sec']/60/agg['games']
agg['PPG'] = agg['PTS']/agg['games']
agg['APG'] = agg['AST']/agg['games']

# ---- advanced metrics (standard formulas, season totals) ----
MP = agg['MP_sec']/60
T_MP = agg['T_MPsec']/60
agg['USG%'] = 100*((agg['FGA']+0.44*agg['FTA']+agg['TOV'])*(T_MP/5)) / (MP*(agg['T_FGA']+0.44*agg['T_FTA']+agg['T_TOV']))
agg['AST%'] = 100*agg['AST'] / (((MP/(T_MP/5))*agg['T_FGM']) - agg['FGM'])
agg['TS%'] = 100*agg['PTS'] / (2*(agg['FGA']+0.44*agg['FTA']))
agg['TOV%'] = 100*agg['TOV'] / (agg['FGA']+0.44*agg['FTA']+agg['TOV'])
agg['AST/TOV'] = agg['AST']/agg['TOV'].replace(0, np.nan)
agg['3PAr'] = agg['P3A']/agg['FGA']*100
agg['3P%'] = agg['P3M']/agg['P3A'].replace(0, np.nan)*100
agg['2P%'] = agg['P2M']/agg['P2A'].replace(0, np.nan)*100
agg['FTr'] = agg['FTA']/agg['FGA']*100

agg['bajo_volumen'] = (agg['games'] < 15) | (agg['MPG'] < 12)

print("Players aggregated:", len(agg))
print("Qualified (bajo_volumen=False):", (~agg['bajo_volumen']).sum())
agg.to_csv('player_season.csv', index=False)
print(agg[['nickname','team_last','games','MPG','PPG','USG%','AST%','TS%']].sort_values('PPG', ascending=False).head(15))

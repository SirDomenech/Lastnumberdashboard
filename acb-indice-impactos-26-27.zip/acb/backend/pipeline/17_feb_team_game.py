import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

BOX = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/f15db639-Box_Scores_FEB_Completo.csv"
df = pd.read_csv(BOX)

RENAME = {
    'URL PARTIDO': 'game_id', 'TEAM NAME': 'team',
    'TLC': 'FTM', 'TLI': 'FTA', 'T2C': 'P2M', 'T2I': 'P2A', 'T3C': 'P3M', 'T3I': 'P3A',
    'TCC': 'FGM', 'TCI': 'FGA', 'SEGUNDOS TOTALES': 'MP_sec',
    'TAPONES A FAVOR': 'BLK', 'TAPONES EN CONTRA': 'BLK_against',
    'REBOTES OFENSIVOS': 'OREB', 'REBOTES DEFENSIVOS': 'DREB', 'REBOTES TOTALES': 'TRB',
    'FALTAS RECIBIDAS': 'FoulsDrawn', 'PERDIDAS': 'TOV', 'ROBOS': 'STL',
    'ASISTENCIAS': 'AST', 'FALTAS PERSONALES': 'PF', 'PUNTOS': 'PTS',
    'GANADOR': 'winner',
}
df = df.rename(columns=RENAME)

NAME_MAP = {
    'CLUB OURENSE BALONCESTO': 'Ourense Baloncesto',
    'CLOUD.GAL OURENSE BALONCESTO ': 'Ourense Baloncesto',
}
df['team'] = df['team'].map(lambda x: NAME_MAP.get(x, x))

team_game_cols = ['PTS', 'FTM', 'FTA', 'P2M', 'P2A', 'P3M', 'P3A', 'FGM', 'FGA', 'AST',
                   'OREB', 'DREB', 'TRB', 'STL', 'TOV', 'BLK', 'BLK_against', 'PF', 'FoulsDrawn', 'MP_sec']

tg = df.groupby(['game_id', 'team'], as_index=False)[team_game_cols].sum()
tg['GP_flag'] = 1

# self-join para sacar el rival estructuralmente (mismo patrón que usamos en ACB: nunca por nombre de rival)
merged = tg.merge(tg, on='game_id', suffixes=('', '_opp'))
merged = merged[merged['team'] != merged['team_opp']].copy()

for c in team_game_cols:
    merged = merged.rename(columns={f'{c}_opp': f'Opp_{c}'})
merged = merged.rename(columns={'team_opp': 'Opp_Team'})

merged['POSS_own_est'] = merged['FGA'] - merged['OREB'] + merged['TOV'] + 0.44 * merged['FTA']
merged['POSS_opp_est'] = merged['Opp_FGA'] - merged['Opp_OREB'] + merged['Opp_TOV'] + 0.44 * merged['Opp_FTA']
merged['POSS_game'] = (merged['POSS_own_est'] + merged['POSS_opp_est']) / 2

merged.to_csv('feb_team_game_full.csv', index=False)
print(f"{merged['game_id'].nunique()} partidos, {merged['team'].nunique()} equipos")
print(merged.groupby('team')['game_id'].nunique())

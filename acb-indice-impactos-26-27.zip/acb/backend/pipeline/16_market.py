# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd

# Transcrito de la "Tabla de mercado de la Liga Endesa 2026-27" (gigantes.com)
# Formato: (Equipo, Tipo['Alta'|'Baja'], Jugador, Club_relacionado, Notas)
rows = []

def alta(team, player, from_club, notas=''):
    rows.append((team, 'Alta', player, from_club, notas))

def baja(team, player, to_club, notas=''):
    rows.append((team, 'Baja', player, to_club, notas))

# Real Madrid
alta('Real Madrid', 'Jaime Pradilla', 'Valencia Basket')
alta('Real Madrid', 'Timothe Luwawu-Cabarrot', 'Kosner Baskonia')
alta('Real Madrid', "Eli N'Diaye", 'Atlanta Hawks')
alta('Real Madrid', 'Mikael Jantunen', 'Fenerbahce')
alta('Real Madrid', 'Max Shulga', 'Boston Celtics')
alta('Real Madrid', 'Damian Jones', 'Vaqueros de Bayamon')
alta('Real Madrid', 'Olivier Sarr', 'Cleveland Cavaliers')
baja('Real Madrid', 'Mario Hezonja', 'Cleveland Cavaliers')
baja('Real Madrid', 'Trey Lyles', 'Minnesota Timberwolves')
baja('Real Madrid', 'Alex Len', '?')
baja('Real Madrid', 'Omer Yurtseven', '?')

# Valencia Basket
alta('Valencia Basket', 'TJ Shorts', 'Panathinaikos')
alta('Valencia Basket', 'Gonzalo Corbalan', 'Recoletas Salud San Pablo Burgos')
alta('Valencia Basket', 'Dylan Osetkowski', 'Partizan')
alta('Valencia Basket', 'Mario Saint-Supery', 'Gonzaga')
alta('Valencia Basket', 'Lucas Mari', 'Vermont')
alta('Valencia Basket', 'Oumar Ballo', 'Pallacanestro Cantu')
alta('Valencia Basket', 'Mo Gueye', 'Windy City Bulls')
alta('Valencia Basket', 'Wildens Leveque', 'Caceres Ciudad de Baloncesto')
alta('Valencia Basket', 'Armoni Brooks', 'ASVEL', 'cesion')
alta('Valencia Basket', 'Elias Valtonen', 'Coviran Granada')
alta('Valencia Basket', 'Jasiel Rivero', 'Maccabi Tel Aviv')
baja('Valencia Basket', 'Jean Montero', 'Olympiacos')
baja('Valencia Basket', 'Darius Thompson', 'EA7 Milano')
baja('Valencia Basket', 'Sergio De Larrea', 'Dallas Mavericks')
baja('Valencia Basket', 'Isaac Nogues', 'ASISA Joventut')
baja('Valencia Basket', 'Brancou Badio', 'Panathinaikos')
baja('Valencia Basket', 'Jaime Pradilla', 'Real Madrid')
baja('Valencia Basket', 'Braxton Key', 'Fenerbahce')
baja('Valencia Basket', 'Matt Costello', 'Chiba Jets')
baja('Valencia Basket', 'Joel Soriano', 'Monbus Obradoiro')
baja('Valencia Basket', 'Millan Jimenez', 'Movistar Estudiantes')

# Kosner Baskonia
alta('Baskonia', 'DJ Stewart', 'Cedevita Olimpija')
alta('Baskonia', 'Chris Duarte', 'Unicaja')
alta('Baskonia', 'AJ Lawson', 'Raptors 905')
alta('Baskonia', 'Damion Baugh', 'Calgary Surge')
alta('Baskonia', 'Kenneth Faried', 'Cangrejeros de Santurce')
baja('Baskonia', 'Trent Forrest', 'Fenerbahce')
baja('Baskonia', 'Timothe Luwawu-Cabarrot', 'Real Madrid')
baja('Baskonia', 'Gytis Radzevicius', 'Rytas Vilnius')
baja('Baskonia', 'Mamadi Diakite', 'Dubai Basketball')
baja('Baskonia', 'Jesse Edwards', 'SPQR Roma')
baja('Baskonia', 'Eugene Omoruyi', 'Besiktas')

# UCAM Murcia
alta('UCAM Murcia', 'Juani Marcos', 'FC Barcelona')
alta('UCAM Murcia', 'Souleyman Boum', 'BC Vienna')
alta('UCAM Murcia', 'Marcis Steinbergs', "Kids&Us Manresa")
alta('UCAM Murcia', 'Jean Marc Pansa', 'Sabah')
baja('UCAM Murcia', 'David DeJulius', 'Besiktas')
baja('UCAM Murcia', 'Dani Garcia', 'iLerna Lleida')
baja('UCAM Murcia', 'Jaylen Hands', 'SIG Strasbourg')
baja('UCAM Murcia', 'Kelan Martin', 'Illawarra Hawks')
baja('UCAM Murcia', 'Devontae Cacok', 'Hapoel Jerusalem')

# FC Barcelona
alta('Barça', 'Olivier Nkamhoua', 'Openjobmetis Varese')
alta('Barça', 'Josh Nebo', 'EA7 Emporio Armani Milan')
alta('Barça', 'Justin Robinson', 'Paris Basketball')
alta('Barça', 'Agustin Ubal', "Kids&Us Manresa")
alta('Barça', 'Umoja Gibson', 'Cedevita Olimpija')
alta('Barça', 'Tosan Evbuomwan', 'Charlotte Hornets')
alta('Barça', 'Stanley Umude', 'Austin Spurs')
alta('Barça', 'Tyrese Martin', 'Philadelphia 76ers')
alta('Barça', 'Olek Balcerowski', 'Unicaja')
alta('Barça', 'Yoan Makoundou', 'AS Monaco')
alta('Barça', 'Justin Minaya', 'Osceola Magic')
baja('Barça', 'Tomas Satoransky', 'Hapoel Tel Aviv')
baja('Barça', 'Juani Marcos', 'UCAM Murcia')
baja('Barça', 'Nico Laprovittola', 'ASISA Joventut')
baja('Barça', 'Miles Norris', 'FC Bayern Munich')
baja('Barça', 'Willy Hernangomez', 'Unicaja')
baja('Barça', 'Youssoupha Fall', 'Nanjing')
baja('Barça', 'Will Clyburn', 'Fenerbahce')
baja('Barça', 'Tornike Shengelia', 'Dubai Basketball')

# ASISA Joventut
alta('Joventut Badalona', 'Alex Reyes', "Kids&Us Manresa")
alta('Joventut Badalona', 'Isaac Nogues', 'Valencia Basket')
alta('Joventut Badalona', 'Nico Laprovittola', 'FC Barcelona')
alta('Joventut Badalona', 'Emir Sulejmanovic', 'Unicaja')
alta('Joventut Badalona', 'Yannick Kraag', 'Dubai Basketball', 'cesion')
alta('Joventut Badalona', 'Kwan Cheatham', 'Reggio Emilia')
alta('Joventut Badalona', 'Boogie Ellis', 'Dubai Basketball')
baja('Joventut Badalona', 'Adam Hanga', '?')
baja('Joventut Badalona', 'Cameron Hunt', 'Unicaja')
baja('Joventut Badalona', 'Henri Drell', 'Neptunas Klaipeda')
baja('Joventut Badalona', 'Yannis Morin', 'Southeast Melbourne Phoenix')
baja('Joventut Badalona', 'Guillem Vives', 'Casademont Zaragoza')

# Surne Bilbao
alta('Surne Bilbao Basket', 'Adam Somogyi', 'Szolnoki Olaj')
alta('Surne Bilbao Basket', 'Dan Duscak', 'Oviedo Baloncesto')
alta('Surne Bilbao Basket', 'Manex Ansorregi', 'Gipuzkoa Basket')
alta('Surne Bilbao Basket', 'Nate Darling', 'Elan Chalon')
alta('Surne Bilbao Basket', 'Bastien Vautier', 'LDLC ASVEL')
alta('Surne Bilbao Basket', 'Ondrej Hustak', 'King Szczezin')
baja('Surne Bilbao Basket', 'Melwin Pantzar', 'Unicaja', 'fin cesion')
baja('Surne Bilbao Basket', 'Justin Jaworski', 'Casademont Zaragoza')
baja('Surne Bilbao Basket', 'Stefan Lazarevic', 'KK Spartak Office Shoes')

# La Laguna Tenerife
alta('La Laguna Tenerife', 'Kyle Guy', 'Shanxi Loongs')
alta('La Laguna Tenerife', 'Xabi Lopez-Arostegui', 'Valencia Basket')
alta('La Laguna Tenerife', 'Ethan Happ', 'Recoletas Salud San Pablo Burgos')
alta('La Laguna Tenerife', 'TJ Bamba', 'Rasta Vechta')
alta('La Laguna Tenerife', 'Arturs Kurucs', 'Rio Breogan')
alta('La Laguna Tenerife', 'Vince Hunter', 'Lokomotiv Kuban')
baja('La Laguna Tenerife', 'Patty Mills', 'ASVEL')

# Unicaja
alta('Unicaja', 'Cameron Hunt', 'ASISA Joventut')
alta('Unicaja', 'Ignas Brazdeikis', 'Zalgiris Kaunas')
alta('Unicaja', 'Willy Hernangomez', 'FC Barcelona')
alta('Unicaja', 'Amine Noua', 'Aris Salonica')
alta('Unicaja', 'Simonas Lukosius', 'Dubai Basketball', 'cesion')
baja('Unicaja', 'Justin Cobbs', '?')
baja('Unicaja', 'Chris Duarte', 'Kosner Baskonia')
baja('Unicaja', 'Chase Audige', 'Recoletas Salud San Pablo Burgos')
baja('Unicaja', 'Xavier Castañeda', 'Nanterre')
baja('Unicaja', 'James Webb III', 'Erokspor')
baja('Unicaja', 'Emir Sulejmanovic', 'ASISA Joventut')
baja('Unicaja', 'Olek Balcerowski', 'FC Barcelona')

# Kids&Us Manresa
alta("BAXI Manresa", 'Lucas Beaufort', 'Saint-Chamond')
alta("BAXI Manresa", 'Pablo Tamba', 'LSU')
alta("BAXI Manresa", 'Michael Enabulele', 'Palmer Basket')
alta("BAXI Manresa", 'Chibuzo Agbo', 'Cholet Basket')
alta("BAXI Manresa", 'Eric Vila', 'Dreamland Gran Canaria')
alta("BAXI Manresa", 'Lukasz Kolenda', 'Rostock Seawolves')
alta("BAXI Manresa", 'Rodrigo Seoane', 'CB Tizona')
alta("BAXI Manresa", 'Nick Ongenda', 'Hapoel Haemek')
alta("BAXI Manresa", 'Yordan Minchev', 'Chemnitz 49ers')
alta("BAXI Manresa", 'Rafa Villar', 'Kosner Baskonia')
alta("BAXI Manresa", 'Timmy Allen', 'PAOK Salonica')
alta("BAXI Manresa", 'JD Notae', 'Trapani Sharks')
baja("BAXI Manresa", 'Agustin Ubal', 'FC Barcelona')
baja("BAXI Manresa", 'Alex Reyes', 'ASISA Joventut')
baja("BAXI Manresa", 'Marcis Steinbergs', 'UCAM Murcia')

# Río Breogán
alta('Rio Breogan', 'Aleksa Ilic', 'Studentski Centar')
alta('Rio Breogan', 'Tevin Brown', 'Rasta Vechta')
alta('Rio Breogan', 'Josep Peris', 'CB Zamora')
alta('Rio Breogan', 'Jonathan Kasibabu', 'Flexicar Fuenlabrada')
alta('Rio Breogan', 'Edgar Vicedo', 'Hestia Menorca')
alta('Rio Breogan', 'Rasir Bolton', 'GeVi Napoli')
alta('Rio Breogan', 'Andersson Garcia', 'Utah Jazz')
baja('Rio Breogan', 'DeWayne Russell', 'Nutribullet Treviso')
baja('Rio Breogan', 'Jordan Walker', 'Movistar Estudiantes')
baja('Rio Breogan', 'Arturs Kurucs', 'La Laguna Tenerife')

# FIATC Girona
alta('Bàsquet Girona', 'Isaac Vazquez', 'Ourense Baloncesto')
alta('Bàsquet Girona', 'Aljaz Kunc', 'TP Torun')
alta('Bàsquet Girona', 'Andrzej Pluta', 'Legia Warszawa')
alta('Bàsquet Girona', "David N'Guessan", 'Braunschweig')
alta('Bàsquet Girona', 'Stanley Whittaker', 'Aliaga Petkim')
alta('Bàsquet Girona', 'Jassel Perez', 'Vaqueros de Bayamon')
alta('Bàsquet Girona', 'Mac McClung', 'Windy City Bulls')
alta('Bàsquet Girona', 'Dominykas Stenionis', 'Valmiera')
baja('Bàsquet Girona', 'Otis Livingston', 'Cluj Napoca')
baja('Bàsquet Girona', 'Derek Needham', 'Chorale Roanne')
baja('Bàsquet Girona', 'Pepe Vildoza', 'Boca Juniors')

# Recoletas Salud San Pablo Burgos
alta('Recoletas Salud San Pablo Burgos', 'Ziga Samar', 'Dreamland Gran Canaria')
alta('Recoletas Salud San Pablo Burgos', 'Retin Obasohan', "Kids&Us Manresa")
alta('Recoletas Salud San Pablo Burgos', 'Raul Lobaco', 'Alimerka Oviedo')
alta('Recoletas Salud San Pablo Burgos', 'Christian Sengfelder', 'Ratiopharm Ulm')
alta('Recoletas Salud San Pablo Burgos', 'Balsa Koprivica', 'Bahcesehir')
alta('Recoletas Salud San Pablo Burgos', 'Chase Audige', 'Unicaja')
alta('Recoletas Salud San Pablo Burgos', 'Ruben Guerrero', 'MoraBanc Andorra')
alta('Recoletas Salud San Pablo Burgos', 'Iñaki Ordoñez', 'CB Valladolid')
alta('Recoletas Salud San Pablo Burgos', 'Vlatko Cancar', '?')
alta('Recoletas Salud San Pablo Burgos', 'DJ Steward', 'Dolomiti Energia Trento')
alta('Recoletas Salud San Pablo Burgos', 'Dusan Radosavljevic', 'FMP')
alta('Recoletas Salud San Pablo Burgos', 'Sekou Doumbouya', 'Koshigaya Alphas')
baja('Recoletas Salud San Pablo Burgos', 'Gonzalo Corbalan', 'Valencia Basket')
baja('Recoletas Salud San Pablo Burgos', 'Ethan Happ', 'La Laguna Tenerife')
baja('Recoletas Salud San Pablo Burgos', 'Raul Neto', 'FC Barcelona', 'via prensa, no en roster fuente')
baja('Recoletas Salud San Pablo Burgos', 'Leo Meindl', 'Monbus Obradoiro')

# iLerna Lleida
alta('Hiopos Lleida', 'Dani Garcia', 'UCAM Murcia')
alta('Hiopos Lleida', 'Mark Hughes', 'FIATC Girona')
alta('Hiopos Lleida', 'Kur Kuath', 'Dreamland Gran Canaria')
alta('Hiopos Lleida', 'Darius McGhee', 'JL Bourg Basket')
alta('Hiopos Lleida', 'Zaccharie Perrin', 'Hamburg Towers')
alta('Hiopos Lleida', 'Aurimas Majauskas', 'Neptunas Klaipeda')
baja('Hiopos Lleida', 'Caleb Agada', 'Monbus Obradoiro')
baja('Hiopos Lleida', 'Corey Walden', '?')
baja('Hiopos Lleida', 'Gyorgy Goloman', 'Legia Warszawa')

# Casademont Zaragoza
alta('Casademont Zaragoza', 'Guillem Vives', 'ASISA Joventut')
alta('Casademont Zaragoza', 'Sergi Garcia', 'Movistar Estudiantes')
alta('Casademont Zaragoza', 'Caleb Homesley', 'Bahcesehir')
alta('Casademont Zaragoza', 'Roberts Blumbergs', 'Aliaga Petkim')
alta('Casademont Zaragoza', 'Nico Brussino', 'Dreamland Gran Canaria')
alta('Casademont Zaragoza', 'Laurynas Birutis', 'Zalgiris')
alta('Casademont Zaragoza', 'Justin Jaworski', 'Surne Bilbao')
alta('Casademont Zaragoza', 'Lluc Pluvinet', 'instituto')
alta('Casademont Zaragoza', 'Jilson Bango', 'Fenerbahce')
baja('Casademont Zaragoza', 'Marco Spissu', 'Napoli Basket')

# MoraBanc Andorra
alta('MoraBanc Andorra', 'Owen Aquino', 'High Point')
alta('MoraBanc Andorra', 'Lazar Mutic', 'Lietkabelis Panevezys')
alta('MoraBanc Andorra', 'Kassius Robertson', 'Dreamland Gran Canaria')
alta('MoraBanc Andorra', 'James Akinjo', 'Ironi Ness Ziona')
alta('MoraBanc Andorra', 'Wes Iwundu', 'Ironi Kiryat Ata')
alta('MoraBanc Andorra', 'Cameron McGriff', 'Salt Lake City Stars')
alta('MoraBanc Andorra', 'Leon Radosevic', 'Treviso Basket')
baja('MoraBanc Andorra', 'Shannon Evans', 'Promitheas')
baja('MoraBanc Andorra', 'Ruben Guerrero', 'Recoletas Salud San Pablo Burgos')
baja('MoraBanc Andorra', 'Yves Pons', 'ASVEL')

# Monbus Obradoiro (equipo nuevo en ACB esta temporada, no estaba en nuestro roster de 18)
alta('Monbus Obradoiro (ASCIENDE)', 'Leo Meindl', 'Recoletas Salud San Pablo Burgos')
alta('Monbus Obradoiro (ASCIENDE)', 'Caleb Agada', 'iLerna Lleida')
alta('Monbus Obradoiro (ASCIENDE)', 'Alonso Faure', 'Oviedo Baloncesto')
alta('Monbus Obradoiro (ASCIENDE)', 'Brandon Childress', 'Bursaspor')
alta('Monbus Obradoiro (ASCIENDE)', 'Joel Soriano', 'Santeros de Aguada')
alta('Monbus Obradoiro (ASCIENDE)', 'Efe Abogidi', 'Rio Grande Valley')
baja('Monbus Obradoiro (ASCIENDE)', 'Travis Munnings', 'Movistar Estudiantes')
baja('Monbus Obradoiro (ASCIENDE)', 'Micah Speight', 'Movistar Estudiantes')

# Leyma Coruña (equipo nuevo en ACB esta temporada, no estaba en nuestro roster de 18)
alta('Leyma Coruña (ASCIENDE)', 'Alonzo Verge Jr', 'Rasta Vechta')
alta('Leyma Coruña (ASCIENDE)', 'Karlis Silins', 'Neptunas')
alta('Leyma Coruña (ASCIENDE)', 'Lukas Uleckas', 'Juventus Utena')
alta('Leyma Coruña (ASCIENDE)', 'George Conditt', 'Gigantes de Carolina')
alta('Leyma Coruña (ASCIENDE)', 'Dmytro Skapintsev', 'Hapoel Jerusalem')
alta('Leyma Coruña (ASCIENDE)', 'Tomas Dimsa', 'PAOK Salonica')
baja('Leyma Coruña (ASCIENDE)', 'Danilo Brnovic', 'Alimerka Oviedo')
baja('Leyma Coruña (ASCIENDE)', 'Mus Barro', 'Alimerka Oviedo')
baja('Leyma Coruña (ASCIENDE)', 'Joe Cremo', 'Dreamland Gran Canaria')
baja('Leyma Coruña (ASCIENDE)', 'Abdou Thiam', 'Coviran Granada')

df = pd.DataFrame(rows, columns=['Equipo', 'Tipo', 'Jugador', 'Club_relacionado', 'Notas'])
print(f"Total movimientos: {len(df)}  ({(df['Tipo']=='Alta').sum()} altas, {(df['Tipo']=='Baja').sum()} bajas)")
print(df['Equipo'].value_counts())

# ---- cruzar con nuestra base de datos (player_archetypes.csv) por nombre ----
import unicodedata
def norm(s):
    if pd.isna(s):
        return ''
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode('ascii')
    return ' '.join(s.lower().strip().split())

pa = pd.read_csv('player_archetypes.csv')
pa['name_norm'] = pa['Player'].map(norm)
pa_by_name = pa.set_index('name_norm')

df['name_norm'] = df['Jugador'].map(norm)
df = df.merge(pa[['name_norm', 'role', 'PPG', 'USG%', 'AST%', 'DOI%', 'pos_group']], on='name_norm', how='left')
df['en_nuestra_bbdd'] = df['role'].notna()

print()
print(f"Jugadores con datos ya en nuestra base (rol/stats de Liga Endesa): {df['en_nuestra_bbdd'].sum()} de {len(df)}")

df = df.drop(columns=['name_norm'])
df.to_csv('mercado_2026_27.csv', index=False, encoding='utf-8-sig')

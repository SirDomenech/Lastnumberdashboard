import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 100)

season = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')

missing = set(season.index) - set(track.index)
print("teams in season not in track:", missing)
df = season.join(track, how='left')
print("nulls after join:", df[track.columns].isna().sum().sum())

# =========================================================================
# 1) Z-SCORES (helper) — sign convention: positive z always = "better"
# =========================================================================
def z(col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def stars(zseries):
    """Map a goodness-z-score to a 0-5 star rating using league-relative bins."""
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    s = pd.cut(zseries, bins=bins, labels=labels).astype(float)
    # 0 reserved for extreme outliers far below the pack
    s[zseries <= -2.5] = 0
    return s.astype(int)

def stars_neutral(col):
    """For Ritmo: same binning but purely descriptive (fast<->slow), not good/bad."""
    x = df[col]
    zc = (x - x.mean()) / x.std(ddof=0)
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    return pd.cut(zc, bins=bins, labels=labels).astype(float).astype(int)

out = pd.DataFrame(index=df.index)

# ---- 1. Ritmo (contextual, no evaluativo) ----
out['Ritmo_poss'] = df['Pace']
out['Ritmo_perfil'] = stars_neutral('Pace')  # 1=muy lento .. 5=muy rapido (NO calidad)

# ---- 2. Ataque (OER) ----
out['Ataque_OER'] = df['OER']
out['Ataque_estrellas'] = stars(z('OER'))

# ---- 3. Defensa (DER, menos es mejor) ----
out['Defensa_DER'] = df['DER']
out['Defensa_estrellas'] = stars(z('DER', invert=True))

# ---- 4. Rebote (TRB% + subsecciones ORB%/DRB%) ----
out['Rebote_TRB%'] = df['TRB%']
out['Rebote_estrellas'] = stars(z('TRB%'))
out['Rebote_ORB%'] = df['ORB%']
out['Rebote_ORB_estrellas'] = stars(z('ORB%'))
out['Rebote_DRB%'] = df['DRB%']
out['Rebote_DRB_estrellas'] = stars(z('DRB%'))

# ---- 5. Control y cuidado de balon (TOV% invertido + AST/TOV) ----
out['Control_TOV%'] = df['TOV%']
out['Control_TOV_estrellas'] = stars(z('TOV%', invert=True))
out['Control_ASTTOV'] = df['AST/TOV']
out['Control_ASTTOV_estrellas'] = stars(z('AST/TOV'))
z_control = (z('TOV%', invert=True) + z('AST/TOV')) / 2
out['Control_estrellas_global'] = stars(z_control)

# ---- 6. Generacion (OER + AST% + AST/TOV) ----
z_gen = (z('OER') + z('AST%') + z('AST/TOV')) / 3
out['Generacion_estrellas'] = stars(z_gen)

# ---- 7. Eficiencia de anotacion (eFG%, TS%, FG%) ----
out['Eficiencia_eFG%'] = df['eFG%']
out['Eficiencia_TS%'] = df['TS%']
out['Eficiencia_FG%'] = df['FG%']
z_efi = (z('eFG%') + z('TS%') + z('FG%')) / 3
out['Eficiencia_estrellas'] = stars(z_efi)

# ---- 8. Tiro exterior (3P% + 3PAr combinados) ----
out['Exterior_3P%'] = df['3P%']
out['Exterior_3PAr'] = df['3PAr']
z_ext = (z('3P%') + z('3PAr')) / 2
out['Exterior_estrellas'] = stars(z_ext)

# ---- 9. Facilidad para sacar faltas (FTr) ----
out['Faltas_FTr'] = df['FTr']
out['Faltas_estrellas'] = stars(z('FTr'))

# ---- 10. Defensa sobre balon (DER invertido + STL%) ----
out['DefBalon_STL%'] = df['STL%']
z_defbalon = (z('DER', invert=True) + z('STL%')) / 2
out['DefBalon_estrellas'] = stars(z_defbalon)

# ---- 11. Proteccion de aro (BLK% + eficiencia rival tiro de 2 invertida) ----
out['Aro_BLK%'] = df['BLK%']
out['Aro_Opp2P%'] = df['Opp_2P%']
z_aro = (z('BLK%') + z('Opp_2P%', invert=True)) / 2
out['Aro_estrellas'] = stars(z_aro)

out = out.round(2)
print(out.to_string())
out.to_csv('team_stars.csv')

# also save z-scores used, for transparency/QA
zdf = pd.DataFrame({
    'z_OER': z('OER'), 'z_DER_inv': z('DER', invert=True), 'z_TRB%': z('TRB%'),
    'z_ORB%': z('ORB%'), 'z_DRB%': z('DRB%'), 'z_TOV%_inv': z('TOV%', invert=True),
    'z_ASTTOV': z('AST/TOV'), 'z_AST%': z('AST%'), 'z_eFG%': z('eFG%'), 'z_TS%': z('TS%'),
    'z_FG%': z('FG%'), 'z_3P%': z('3P%'), 'z_3PAr': z('3PAr'), 'z_FTr': z('FTr'),
    'z_STL%': z('STL%'), 'z_BLK%': z('BLK%'), 'z_Opp2P%_inv': z('Opp_2P%', invert=True),
    'z_Pace': z('Pace'),
})
zdf.round(2).to_csv('team_zscores.csv')
print("\nsaved team_stars.csv and team_zscores.csv")

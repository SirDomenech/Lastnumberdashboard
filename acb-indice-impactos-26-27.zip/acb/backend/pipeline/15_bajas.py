import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 60)
pd.set_option('display.max_rows', 400)

ps = pd.read_csv('player_season.csv')       # temporada de referencia (334 jugadores, 18 equipos)
rm = pd.read_csv('roster_matched.csv')      # roster 25/26 (358 jugadores)

# ids de la temporada de referencia que SÍ siguen apareciendo en algún equipo del roster 25/26
matched_ids = set(rm.loc[rm['nickname'].notna(), 'id'].dropna())

ps['sigue_en_liga'] = ps['id'].isin(matched_ids)

# para los que siguen, ¿en qué equipo? (puede ser el mismo o distinto)
id_to_new_team = rm.loc[rm['nickname'].notna()].set_index('id')['team_box'].to_dict()
ps['equipo_nuevo'] = ps['id'].map(id_to_new_team)

def tipo_baja(row):
    if not row['sigue_en_liga']:
        return 'Sale de la ACB (no aparece en ningún equipo del roster 25/26)'
    if row['equipo_nuevo'] != row['team_last']:
        return f"Traspaso dentro de la ACB -> {row['equipo_nuevo']}"
    return None  # sigue en el mismo equipo, no es baja

ps['tipo_baja'] = ps.apply(tipo_baja, axis=1)
bajas = ps[ps['tipo_baja'].notna()].copy()

print(f"Total bajas detectadas: {len(bajas)} de {len(ps)} jugadores de la temporada de referencia")
print()
print("Por equipo (temporada de referencia):")
print(bajas.groupby('team_last').size().sort_values(ascending=False))
print()

out = bajas[['team_last', 'nickname', 'tipo_baja', 'games', 'MPG', 'PPG', 'AST%', 'USG%', 'DOI%', 'bajo_volumen']].copy()
out.columns = ['Equipo_origen', 'Jugador', 'Tipo_baja', 'Partidos_ref', 'MPG', 'PPG', 'AST%', 'USG%', 'DOI%', 'Bajo_volumen_ref']
for c in ['MPG', 'PPG', 'AST%', 'USG%', 'DOI%']:
    out[c] = out[c].round(1)
out = out.sort_values(['Equipo_origen', 'PPG'], ascending=[True, False])
out.to_csv('bajas_detectadas.csv', index=False, encoding='utf-8-sig')

print(out.head(30).to_string(index=False))

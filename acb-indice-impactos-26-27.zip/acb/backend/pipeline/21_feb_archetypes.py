import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 100)

OUT_TEAMS = ['Coviran Granada', 'Dreamland Gran Canaria']

acb = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
acb_full = acb.join(track, how='left')
acb_full['PF_per100'] = acb_full['PF'] / acb_full['POSS'] * 100
acb_full['Top3_share'] = pd.read_csv('scoring_top3share.csv', index_col=0)['share']
acb_cont = acb_full.drop(index=[t for t in OUT_TEAMS if t in acb_full.index])

trans = pd.read_csv('feb_translated_to_acb.csv', index_col=0)
trans.index = ['Leyma Coruña', 'Monbus Obradoiro']

ARCH_COLS = ['Pace', '3PAr', 'AST%', 'AST/TOV', 'ORB%', 'FTr', 'Top3_share', 'DRB%',
             'Opp_2P%', 'Opp_TOV%', 'Opp_FTr', 'STL%', 'PF_per100']
# columnas de tracking que SOLO tienen los 16 equipos ACB reales (no derivables del boxscore FEB)
TRACK_ONLY = ['ptsPIN_per100pos', 'ptsRO_per100pos', 'r_ptsPIN_per100pos', 'r_ptsCA_per100pos']

df = pd.concat([acb_cont[ARCH_COLS + TRACK_ONLY], trans[ARCH_COLS]])  # las 2 nuevas quedan NaN en TRACK_ONLY
NEW_TEAMS = ['Leyma Coruña', 'Monbus Obradoiro']

def zg(col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def tertile(col, invert=False):
    r = df[col].rank(ascending=invert)
    n = len(df)
    return pd.cut(r, bins=[0, n/3, 2*n/3, n], labels=['Alto', 'Medio', 'Bajo'])

df['Pace_tier'] = tertile('Pace')
df['z_pacespace_idx'] = (zg('Pace') + zg('3PAr')) / 2
n = len(df)
r_idx = df['z_pacespace_idx'].rank(ascending=False)
df['PaceSpace_idx_tier'] = pd.cut(r_idx, bins=[0, n/3, 2*n/3, n], labels=['Alto', 'Medio', 'Bajo'])

TARGET = 1.4

REMAINING_ARCHETYPES_FULL = {
    'Juego Coral (Pase y Corte)': {'AST%': False, 'AST/TOV': False},
    'Juego Interior y Físico': {'ORB%': False, 'FTr': False, 'ptsPIN_per100pos': False, 'ptsRO_per100pos': False},
    'Talento Individual (1c1)': {'Top3_share': False, 'AST%': True},
}
DEFENSE_ARCHETYPES_FULL = {
    'Cierre de Pintura (Contención)': {'DRB%': False, 'Opp_2P%': True, 'r_ptsPIN_per100pos': True, 'Opp_FTr': True},
    'Presión y Agresividad (esquema)': {'Opp_TOV%': False},
    'Agresividad sobre balón (individual)': {'STL%': False, 'PF_per100': False},
    'Balance Defensivo y Equilibrio': {'r_ptsCA_per100pos': True, 'DRB%': False, 'PF_per100': True},
}

def best_fit(team, candidates):
    dists = {}
    for arch, metrics in candidates.items():
        # si algun jugador/equipo no tiene el dato de tracking, se excluye ese arquetipo entero
        if any(pd.isna(zg(m, invert=inv)[team]) for m, inv in metrics.items()):
            continue
        vals = [(zg(m, invert=inv)[team] - TARGET) ** 2 for m, inv in metrics.items()]
        dists[arch] = np.sqrt(np.mean(vals))
    return dists

results = {}
for team in NEW_TEAMS:
    row = {}
    if df.loc[team, 'PaceSpace_idx_tier'] == 'Alto':
        row['Ataque'] = 'Ritmo y Espacio'
        row['Ataque_motivo'] = 'Regla 1: indice ritmo+3PAr en tercio superior'
    elif df.loc[team, 'Pace_tier'] == 'Bajo':
        row['Ataque'] = 'Baloncesto de Control'
        row['Ataque_motivo'] = 'Regla 2: ritmo bajo'
    else:
        candidates = dict(REMAINING_ARCHETYPES_FULL)
        if df.loc[team, 'Pace_tier'] == 'Alto':
            candidates.pop('Juego Coral (Pase y Corte)', None)
        dists = best_fit(team, candidates)
        excluded = set(REMAINING_ARCHETYPES_FULL) - set(dists)
        best = min(dists, key=dists.get)
        row['Ataque'] = best + ' *' if excluded else best
        row['Ataque_motivo'] = f"Regla 3 nearest-fit sobre {list(dists.keys())} (excluidos por falta de tracking: {sorted(excluded)}): {[(k, round(v,2)) for k,v in dists.items()]}"

    dists_def = best_fit(team, DEFENSE_ARCHETYPES_FULL)
    excluded_def = set(DEFENSE_ARCHETYPES_FULL) - set(dists_def)
    best_def = min(dists_def, key=dists_def.get)
    row['Defensa'] = best_def + ' *' if excluded_def else best_def
    row['Defensa_motivo'] = f"nearest-fit sobre {list(dists_def.keys())} (excluidos por falta de tracking: {sorted(excluded_def)}): {[(k, round(v,2)) for k,v in dists_def.items()]}"
    results[team] = row

res = pd.DataFrame(results).T
print(res.to_string())
res.to_csv('feb_new_teams_archetypes.csv')

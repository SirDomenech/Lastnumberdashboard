import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 60)

BOX = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77c1dac6-Box_Scores_ACB.csv"
box = pd.read_csv(BOX)

NAME_MAP = {
    'Asisa Joventut': 'Joventut Badalona', 'Joventut Badalona': 'Joventut Badalona',
    'Kosner Baskonia': 'Baskonia', 'Baskonia': 'Baskonia',
    'Surne Bilbao': 'Surne Bilbao Basket', 'Surne Bilbao Basket': 'Surne Bilbao Basket',
}
box['Nombre equipo'] = box['Nombre equipo'].map(lambda x: NAME_MAP.get(x, x))

tgf = pd.read_csv('team_game_full.csv')[['ID Partido', 'Nombre equipo', 'POSS_game']]

pg = box.merge(tgf, on=['ID Partido', 'Nombre equipo'], how='left')
assert pg['POSS_game'].isna().sum() == 0, "unmatched games when joining POSS_game"

# sum of team possessions across exactly the games this player appears in
t_poss = pg.groupby(['id', 'nickname'], as_index=False)['POSS_game'].sum().rename(columns={'POSS_game': 'T_POSS'})

ps = pd.read_csv('player_season.csv')
ps = ps.merge(t_poss, on=['id', 'nickname'], how='left')

MP = ps['MP_sec'] / 60
T_MP = ps['T_MPsec'] / 60
ps['Team_Poss_onfloor'] = (MP / (T_MP / 5)) * ps['T_POSS']

ps['DOI%'] = 100 * (ps['FGA'] + 0.44 * ps['FTA'] + ps['TOV'] + 0.75 * ps['AST']) / ps['Team_Poss_onfloor']

ps.to_csv('player_season.csv', index=False)

print("DOI% describe:")
print(ps['DOI%'].describe())
print()
print("Top 15 por DOI% (jugadores cualificados):")
q = ps[~ps['bajo_volumen']].sort_values('DOI%', ascending=False).head(15)
print(q[['nickname', 'team_last', 'MPG', 'PPG', 'APG', 'USG%', 'AST%', 'DOI%']].to_string(index=False))
print()
print("Comparación USG% vs DOI% para algunos conocidos:")
for n in ['Llull', 'Campazzo', 'Tavares', 'Kuric', 'Deck']:
    sub = ps[ps['nickname'].str.contains(n, case=False, na=False)]
    print(sub[['nickname', 'team_last', 'USG%', 'AST%', 'DOI%']].to_string(index=False))

import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np
import json

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 100)

OUT_TEAMS = ['Coviran Granada', 'Dreamland Gran Canaria']  # relegados, no juegan ACB 26/27
NEW_TEAMS = ['Leyma Coruña', 'Monbus Obradoiro']            # ascendidos desde Primera FEB
NEW_TEAMS_FEB_KEY = {'Leyma Coruña': 'LEYMA CORUÑA', 'Monbus Obradoiro': 'MONBUS OBRADOIRO'}

# ---------------- datos base: 16 equipos ACB que continuan ----------------
acb = pd.read_csv('season_metrics.csv', index_col=0)

# Excepcion pedida por el usuario: Real Madrid ya tenia el 1er puesto de la liga regular
# garantizado en las jornadas 30-34 y bajo el nivel ahi (perdio las 5, incluida alguna por
# margen amplio). Esas 5 jornadas se ponderan a x0.7 en vez de x1 al reconstruir sus metricas
# de temporada desde el boxscore partido a partido (team_game_full.csv), para que ese tramo
# sin intensidad competitiva real pese menos en su perfil. Solo se recalculan las metricas de
# calidad que alimentan las categorias de estrellas/Rating (Ataque, Defensa, Rebote, Control,
# Generacion, Eficiencia, Tiro exterior, Saca faltas, Defensa sobre balon, Proteccion de aro).
# Ritmo (Pace) y GP quedan sin tocar: son descriptivos (partidos realmente jugados / ritmo
# real), no una valoracion de calidad, y no entran en el Rating. No afecta a ningun otro
# equipo ni a la clasificacion de arquetipos.
def _apply_madrid_last5_weight(acb_df, jornada_ini=30, jornada_fin=34, peso=0.7):
    mg = pd.read_csv('team_game_full.csv')
    rm = mg[mg['Nombre equipo'] == 'Real Madrid'].copy()
    rm['w'] = rm['Jornada'].apply(lambda j: peso if jornada_ini <= j <= jornada_fin else 1.0)
    sum_cols = ['PTS', 'FTA', 'P3M', 'P3A', 'AST', 'OREB', 'DREB', 'TRB', 'STL', 'TOV', 'BLK',
                'FGM', 'FGA', 'POSS_game', 'Opp_PTS', 'Opp_P2M', 'Opp_P2A', 'Opp_OREB',
                'Opp_DREB', 'Opp_TRB']
    s = {c: (rm[c] * rm['w']).sum() for c in sum_cols}
    POSS = s['POSS_game']
    i = 'Real Madrid'
    acb_df.loc[i, 'OER'] = s['PTS'] / POSS * 100
    acb_df.loc[i, 'DER'] = s['Opp_PTS'] / POSS * 100
    acb_df.loc[i, 'NetRtg'] = acb_df.loc[i, 'OER'] - acb_df.loc[i, 'DER']
    acb_df.loc[i, 'ORB%'] = s['OREB'] / (s['OREB'] + s['Opp_DREB']) * 100
    acb_df.loc[i, 'DRB%'] = s['DREB'] / (s['DREB'] + s['Opp_OREB']) * 100
    acb_df.loc[i, 'TRB%'] = s['TRB'] / (s['TRB'] + s['Opp_TRB']) * 100
    acb_df.loc[i, 'TOV%'] = s['TOV'] / POSS * 100
    acb_df.loc[i, 'AST/TOV'] = s['AST'] / s['TOV']
    acb_df.loc[i, 'AST%'] = s['AST'] / s['FGM'] * 100
    acb_df.loc[i, 'eFG%'] = (s['FGM'] + 0.5 * s['P3M']) / s['FGA'] * 100
    acb_df.loc[i, 'TS%'] = s['PTS'] / (2 * (s['FGA'] + 0.44 * s['FTA'])) * 100
    acb_df.loc[i, 'FG%'] = s['FGM'] / s['FGA'] * 100
    acb_df.loc[i, '3PAr'] = s['P3A'] / s['FGA'] * 100
    acb_df.loc[i, '3P%'] = s['P3M'] / s['P3A'] * 100
    acb_df.loc[i, 'FTr'] = s['FTA'] / s['FGA'] * 100
    acb_df.loc[i, 'STL%'] = s['STL'] / POSS * 100
    acb_df.loc[i, 'BLK%'] = s['BLK'] / s['Opp_P2A'] * 100
    acb_df.loc[i, 'Opp_2P%'] = s['Opp_P2M'] / s['Opp_P2A'] * 100
    return acb_df

acb = _apply_madrid_last5_weight(acb)

TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
acb_full = acb.join(track, how='left')
acb_full['PF_per100'] = acb_full['PF'] / acb_full['POSS'] * 100
acb_full['Top3_share'] = pd.read_csv('scoring_top3share.csv', index_col=0)['share']
acb_cont = acb_full.drop(index=[t for t in OUT_TEAMS if t in acb_full.index])

# ---------------- los 2 ascendidos, ya traducidos a equivalente ACB ----------------
trans = pd.read_csv('feb_translated_to_acb.csv', index_col=0)
trans.index = NEW_TEAMS
feb_raw = pd.read_csv('feb_season_metrics.csv', index_col='team')
GP_FEB = {'Leyma Coruña': int(feb_raw.loc['LEYMA CORUÑA', 'GP']),
          'Monbus Obradoiro': int(feb_raw.loc['MONBUS OBRADOIRO', 'GP'])}

ARCH_COLS = ['Pace', '3PAr', 'AST%', 'AST/TOV', 'ORB%', 'FTr', 'Top3_share', 'DRB%',
             'Opp_2P%', 'Opp_TOV%', 'Opp_FTr', 'STL%', 'PF_per100']
TRACK_ONLY = ['ptsPIN_per100pos', 'ptsRO_per100pos', 'r_ptsPIN_per100pos', 'r_ptsCA_per100pos']
STAR_NEEDED = ['Pace', 'OER', 'DER', 'TRB%', 'ORB%', 'DRB%', 'TOV%', 'AST/TOV', 'AST%',
               'eFG%', 'TS%', 'FG%', '3P%', '3PAr', 'FTr', 'STL%', 'BLK%', 'Opp_2P%']

ALL_COLS = list(dict.fromkeys(ARCH_COLS + TRACK_ONLY + STAR_NEEDED))  # union, sin duplicados, orden estable
df = pd.concat([acb_cont[ALL_COLS], trans[[c for c in ALL_COLS if c in trans.columns]]])
TEAMS_ALL = list(df.index)
print(f"Liga combinada final: {len(TEAMS_ALL)} equipos -> {TEAMS_ALL}")

# ================= ESTRELLAS =================
def z(col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def stars(zseries):
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    s = pd.cut(zseries, bins=bins, labels=labels).astype(float)
    s[zseries <= -2.5] = 0
    return s.astype(int)

def stars_neutral(col):
    x = df[col]
    zc = (x - x.mean()) / x.std(ddof=0)
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    return pd.cut(zc, bins=bins, labels=labels).astype(float).astype(int)

def rank_desc(series):
    # rank 1 = mejor (valor mas alto). Empates -> rank promedio redondeado hacia orden estable.
    return series.rank(ascending=False, method='min').astype(int)

z_control = (z('TOV%', invert=True) + z('AST/TOV')) / 2
z_gen = (z('OER') + z('AST%') + z('AST/TOV')) / 3
z_efi = (z('eFG%') + z('TS%') + z('FG%')) / 3
z_ext = (z('3P%') + z('3PAr')) / 2
z_defbalon = (z('DER', invert=True) + z('STL%')) / 2
z_aro = (z('BLK%') + z('Opp_2P%', invert=True)) / 2

RANKS = {
    'ataque': rank_desc(df['OER']),
    'defensa': rank_desc(-df['DER']),
    'rebote': rank_desc(df['TRB%']),
    'rebote_orb': rank_desc(df['ORB%']),
    'rebote_drb': rank_desc(df['DRB%']),
    'control': rank_desc(z_control),
    'generacion': rank_desc(z_gen),
    'eficiencia': rank_desc(z_efi),
    'exterior': rank_desc(z_ext),
    'faltas': rank_desc(df['FTr']),
    'defbalon': rank_desc(z_defbalon),
    'aro': rank_desc(z_aro),
}

# ================= ARQUETIPOS (para los 18) =================
def zg(col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def tertile(col, invert=False):
    r = df[col].rank(ascending=invert)
    n = len(df)
    return pd.cut(r, bins=[0, n/3, 2*n/3, n], labels=['Alto', 'Medio', 'Bajo'])

df['Pace_tier'] = tertile('Pace')
df['z_pacespace_idx'] = (zg('Pace') + zg('3PAr')) / 2
n = len(df)
r_idx = df['z_pacespace_idx'].rank(ascending=False)
df['PaceSpace_idx_tier'] = pd.cut(r_idx, bins=[0, n/3, 2*n/3, n], labels=['Alto', 'Medio', 'Bajo'])

# --- Ajuste para los 2 ascendidos: su perfil de ritmo/espacio se evalua dentro de su
# propia liga (Primera FEB, 17 equipos), no contra el pool de 18 de ACB. Primera FEB juega
# de media mas lento que ACB (75.5 vs 78.1 posesiones/partido), asi que comparar su ritmo
# bruto contra el pool ACB los hundia casi automaticamente en el tercio bajo aunque dentro
# de su propia liga jugaran rapido. Se usan bins con techo (ceil) para el tercio superior,
# ya que 17 no es multiplo de 3 (17/3=5.67): el equipo en el puesto 6 de 17 entra en el
# tercio alto en vez de quedar fuera por un margen minimo.
import math
feb_pace_pool = feb_raw.copy()
def zfeb(col):
    x = feb_pace_pool[col]
    return (x - x.mean()) / x.std(ddof=0)
feb_pace_pool['z_pacespace_idx_feb'] = (zfeb('Pace') + zfeb('3PAr')) / 2
n_feb = len(feb_pace_pool)
b1, b2 = math.ceil(n_feb / 3), math.ceil(2 * n_feb / 3)
def tertile_feb(rank_series):
    return pd.cut(rank_series, bins=[0, b1, b2, n_feb], labels=['Alto', 'Medio', 'Bajo'])
feb_pace_pool['Pace_tier_feb'] = tertile_feb(feb_pace_pool['Pace'].rank(ascending=False))
feb_pace_pool['PaceSpace_idx_tier_feb'] = tertile_feb(feb_pace_pool['z_pacespace_idx_feb'].rank(ascending=False))

for team in NEW_TEAMS:
    k = NEW_TEAMS_FEB_KEY[team]
    df.loc[team, 'Pace_tier'] = feb_pace_pool.loc[k, 'Pace_tier_feb']
    df.loc[team, 'PaceSpace_idx_tier'] = feb_pace_pool.loc[k, 'PaceSpace_idx_tier_feb']
    df.loc[team, 'z_pacespace_idx'] = feb_pace_pool.loc[k, 'z_pacespace_idx_feb']

TARGET = 1.4

# Ritmo y Espacio y Baloncesto de Control son categorias EXTREMAS de ritmo (pedido
# explicito del usuario: "ritmo y control son categorias extremas por ritmo y otros
# valores"): no basta con estar en el tercio superior/inferior de la liga (eso admitia
# equipos solo "algo" rapidos o lentos, como Andorra/Girona por 3PAr, o Unicaja por estar
# justo en el borde del tercio lento, sin ser realmente un caso extremo). Control se decide
# por Regla 0, directamente por ritmo real (ver mas abajo, EXTREME_SLOW_TEAMS); ya no compite
# por distancia estadistica contra Individual/Estatico, y por eso no aparece en este dict.
#
# Candidatos para el resto de equipos (los que no caen en ninguna categoria extrema).
# Talento Individual se identifica por concentracion de anotacion (Top3_share) y AST%
# invertido (bajo reparto). Juego en Estatico (fusion de la antigua Juego Coral + Juego
# Interior y Fisico) compite si el equipo NO esta en el tercio alto de ritmo.
ATTACK_CANDIDATES_FULL = {
    'Talento Individual (1c1)': {'Top3_share': False, 'AST%': True},
    'Juego en Estático': {'AST%': False, 'AST/TOV': False, 'ORB%': False, 'FTr': False,
                           'ptsPIN_per100pos': False, 'ptsRO_per100pos': False},
}
# Talento Individual SOLO para los equipos de ritmo Medio que no activan la puerta de AST%
# de abajo: ahi se usa una version reducida (solo Top3_share, sin AST%) porque en ese grupo
# concreto (ritmo medio, sin Control como opcion) el AST% ya se usa como señal de entrada a
# Estatico por separado -- diluirlo tambien dentro de Individual duplicaba su peso y
# distorsionaba casos como Lleida. Para el resto de la liga (ritmo Alto o Bajo) se mantiene
# la definicion completa de Individual, sin tocar equipos no mencionados en esta revision.
ATTACK_INDIVIDUAL_MEDIO = {'Top3_share': False}
# Umbral de reparto de juego: para equipos de ritmo Medio (donde Control no es candidato,
# solo compiten Individual y Estatico), un AST% claramente por encima de la media de la
# liga (z >= 0.8) es en si mismo la senal de identidad de "juego en estatico" y decide
# directamente, sin diluirlo en la media de las otras 5 metricas del perfil.
AST_GATE_Z = 0.8

# Nucleo de ritmo extremadamente lento (Regla 0, Baloncesto de Control). Se calcula solo
# sobre los 16 equipos con temporada real en ACB (los 2 ascendidos usan su propia escala de
# Primera FEB y no entran en este ranking, igual que en el resto de reglas de ritmo). Se fija
# en 3 equipos -- no todo el tercio inferior (que son 4) -- porque el 4º mas lento de esa
# lista, Unicaja, no es un caso de ritmo extremo (queda muy cerca del corte con el tercio
# medio): jugar "algo lento" no basta para ser Control, hay que estar en el nucleo mas lento
# de verdad.
REAL_ACB_TEAMS = [t for t in TEAMS_ALL if t not in NEW_TEAMS]
_pace_rank_slow = df.loc[REAL_ACB_TEAMS, 'Pace'].rank(ascending=True)  # 1 = el mas lento
EXTREME_SLOW_N = 3
EXTREME_SLOW_TEAMS = set(_pace_rank_slow[_pace_rank_slow <= EXTREME_SLOW_N].index)

# Excepciones manuales de ataque, pedidas explicitamente por el usuario para dos casos
# limite que la Regla 1 (ritmo real + indice combinado) deja en lados opuestos pese a tener
# indices de ritmo+3PAr casi identicos: Girona (ritmo real "Medio", pero 2o mayor volumen de
# triple de la liga) y UCAM Murcia (ritmo real "Alto" en el limite, volumen de triple mucho
# mas discreto). No son un ajuste de formula: es una decision editorial directa sobre estos
# dos equipos, documentada aqui para que quede trazada.
ATTACK_MANUAL_OVERRIDE = {
    'Bàsquet Girona': ('Ritmo y Espacio',
        'Excepción manual: aunque su ritmo real está en el tercio Medio, su volumen de triple (3PAr, 2º más alto de la liga) se considera decisivo para esta etiqueta.'),
    'UCAM Murcia': ('Talento Individual (1c1)',
        'Excepción manual: aunque su ritmo real supera el corte del tercio Alto, se reclasifica como Talento Individual por decisión editorial, no por ajuste estadístico.'),
}

DEFENSE_ARCHETYPES_FULL = {
    'Cierre de Pintura (Contención)': {'DRB%': False, 'Opp_2P%': True, 'r_ptsPIN_per100pos': True},
    'Presión y Agresividad sobre Balón': {'Opp_TOV%': False, 'STL%': False, 'Opp_FTr': True},
    'Equilibrio Defensivo': {'r_ptsCA_per100pos': True, 'DRB%': False, 'PF_per100': True},
}
# Opp_FTr (tiros libres concedidos por el rival) se movio de Cierre de Pintura a Presion y
# Agresividad, y sustituye a PF_per100 ahi: lo que de verdad distingue una defensa agresiva
# "de verdad" es generar perdidas y robos SIN mandar al rival a la linea -- PF_per100 en
# bruto (mas faltas = mas agresivo) era un proxy pobre, penalizaba a defensas inteligentes
# que presionan sin cometer faltas.

def best_fit(team, candidates):
    dists = {}
    for arch, metrics in candidates.items():
        if any(pd.isna(zg(m, invert=inv)[team]) for m, inv in metrics.items()):
            continue
        vals = [(zg(m, invert=inv)[team] - TARGET) ** 2 for m, inv in metrics.items()]
        dists[arch] = np.sqrt(np.mean(vals))
    return dists

archetypes = {}
for team in TEAMS_ALL:
    row = {}
    feb_ctx = " (perfil medido dentro de Primera FEB, no contra el pool ACB)" if team in NEW_TEAMS else ""
    # Regla 1 (Ritmo y Espacio) exige ritmo real en el tercio alto ademas del indice
    # combinado con 3PAr -- un equipo de ritmo Medio que solo destaca por volumen de triple
    # (Andorra, Girona) no es un caso de ritmo extremo, solo de mucho tiro exterior. Para los
    # 2 ascendidos se mantiene el criterio anterior (solo el indice combinado, dentro de
    # Primera FEB): no hay datos suficientes para separar ambos factores con el mismo rigor
    # fuera de ACB, y no es el foco de esta revision.
    pace_alto_real = (team in NEW_TEAMS) or (df.loc[team, 'Pace_tier'] == 'Alto')
    if team in ATTACK_MANUAL_OVERRIDE:
        row['ataque'], row['ataque_motivo'] = ATTACK_MANUAL_OVERRIDE[team]
    elif team in EXTREME_SLOW_TEAMS:
        row['ataque'] = 'Baloncesto de Control'
        row['ataque_motivo'] = f"Regla 0: entre los {EXTREME_SLOW_N} equipos de ritmo mas extremadamente lento de la liga ({df.loc[team,'Pace']:.1f} pos/partido, puesto {int(_pace_rank_slow[team])} de {len(REAL_ACB_TEAMS)} mas lento)"
    elif df.loc[team, 'PaceSpace_idx_tier'] == 'Alto' and pace_alto_real:
        row['ataque'] = 'Ritmo y Espacio'
        row['ataque_motivo'] = f"Regla 1: ritmo real en el tercio superior de la liga y indice ritmo+3PAr en tercio superior (idx z={df.loc[team,'z_pacespace_idx']:.2f}){feb_ctx}"
    elif df.loc[team, 'Pace_tier'] == 'Medio' and zg('AST%')[team] >= AST_GATE_Z:
        row['ataque'] = 'Juego en Estático'
        row['ataque_motivo'] = f"Regla 2: ritmo medio con AST% muy por encima de la media (z={zg('AST%')[team]:.2f} >= {AST_GATE_Z}), reparto de juego decide directamente"
    else:
        candidates = dict(ATTACK_CANDIDATES_FULL)
        if df.loc[team, 'Pace_tier'] == 'Alto':
            candidates.pop('Juego en Estático', None)
        if df.loc[team, 'Pace_tier'] == 'Medio':
            candidates['Talento Individual (1c1)'] = ATTACK_INDIVIDUAL_MEDIO
        dists = best_fit(team, candidates)
        excluded = set(ATTACK_CANDIDATES_FULL) - set(dists)
        best = min(dists, key=dists.get)
        row['ataque'] = best  # etiqueta limpia; el flag de estimacion FEB se marca aparte, a nivel de equipo
        row['ataque_motivo'] = f"Regla 3 nearest-fit (con puertas por ritmo{' evaluado dentro de Primera FEB' if team in NEW_TEAMS else ''}): {[(k, round(v,2)) for k,v in dists.items()]}" + (f" (excluidos: {sorted(excluded)})" if excluded else "")

    dists_def = best_fit(team, DEFENSE_ARCHETYPES_FULL)
    excluded_def = set(DEFENSE_ARCHETYPES_FULL) - set(dists_def)
    best_def = min(dists_def, key=dists_def.get)
    row['defensa'] = best_def  # idem
    row['defensa_motivo'] = f"nearest-fit: {[(k, round(v,2)) for k,v in dists_def.items()]}" + (f" (excluidos por falta de tracking: {sorted(excluded_def)})" if excluded_def else "")
    archetypes[team] = row

# ================= METRICAS Y RANKING REALES EN PRIMERA FEB (17 equipos) =================
# Para las fichas de los 2 ascendidos: se muestran sus numeros reales de Primera FEB 25/26
# (no el equivalente ACB traducido) junto a su puesto dentro de esa liga de 17 equipos.
# (NEW_TEAMS_FEB_KEY definido arriba, junto a NEW_TEAMS)
feb17 = feb_raw.copy()

def zf(col, invert=False):
    x = feb17[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def rank_feb(series):
    return series.rank(ascending=False, method='min').astype(int)

fz_control = (zf('TOV%', invert=True) + zf('AST/TOV')) / 2
fz_gen = (zf('OER') + zf('AST%') + zf('AST/TOV')) / 3
fz_efi = (zf('eFG%') + zf('TS%') + zf('FG%')) / 3
fz_ext = (zf('3P%') + zf('3PAr')) / 2
fz_defbalon = (zf('DER', invert=True) + zf('STL%')) / 2
fz_aro = (zf('BLK%') + zf('Opp_2P%', invert=True)) / 2

FEB_RANKS = {
    'ataque': rank_feb(feb17['OER']),
    'defensa': rank_feb(-feb17['DER']),
    'rebote': rank_feb(feb17['TRB%']),
    'control': rank_feb(fz_control),
    'generacion': rank_feb(fz_gen),
    'eficiencia': rank_feb(fz_efi),
    'exterior': rank_feb(fz_ext),
    'faltas': rank_feb(feb17['FTr']),
    'defbalon': rank_feb(fz_defbalon),
    'aro': rank_feb(fz_aro),
}
N_FEB = len(feb17)

# ---------------- Nota (Rating) de los 2 ascendidos, calibrada dentro de Primera FEB ----------------
# Replica exacta de la formula secreta del dashboard (WEIGHTS, formula de nota y bandas de
# letra en dashboard_v2_content.html), pero aplicada sobre los 17 equipos de Primera FEB en
# vez de sobre ACB: estrellas por categoria via z-score dentro de FEB, Net Rating (columna
# NetRtg real de FEB) como fuerza de contraste, y clasificacion por puesto de Net Rating
# dentro de FEB como proxy de clasificacion real (Primera FEB no tiene datos de V-D por
# equipo en este dataset). Si la formula secreta del dashboard cambia, hay que replicar el
# cambio aqui tambien (mismo patron que 23_calibrate_weighted.py).
def stars_feb(zseries):
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    s = pd.cut(zseries, bins=bins, labels=labels).astype(float)
    s[zseries <= -2.5] = 0
    return s.astype(int)

FEB_WEIGHTS = {'ataque': 1.5, 'defensa': 1.5, 'rebote': 1.1, 'control': 0.9, 'generacion': 0.7, 'eficiencia': 1.1,
               'exterior': 0.7, 'faltas': 0.6, 'defbalon': 1, 'aro': 1, 'netrtg': 1.5, 'clasificacion': 2.2}
FEB_LETTER_EDGES = [-1.8, -1.4, -1.0, -0.6, -0.2, 0.2, 0.6, 1.2, 1.8, 2.4]
FEB_LETTER_BANDS = ['F', 'D', 'C-', 'C', 'C+', 'B-', 'B', 'B+', 'A-', 'A', 'A+']

feb_star = pd.DataFrame(index=feb17.index)
feb_star['ataque'] = stars_feb(zf('OER'))
feb_star['defensa'] = stars_feb(zf('DER', invert=True))
feb_star['rebote'] = stars_feb(zf('TRB%'))
feb_star['control'] = stars_feb(fz_control)
feb_star['generacion'] = stars_feb(fz_gen)
feb_star['eficiencia'] = stars_feb(fz_efi)
feb_star['exterior'] = stars_feb(fz_ext)
feb_star['faltas'] = stars_feb(zf('FTr'))
feb_star['defbalon'] = stars_feb(fz_defbalon)
feb_star['aro'] = stars_feb(fz_aro)
feb_star['netrtg_estrellas'] = stars_feb(zf('NetRtg'))
feb_net_rank = feb17['NetRtg'].rank(ascending=False, method='min').astype(int)
def rank_tier_feb(r):
    if r <= 3: return 1
    if r <= 6: return 2
    if r <= 10: return 3
    if r <= 14: return 4
    return 5
FEB_TIER_TO_STARS = {1: 5, 2: 4, 3: 3, 4: 2, 5: 1}
feb_star['clasif_estrellas'] = feb_net_rank.map(lambda r: FEB_TIER_TO_STARS[rank_tier_feb(r)])

feb_rating_raw = (
    FEB_WEIGHTS['ataque'] * feb_star['ataque'] + FEB_WEIGHTS['defensa'] * feb_star['defensa'] +
    FEB_WEIGHTS['rebote'] * feb_star['rebote'] + FEB_WEIGHTS['control'] * feb_star['control'] +
    FEB_WEIGHTS['generacion'] * feb_star['generacion'] + FEB_WEIGHTS['eficiencia'] * feb_star['eficiencia'] +
    FEB_WEIGHTS['exterior'] * feb_star['exterior'] + FEB_WEIGHTS['faltas'] * feb_star['faltas'] +
    FEB_WEIGHTS['defbalon'] * feb_star['defbalon'] + FEB_WEIGHTS['aro'] * feb_star['aro'] +
    FEB_WEIGHTS['netrtg'] * feb_star['netrtg_estrellas'] + FEB_WEIGHTS['clasificacion'] * feb_star['clasif_estrellas']
)
feb_rating_mean = feb_rating_raw.mean()
feb_rating_std = feb_rating_raw.std(ddof=0)
feb_rating_z = (feb_rating_raw - feb_rating_mean) / feb_rating_std
feb_grade = (5 + feb_rating_z * 2.2).clip(0, 10)

def letter_feb(zv):
    i = 0
    while i < len(FEB_LETTER_EDGES) and zv >= FEB_LETTER_EDGES[i]:
        i += 1
    return FEB_LETTER_BANDS[i]

def feb_rating_for(team_disp):
    k = NEW_TEAMS_FEB_KEY[team_disp]
    return {
        'valor': round(float(feb_rating_raw[k]), 1),
        'nota': round(float(feb_grade[k]), 1),
        'letra': letter_feb(feb_rating_z[k]),
        'puesto': int(feb_rating_raw.rank(ascending=False, method='min').astype(int)[k]),
        'n_liga': N_FEB,
    }

def feb_stats_for(team_disp):
    k = NEW_TEAMS_FEB_KEY[team_disp]
    return {
        'ataque': {'valor': round(float(feb17.loc[k, 'OER']), 1), 'unidad': 'pts/100 pos', 'puesto': int(FEB_RANKS['ataque'][k])},
        'defensa': {'valor': round(float(feb17.loc[k, 'DER']), 1), 'unidad': 'pts/100 pos encajados', 'puesto': int(FEB_RANKS['defensa'][k])},
        'rebote': {'valor': round(float(feb17.loc[k, 'TRB%']), 1), 'unidad': '% TRB', 'puesto': int(FEB_RANKS['rebote'][k])},
        'control': {'valor': f"TOV% {feb17.loc[k,'TOV%']:.1f} · AST/TOV {feb17.loc[k,'AST/TOV']:.2f}", 'unidad': '', 'puesto': int(FEB_RANKS['control'][k])},
        'generacion': {'valor': round(float(feb17.loc[k, 'AST%']), 1), 'unidad': '% AST', 'puesto': int(FEB_RANKS['generacion'][k])},
        'eficiencia': {'valor': f"eFG% {feb17.loc[k,'eFG%']:.1f} · TS% {feb17.loc[k,'TS%']:.1f}", 'unidad': '', 'puesto': int(FEB_RANKS['eficiencia'][k])},
        'exterior': {'valor': f"3P% {feb17.loc[k,'3P%']:.1f} · 3PAr {feb17.loc[k,'3PAr']:.1f}%", 'unidad': '', 'puesto': int(FEB_RANKS['exterior'][k])},
        'faltas': {'valor': round(float(feb17.loc[k, 'FTr']), 1), 'unidad': '% FTr', 'puesto': int(FEB_RANKS['faltas'][k])},
        'defbalon': {'valor': round(float(feb17.loc[k, 'STL%']), 1), 'unidad': '% STL', 'puesto': int(FEB_RANKS['defbalon'][k])},
        'aro': {'valor': f"BLK% {feb17.loc[k,'BLK%']:.1f} · Opp2P% {feb17.loc[k,'Opp_2P%']:.1f}", 'unidad': '', 'puesto': int(FEB_RANKS['aro'][k])},
        'n_liga': N_FEB,
    }

# ================= ENSAMBLAR JSON FINAL =================
out_teams = {}
for team in TEAMS_ALL:
    is_est = team in NEW_TEAMS
    d = {
        'name': team,
        'estimado_feb': is_est,
        'ritmo': {'poss': round(float(df.loc[team, 'Pace']), 1), 'perfil': int(stars_neutral('Pace')[team])},
        'ataque': {'oer': round(float(df.loc[team, 'OER']), 1), 'estrellas': int(stars(z('OER'))[team])},
        'defensa': {'der': round(float(df.loc[team, 'DER']), 1), 'estrellas': int(stars(z('DER', invert=True))[team])},
        'rebote': {
            'trb': round(float(df.loc[team, 'TRB%']), 1), 'estrellas': int(stars(z('TRB%'))[team]),
            'orb': round(float(df.loc[team, 'ORB%']), 1), 'orb_estrellas': int(stars(z('ORB%'))[team]),
            'drb': round(float(df.loc[team, 'DRB%']), 1), 'drb_estrellas': int(stars(z('DRB%'))[team]),
        },
        'control': {
            'tov': round(float(df.loc[team, 'TOV%']), 1), 'asttov': round(float(df.loc[team, 'AST/TOV']), 2),
            'estrellas': int(stars(z_control)[team]),
        },
        'generacion': {'estrellas': int(stars(z_gen)[team]), 'ast_pct': round(float(df.loc[team, 'AST%']), 1)},
        'eficiencia': {
            'efg': round(float(df.loc[team, 'eFG%']), 1), 'ts': round(float(df.loc[team, 'TS%']), 1),
            'fg': round(float(df.loc[team, 'FG%']), 1), 'estrellas': int(stars(z_efi)[team]),
        },
        'exterior': {'p3': round(float(df.loc[team, '3P%']), 1), 'p3ar': round(float(df.loc[team, '3PAr']), 1), 'estrellas': int(stars(z_ext)[team])},
        'faltas': {'ftr': round(float(df.loc[team, 'FTr']), 1), 'estrellas': int(stars(z('FTr'))[team])},
        'defbalon': {'stl': round(float(df.loc[team, 'STL%']), 1), 'estrellas': int(stars(z_defbalon)[team])},
        'aro': {'blk': round(float(df.loc[team, 'BLK%']), 1), 'opp2p': round(float(df.loc[team, 'Opp_2P%']), 1), 'estrellas': int(stars(z_aro)[team])},
        'arquetipo_ataque': archetypes[team]['ataque'],
        'arquetipo_ataque_motivo': archetypes[team]['ataque_motivo'],
        'arquetipo_defensa': archetypes[team]['defensa'],
        'gp': GP_FEB[team] if is_est else 34,
        'netrtg': round(float(df.loc[team, 'OER'] - df.loc[team, 'DER']), 1),
        'rank': {cat: int(RANKS[cat][team]) for cat in RANKS},
    }
    if is_est:
        d['gp_liga'] = 'Primera FEB 25/26'
        d['nota_estimacion'] = ('Equipo recién ascendido a ACB 26/27. Métricas estimadas a partir de su temporada en Primera FEB '
                                 '25/26, traducidas a equivalente ACB y penalizadas estructuralmente por venir de una categoría '
                                 'inferior. Ritmo se muestra sin traducir (valor real de Primera FEB).')
        d['feb_stats'] = feb_stats_for(team)
        d['feb_rating'] = feb_rating_for(team)
    out_teams[team] = d

with open('dashboard_teams_new.json', 'w', encoding='utf-8') as f:
    json.dump(out_teams, f, ensure_ascii=False, indent=1)

print("\nResumen equipos estimados:")
for t in NEW_TEAMS:
    print(t, "-> ataque", out_teams[t]['ataque'], "defensa", out_teams[t]['defensa'], "rank ataque", out_teams[t]['rank']['ataque'])

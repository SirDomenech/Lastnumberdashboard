import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

import pandas as pd
import numpy as np

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 100)

COEF = 0.30
NEW_TEAMS = ['LEYMA CORUÑA', 'MONBUS OBRADOIRO']
NEW_TEAMS_DISP = ['Leyma Coruña', 'Monbus Obradoiro']
OUT_TEAMS = ['Coviran Granada', 'Dreamland Gran Canaria']

acb = pd.read_csv('season_metrics.csv', index_col=0)
TRACK = "/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/77ef7d4c-data4basket_stats_17__Sheet1.csv"
track = pd.read_csv(TRACK).set_index('name')
acb_full = acb.join(track, how='left')
acb_full['PF_per100'] = acb_full['PF'] / acb_full['POSS'] * 100
acb_full['Top3_share'] = pd.read_csv('scoring_top3share.csv', index_col=0)['share']
acb_cont = acb_full.drop(index=[t for t in OUT_TEAMS if t in acb_full.index])

feb = pd.read_csv('feb_season_metrics.csv', index_col='team')
feb['PF_per100'] = feb['PF'] / feb['POSS'] * 100

QUALITY_METRICS = ['OER', 'DER', 'TRB%', 'ORB%', 'DRB%', 'TOV%', 'AST/TOV', 'AST%',
                    'eFG%', 'TS%', 'FG%', '3P%', '3PAr', 'FTr', 'STL%', 'BLK%',
                    'Opp_2P%', 'Opp_TOV%', 'Opp_FTr', 'PF_per100', 'Top3_share']
DIRECTION = {
    'OER': 1, 'DER': -1, 'TRB%': 1, 'ORB%': 1, 'DRB%': 1, 'TOV%': -1, 'AST/TOV': 1,
    'AST%': 1, 'eFG%': 1, 'TS%': 1, 'FG%': 1, '3P%': 1, '3PAr': 1, 'FTr': 1,
    'STL%': 1, 'BLK%': 1, 'Opp_2P%': -1, 'Opp_TOV%': 1, 'Opp_FTr': -1,
    'PF_per100': 0, 'Top3_share': 0,
}
feb_mean = feb[QUALITY_METRICS].mean()
feb_std = feb[QUALITY_METRICS].std(ddof=0)
acb_mean = acb_cont[QUALITY_METRICS].mean()
acb_std = acb_cont[QUALITY_METRICS].std(ddof=0)

NEEDED_STARS = ['Pace', 'OER', 'DER', 'TRB%', 'ORB%', 'DRB%', 'TOV%', 'AST/TOV', 'AST%',
                'eFG%', 'TS%', 'FG%', '3P%', '3PAr', 'FTr', 'STL%', 'BLK%', 'Opp_2P%']

WEIGHTS = {'ataque':2,'defensa':2,'rebote':1,'control':1,'generacion':0.8,'eficiencia':1,
           'exterior':0.8,'faltas':0.7,'defbalon':1,'aro':1,'netrtg':1,'clasificacion':1}

def translate(pen):
    translated = {}
    for team in NEW_TEAMS:
        z_feb = (feb.loc[team, QUALITY_METRICS] - feb_mean) / feb_std
        z_pen = z_feb * COEF - pen * pd.Series(DIRECTION)
        raw_acb_equiv = acb_mean + z_pen * acb_std
        row = {m: raw_acb_equiv[m] for m in QUALITY_METRICS}
        row['Pace'] = feb.loc[team, 'Pace']
        translated[team] = row
    df = pd.DataFrame(translated).T
    df.index = NEW_TEAMS_DISP
    return df

def z(df, col, invert=False):
    x = df[col]
    s = (x - x.mean()) / x.std(ddof=0)
    return -s if invert else s

def stars(zseries):
    bins = [-np.inf, -1.28, -0.52, 0.52, 1.28, np.inf]
    labels = [1, 2, 3, 4, 5]
    s = pd.cut(zseries, bins=bins, labels=labels).astype(float)
    s[zseries <= -2.5] = 0
    return s.astype(int)

def rank_tier(rank):
    if rank<=3: return 1
    if rank<=6: return 2
    if rank<=10: return 3
    if rank<=14: return 4
    return 5

TIER_TO_STARS = {1:5,2:4,3:3,4:2,5:1}

def compute_all(pen):
    trans = translate(pen)
    df = pd.concat([acb_cont[NEEDED_STARS], trans[NEEDED_STARS]])
    netrtg = df['OER'] - df['DER']

    z_control = (z(df,'TOV%',invert=True) + z(df,'AST/TOV')) / 2
    z_gen = (z(df,'OER') + z(df,'AST%') + z(df,'AST/TOV')) / 3
    z_efi = (z(df,'eFG%') + z(df,'TS%') + z(df,'FG%')) / 3
    z_ext = (z(df,'3P%') + z(df,'3PAr')) / 2
    z_defbalon = (z(df,'DER',invert=True) + z(df,'STL%')) / 2
    z_aro = (z(df,'BLK%') + z(df,'Opp_2P%',invert=True)) / 2

    stars_df = pd.DataFrame(index=df.index)
    stars_df['ataque'] = stars(z(df,'OER'))
    stars_df['defensa'] = stars(z(df,'DER',invert=True))
    stars_df['rebote'] = stars(z(df,'TRB%'))
    stars_df['control'] = stars(z_control)
    stars_df['generacion'] = stars(z_gen)
    stars_df['eficiencia'] = stars(z_efi)
    stars_df['exterior'] = stars(z_ext)
    stars_df['faltas'] = stars(z(df,'FTr'))
    stars_df['defbalon'] = stars(z_defbalon)
    stars_df['aro'] = stars(z_aro)

    netmean, netstd = netrtg.mean(), netrtg.std(ddof=0)
    znet = (netrtg - netmean) / netstd
    netstars = stars(znet)

    standings_rank = netrtg.rank(ascending=False, method='min').astype(int)
    clasifstars = standings_rank.map(lambda r: TIER_TO_STARS[rank_tier(r)])

    rating = (WEIGHTS['ataque']*stars_df['ataque'] + WEIGHTS['defensa']*stars_df['defensa'] +
              WEIGHTS['rebote']*stars_df['rebote'] + WEIGHTS['control']*stars_df['control'] +
              WEIGHTS['generacion']*stars_df['generacion'] + WEIGHTS['eficiencia']*stars_df['eficiencia'] +
              WEIGHTS['exterior']*stars_df['exterior'] + WEIGHTS['faltas']*stars_df['faltas'] +
              WEIGHTS['defbalon']*stars_df['defbalon'] + WEIGHTS['aro']*stars_df['aro'] +
              WEIGHTS['netrtg']*netstars + WEIGHTS['clasificacion']*clasifstars)

    pos = rating.rank(ascending=False, method='min').astype(int)
    return rating, pos, netrtg

if __name__ == '__main__':
    for pen in [1.0, 1.3, 1.6, 1.9, 2.2, 2.5, 2.8, 3.1, 3.4, 3.7, 4.0]:
        rating, pos, netrtg = compute_all(pen)
        print(f"PEN={pen:.2f}  Coruña: pos {pos['Leyma Coruña']} (rating {rating['Leyma Coruña']:.1f})   "
              f"Obradoiro: pos {pos['Monbus Obradoiro']} (rating {rating['Monbus Obradoiro']:.1f})")

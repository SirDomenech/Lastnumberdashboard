# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Construye el Excel de Altas y Bajas ACB 2026-27, tal y como aparecen
en https://acb.com/es/liga/tabla-mercado/2026-27
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# cada fila: (Equipo, Tipo, Jugador, Rol, Posicion, ClubProcedenciaODestino, Nota)
rows = []

def alta(equipo, jugador, pos, club, nota="", rol="Jugador"):
    rows.append((equipo, "Alta", jugador, rol, pos, club, nota))

def baja(equipo, jugador, club="", nota="", rol="Jugador"):
    rows.append((equipo, "Baja", jugador, rol, "", club, nota))

# ---------------- ASISA JOVENTUT ----------------
E = "Asisa Joventut"
alta(E, "Boogie Ellis", "Base", "Galatasaray")
alta(E, "Nico Laprovittola", "Base", "Barça")
alta(E, "Isaac Nogués", "Escolta", "Valencia Basket")
alta(E, "Alex Reyes", "Alero", "Kids&Us Manresa")
alta(E, "Yannick Kraag", "Alero", "Dubai Basketball", "cesión")
alta(E, "Eli John Ndiaye", "Ala-Pívot", "Real Madrid", "cesión")
alta(E, "Emir Sulejmanovic", "Ala-Pívot", "Unicaja")
alta(E, "Kwan Cheatham", "Ala-Pívot", "Reggio Emilia")
baja(E, "Adam Hanga")
baja(E, "Cameron Hunt", "Unicaja")
baja(E, "Guillem Vives", "Casademont Zaragoza")
baja(E, "Henri Drell", "BC Neptunas")
baja(E, "Jabari Parker", "Partizan")
baja(E, "Miguel Allen", "Charlotte 49ers")

# ---------------- BARÇA ----------------
E = "Barça"
alta(E, "Justin Robinson", "Base", "París Basketball")
alta(E, "Umoja Gibson", "Base", "Cedevita")
alta(E, "Agustín Ubal", "Alero", "Kids&Us Manresa")
alta(E, "Justin Minaya", "Alero", "Osceola Magic")
alta(E, "Stanley Umude", "Alero", "Austin Spurs")
alta(E, "Tyrese Martin", "Alero", "Philadelphia 76ers")
alta(E, "Olivier Nkamhoua", "Ala-Pívot", "Varese")
alta(E, "Tosan Evbuomwan", "Ala-Pívot", "Charlotte Hornets")
alta(E, "Josh Nebo", "Pívot", "Olimpia Milano")
alta(E, "Olek Balcerowski", "Pívot", "Unicaja")
alta(E, "Yoan Makoundou", "Pívot", "AS Monaco")
alta(E, "Aleksander Sekulic", "", "Dubai BC", "", rol="Entrenador")
baja(E, "Jan Vesely", "", "retirado")
baja(E, "Juani Marcos", "UCAM Murcia")
baja(E, "Miles Norris", "Bayern Munich")
baja(E, "Myles Cale", "Asvel Villeurbanne")
baja(E, "Nico Laprovittola", "Asisa Joventut")
baja(E, "Tomas Satoransky", "Hapoel Tel Aviv")
baja(E, "Tornike Shengelia", "Dubai Basketball")
baja(E, "Will Clyburn", "Fenerbahçe")
baja(E, "Willy Hernangómez", "Unicaja")
baja(E, "Xavi Pascual", "Dubai Basketball", "", rol="Entrenador")
baja(E, "Youssoupha Fall", "Nanjing Tongxi")

# ---------------- CASADEMONT ZARAGOZA ----------------
E = "Casademont Zaragoza"
alta(E, "Guillem Vives", "Base", "Asisa Joventut")
alta(E, "Sergi García", "Base", "Movistar Estudiantes")
alta(E, "Justin Jaworski", "Escolta", "Surne Bilbao")
alta(E, "Caleb Homesley", "Alero", "Bahçeşehir Koleji")
alta(E, "Nico Brussino", "Alero", "Dreamland Gran Canaria")
alta(E, "Roberts Blumbergs", "Ala-Pívot", "Petkim Spor")
alta(E, "Jilson Bango", "Pívot", "Fenerbahce BEKO")
alta(E, "Laurynas Birutis", "Pívot", "Zalgiris Kaunas")
baja(E, "Bojan Dubljevic", "", "retirado")
baja(E, "Christ Koumadje")
baja(E, "Devin Robinson", "WKS Śląsk Wrocław")
baja(E, "DJ Stephens")
baja(E, "Joaquín Rodríguez", "Dreamland Gran Canaria")
baja(E, "Justin Wright-Foreman", "Al Ahly Cairo")
baja(E, "Marco Spissu", "Napoli Basket")
baja(E, "Nate Watson", "Bursaspor")
baja(E, "Santi Yusta", "Anadolu Efes")

# ---------------- FIATC GIRONA ----------------
E = "FIATC Girona"
alta(E, "Andrzej Pluta", "Base", "Legia Warszawa")
alta(E, "Dominykas Stenionis", "Base", "Valmiera Glass VIA")
alta(E, "Isaac Vázquez", "Base", "Club Ourense Baloncesto")
alta(E, "Mac McClung", "Base", "Chicago Bulls")
alta(E, "Stanley Whittaker", "Base", "Aliaga Petkim Spor")
alta(E, "Jassel Pérez", "Alero", "Vaqueros de Bayamón")
alta(E, "David N'Guessan", "Ala-Pívot", "Braunschweig")
alta(E, "Aljaz Kunc", "Pívot", "Twarde Pierniki Toruń")
baja(E, "Cameron Hildreth")
baja(E, "Derek Needham", "Chorale Roanne")
baja(E, "Guillem Ferrando", "Grupo Alega Cantabria")
baja(E, "James Karnik", "Vancouver Bandits")
baja(E, "Juan Fernández", "South Carolina")
baja(E, "Mark Hughes", "iLERNA Lleida")
baja(E, "Mindaugas Susinskas", "Sabah BC")
baja(E, "Otis Livingston II", "Cluj Napoca")
baja(E, "Pepe Vildoza", "Boca Juniors")

# ---------------- ILERNA LLEIDA ----------------
E = "Ilerna Lleida"
alta(E, "Dani García", "Base", "UCAM Murcia")
alta(E, "Darius McGhee", "Base", "Bourg-en-Bresse")
alta(E, "Mark Hughes", "Escolta", "FIATC Girona")
alta(E, "Aurimas Majauskas", "Ala-Pívot", "Neptunas")
alta(E, "Kur Kuath", "Pívot", "Dreamland Gran Canaria")
alta(E, "Zacharie Perrin", "Pívot", "Hamburgo Towers")
baja(E, "Caleb Agada", "Monbus Obradoiro")
baja(E, "Cameron Krutwig", "Phoenix Hagen")
baja(E, "Corey Walden")
baja(E, "Gyorgy Goloman", "Legia Warszawa")
baja(E, "Millán Jiménez", "Movistar Estudiantes")

# ---------------- KIDS&US MANRESA ----------------
E = "Kids&Us Manresa"
alta(E, "J.D. Notae", "Base", "Trapani Shark")
alta(E, "Lucas Beaufort", "Base", "Saint-Chamond")
alta(E, "Rafa Villar", "Base", "Kosner Baskonia")
alta(E, "Lukasz Kolenda", "Escolta", "Rostock Seawolves")
alta(E, "Chibuzo Agbo", "Alero", "Cholet Basket")
alta(E, "Pablo Tamba", "Alero", "LSU Tigers")
alta(E, "Eric Vila", "Ala-Pívot", "Dreamland Gran Canaria")
alta(E, "Timmy Allen", "Ala-Pívot", "PAOK")
alta(E, "Yordan Minchev", "Ala-Pívot", "Niners de Chemnitz")
alta(E, "Nick Ongenda", "Pívot", "Hapoel Haemek")
baja(E, "Agustín Ubal", "Barça")
baja(E, "Álex Reyes", "Asisa Joventut")
baja(E, "Dani Pérez", "Súper Agropal Palencia")
baja(E, "David Duke Jr.", "Varese")
baja(E, "Eli Brooks", "Trier")
baja(E, "Gustav Knudsen", "Universidad de San Francisco")
baja(E, "Kaodirichi Akobundu", "Zalgiris")
baja(E, "Louis Olinde", "Reyer Venezia")
baja(E, "Marcis Steinbergs", "UCAM Murcia")
baja(E, "Pauly Paulicap", "Slavia Prague")
baja(E, "Retin Obasohan", "Recoletas Salud San Pablo Burgos")

# ---------------- KOSNER BASKONIA ----------------
E = "Kosner Baskonia"
alta(E, "Damion Baugh", "Base", "Valley Suns")
alta(E, "AJ Lawson", "Alero", "Toronto Raptors")
alta(E, "Chris Duarte", "Alero", "Unicaja")
alta(E, "Dewayne Stewart Jr", "Alero", "Cedevita Olimpija")
alta(E, "Kenneth Faried", "Ala-Pívot", "Cangrejeros de Santurce")
alta(E, "Alex Len", "Pívot", "Kosner Baskonia", "así consta en la página (renovación/dato a confirmar)")
baja(E, "Eugene Omoruyi", "Besiktas")
baja(E, "Gytis Radzevicius", "Rytas Vilnius")
baja(E, "Jesse Edwards", "BC Roma SPQR")
baja(E, "Khalifa Diop", "Cleveland Cavaliers")
baja(E, "Mamadi Diakite", "Dubai BC")
baja(E, "Markquis Nowell")
baja(E, "Rafa Villar", "Kids&Us Manresa")
baja(E, "Timothé Luwawu-Cabarrot", "Real Madrid")
baja(E, "Trent Forrest", "Fenerbahce")

# ---------------- LA LAGUNA TENERIFE ----------------
E = "La Laguna Tenerife"
alta(E, "Arturs Kurucs", "Base", "Río Breogán")
alta(E, "Kyle Guy", "Escolta", "Shanxi Loongs")
alta(E, "TJ Bamba", "Escolta", "Rasta Vechta")
alta(E, "Xabi López-Arostegui", "Alero", "Valencia Basket")
alta(E, "Ethan Happ", "Pívot", "Recoletas Salud San Pablo Burgos")
alta(E, "Vince Hunter", "Pívot", "Lokomotiv Kuban")
alta(E, "Jaka Lakovic", "", "", "", rol="Entrenador")
baja(E, "Dylan Bordón", "Universidad de San Francisco")
baja(E, "Elvar Fridriksson", "Neptunas Klaipeda")
baja(E, "Fran Guerra", "CB Gran Canaria")
baja(E, "Joan Sastre")
baja(E, "Kevin Yebo", "Safiport Erokspor")
baja(E, "Patty Mills", "Asvel Villeurbanne")
baja(E, "Thomas Scrubb", "Lobos Puebla")
baja(E, "Txus Vidorreta", "Unicaja", "", rol="Entrenador")

# ---------------- LEYMA CORUÑA ----------------
E = "Leyma Coruña"
alta(E, "Alonzo Verge Jr.", "Base", "Rasta Vechta")
alta(E, "Tomas Dimsa", "Escolta", "PAOK")
alta(E, "Lukas Uleckas", "Alero", "Juventus Utenos")
alta(E, "Dmytro Skapintsev", "Pívot", "Hapoel Jerusalem")
alta(E, "George Conditt IV", "Pívot", "Gigantes de Carolina")
alta(E, "Karlis Silins", "Pívot", "Neptunas Klaipeda")
baja(E, "Abdou Thiam", "Coviran Granada")
baja(E, "Danilo Brnovic", "Alimerka Oviedo Baloncesto")
baja(E, "Illimane Diop", "BCH Knights")
baja(E, "Joe Cremo", "Dreamland Gran Canaria")
baja(E, "Macachi Braz", "Albacete Basket")
baja(E, "Moustapha Barro", "Alimerka Oviedo")
baja(E, "Strahinja Micovic")

# ---------------- MONBUS OBRADOIRO ----------------
E = "Monbus Obradoiro"
alta(E, "Brandon Childress", "Base", "Bursaspor")
alta(E, "Caleb Agada", "Escolta", "Ilerna Lleida")
alta(E, "Leo Meindl", "Alero", "Recoletas Salud San Pablo Burgos")
alta(E, "Alonso Faure", "Ala-Pívot", "Alimerka Oviedo")
alta(E, "Efe Abogidi", "Ala-Pívot", "Rio Grande Valley")
alta(E, "Joel Soriano", "Pívot", "Ratiopharm Ulm")
baja(E, "Aitor Etxeguren", "CBZ-Club Baloncesto Zaragoza")
baja(E, "Alonso Grela", "Cultural y Deportiva Leonesa")
baja(E, "Dejan Kravic")
baja(E, "Denzel Andersson", "Astoria Bydgoszcz")
baja(E, "Goran Huskic", "Baloncesto Fuenlabrada")
baja(E, "Leo Westermann")
baja(E, "Micah Speight", "Movistar Estudiantes")
baja(E, "Tra Holder")
baja(E, "Travis Munnings", "Movistar Estudiantes")

# ---------------- MORABANC ANDORRA ----------------
E = "MoraBanc Andorra"
alta(E, "James Akinjo", "Base", "Ness Ziona")
alta(E, "Aaron Best", "Escolta", "", "renovación")
alta(E, "Chumi Ortega", "Escolta", "", "renovación")
alta(E, "Kassius Robertson", "Escolta", "Dreamland Gran Canaria")
alta(E, "Lazar Mutic", "Alero", "BC Lietkabelis")
alta(E, "Wes Iwundu", "Alero", "Ironi Kiryat Ata")
alta(E, "Cameron McGriff", "Ala-Pívot", "Salt Lake City Stars")
alta(E, "Owen Aquino", "Ala-Pívot", "Universidad de High Point")
alta(E, "Leon Radosevic", "Pívot", "Treviso Basket")
baja(E, "Aaron Ganal", "CB Salou")
baja(E, "Justin McKoy", "SIG Strasbourg")
baja(E, "Kostas Kostadinov", "Coretec Oostende")
baja(E, "Rubén Guerrero", "Recoletas Salud San Pablo Burgos")
baja(E, "Shannon Evans II", "Promitheas")
baja(E, "Sir' Jabari Rice", "Reyer Venezia")
baja(E, "Stan Okoye", "Goteborg")
baja(E, "Yves Pons", "Asvel Villeurbanne")

# ---------------- REAL MADRID ----------------
E = "Real Madrid"
alta(E, "Max Shulga", "Escolta", "Boston Celtics")
alta(E, "Nick Smith Jr.", "Escolta", "Los Angeles Lakers")
alta(E, "Timothé Luwawu-Cabarrot", "Alero", "Kosner Baskonia")
alta(E, "Jaime Pradilla", "Ala-Pívot", "Valencia Basket")
alta(E, "Mikael Jantunen", "Ala-Pívot", "Fenerbahçe")
alta(E, "Damian Jones", "Pívot", "Vaqueros de Bayamón")
alta(E, "Olivier Sarr", "Pívot", "Cleveland Cavaliers")
alta(E, "Pedro Martínez", "", "Valencia Basket", "", rol="Entrenador")
baja(E, "Alex Len", "Kosner Baskonia")
baja(E, "David Krämer", "Estrella Roja")
baja(E, "Eli John Ndiaye", "Asisa Joventut", "cesión")
baja(E, "Izan Almansa")
baja(E, "Mady Sissoko", "Besiktas")
baja(E, "Mario Hezonja", "Cleveland Cavaliers")
baja(E, "Ömer Yurtseven")
baja(E, "Sergio Scariolo", "", "", rol="Entrenador")
baja(E, "Trey Lyles", "Minnesota Timberwolves")

# ---------------- RECOLETAS SALUD SAN PABLO BURGOS ----------------
E = "Recoletas Salud San Pablo Burgos"
alta(E, "DJ Steward", "Base", "Trentino")
alta(E, "Ziga Samar", "Base", "Dreamland Gran Canaria")
alta(E, "Chase Audige", "Escolta", "Unicaja")
alta(E, "Raúl Lobaco", "Escolta", "Alimerka Oviedo")
alta(E, "Retin Obasohan", "Escolta", "Kids&Us Manresa")
alta(E, "Dusan Radosavljevic", "Alero", "FMP SoccerBet")
alta(E, "Vlatko Cancar", "Alero", "EA7 Milán")
alta(E, "Christian Sengfelder", "Ala-Pívot", "Ratiopharm Ulm")
alta(E, "Sekou Doumbouya", "Ala-Pívot", "Koshigaya Alphas")
alta(E, "Balsa Koprivica", "Pívot", "Bahcesehir Koleji")
alta(E, "Rubén Guerrero", "Pívot", "MoraBanc Andorra")
baja(E, "Ethan Happ", "La Laguna Tenerife")
baja(E, "Gonzalo Corbalán", "Valencia Basket")
baja(E, "Jaden Shackelford", "Tianjin Pioneers")
baja(E, "Jermaine Samuels Jr.", "Tezenis Verona")
baja(E, "Jon Axel Gudmundsson", "Dreamland Gran Canaria")
baja(E, "Juan Rubio", "Dreamland Gran Canaria")
baja(E, "Leo Meindl", "Monbus Obradoiro")
baja(E, "Luke Fischer", "Dreamland Gran Canaria")
baja(E, "Yannick Nzosa", "Unicaja", "fin de cesión")

# ---------------- RÍO BREOGÁN ----------------
E = "Río Breogán"
alta(E, "Rasir Bolton", "Base", "GeVi Napoli")
alta(E, "Josep Peris", "Escolta", "CB Zamora")
alta(E, "Tevin Brown", "Alero", "Rasta Vechta")
alta(E, "Andersson García", "Ala-Pívot", "Utah Jazz")
alta(E, "Edgar Vicedo", "Ala-Pívot", "Hestia Menorca")
alta(E, "Aleksa Ilic", "Pívot", "SC Derby")
alta(E, "Jonathan Kasibabu", "Pívot", "Flexicar Fuenlabrada")
baja(E, "Arturs Kurucs", "La Laguna Tenerife")
baja(E, "Dewayne Russell", "Treviso Basket")
baja(E, "Dragan Apic", "Club Soles de Mexicali")
baja(E, "Iván Cruz", "Flexicar Fuenlabrada")
baja(E, "Jordan Walker", "Movistar Estudiantes")

# ---------------- SURNE BILBAO ----------------
E = "Surne Bilbao"
alta(E, "Adam Somogyi", "Base", "Szolnoki Olaj")
alta(E, "Dan Duščak", "Base", "Alimerka Oviedo")
alta(E, "Nate Darling", "Escolta", "Elan Chalon")
alta(E, "Manex Ansorregi", "Alero", "Askatuak Gipuzkoa")
alta(E, "Bastien Vautier", "Pívot", "Asvel Villeurbanne")
alta(E, "Ondřej Husták", "Pívot", "King Szczecin")
baja(E, "Amar Sylla", "Gimnasia de Comodoro")
baja(E, "Bassala Bagayoko", "Texas Tech")
baja(E, "Justin Jaworski", "Casademont Zaragoza")
baja(E, "Melwin Pantzar", "Unicaja", "cesión")
baja(E, "Stefan Lazarevic", "Spartak Subotica")

# ---------------- UCAM MURCIA ----------------
E = "UCAM Murcia"
alta(E, "Juani Marcos", "Base", "Barça")
alta(E, "Souley Boum", "Alero", "BC Vienna")
alta(E, "Marcis Steinbergs", "Ala-Pívot", "Kids&Us Manresa")
alta(E, "Jean-Marc Pansa", "Pívot", "Sabah BC")
baja(E, "Dani García", "iLERNA Lleida")
baja(E, "David DeJulius", "Besiktas JK", "cesión")
baja(E, "Devontae Cacok", "Hapoel Jerusalén")
baja(E, "Jaylen Hands", "Strasbourg")
baja(E, "Kelan Martin", "Illawarra Hawks")

# ---------------- UNICAJA ----------------
E = "Unicaja"
alta(E, "Melwin Pantzar", "Base", "Surne Bilbao", "retorna de cesión")
alta(E, "Cameron Hunt", "Escolta", "Asisa Joventut")
alta(E, "Ignas Brazdeikis", "Alero", "Zalgiris de Kaunas")
alta(E, "Simonas Lukosius", "Alero", "Dubai BC", "cesión")
alta(E, "Amine Noua", "Ala-Pívot", "Aris Betsson Thessaloniki")
alta(E, "Willy Hernangómez", "Pívot", "Barça")
alta(E, "Yannick Nzosa", "Pívot", "Recoletas Salud San Pablo Burgos", "retorna de cesión")
alta(E, "Txus Vidorreta", "", "La Laguna Tenerife", "", rol="Entrenador")
baja(E, "Augustine Rubit", "Maccabi Ashdod")
baja(E, "Chase Audige", "Recoletas Salud San Pablo Burgos")
baja(E, "Chris Duarte", "Kosner Baskonia")
baja(E, "Emir Sulejmanovic", "Asisa Joventut")
baja(E, "Ibon Navarro", "Estrella Roja", "", rol="Entrenador")
baja(E, "James Webb III", "Safiport Erokspor")
baja(E, "Justin Cobbs", "Jilin Northeast Tigers")
baja(E, "Olek Balcerowski", "Barça")
baja(E, "Xavier Castañeda", "Nanterre 92")

# ---------------- VALENCIA BASKET ----------------
E = "Valencia Basket"
alta(E, "Mario Saint-Supéry", "Base", "Universidad de Gonzaga")
alta(E, "Tj Shorts", "Base", "Panathinaikos")
alta(E, "Armoni Brooks", "Escolta", "Asvel Villeurbanne")
alta(E, "Gonzalo Corbalán", "Escolta", "Recoletas Salud San Pablo Burgos")
alta(E, "Lucas Marí", "Escolta", "Vermont")
alta(E, "Elias Valtonen", "Alero", "Coviran Granada")
alta(E, "Dylan Osetkowski", "Ala-Pívot", "Partizan")
alta(E, "Jasiel Rivero", "Ala-Pívot", "Estrella Roja")
alta(E, "Mo Gueye", "Ala-Pívot", "Windy City Bulls")
alta(E, "Nikola Mirotic", "Ala-Pívot", "As Mónaco")
alta(E, "Xavi Albert", "", "", "", rol="Entrenador")
baja(E, "Brancou Badio", "Panathinaikos")
baja(E, "Braxton Key", "Fenerbaçe")
baja(E, "Darius Thompson", "Olimpia Milano")
baja(E, "Isaac Nogués", "Asisa Joventut")
baja(E, "Jaime Pradilla", "Real Madrid")
baja(E, "Jean Montero", "Olympiacos")
baja(E, "Matt Costello", "Chiba Jets")
baja(E, "Pedro Martínez", "Real Madrid", "", rol="Entrenador")
baja(E, "Sergio de Larrea", "Dallas Mavericks")
baja(E, "Xabi López-Arostegui", "La Laguna Tenerife")

# ================= build workbook =================
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Altas y Bajas 26-27"

headers = ["Equipo", "Tipo", "Jugador", "Rol", "Posición", "Procedencia / Destino", "Nota"]
ws.append(headers)

FONT_NAME = "Arial"
header_fill = PatternFill("solid", fgColor="1F2937")
header_font = Font(name=FONT_NAME, bold=True, color="FFFFFF", size=11)
alta_fill = PatternFill("solid", fgColor="E2F0D9")
baja_fill = PatternFill("solid", fgColor="FCE4E4")
coach_font = Font(name=FONT_NAME, italic=True, size=10)
normal_font = Font(name=FONT_NAME, size=10)
thin = Side(style="thin", color="D9D9D9")
border = Border(left=thin, right=thin, top=thin, bottom=thin)

for c in range(1, len(headers) + 1):
    cell = ws.cell(row=1, column=c)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = border

for r in rows:
    ws.append(r)

n_players = sum(1 for r in rows if r[3] == "Jugador")
n_coaches = sum(1 for r in rows if r[3] == "Entrenador")
n_altas = sum(1 for r in rows if r[1] == "Alta")
n_bajas = sum(1 for r in rows if r[1] == "Baja")

for i, r in enumerate(rows, start=2):
    fill = alta_fill if r[1] == "Alta" else baja_fill
    font = coach_font if r[3] == "Entrenador" else normal_font
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=i, column=c)
        cell.fill = fill
        cell.font = font
        cell.border = border
        cell.alignment = Alignment(vertical="center", wrap_text=False)

widths = [26, 8, 26, 12, 12, 34, 30]
for i, w in enumerate(widths, start=1):
    ws.column_dimensions[get_column_letter(i)].width = w

ws.freeze_panes = "A2"
ws.auto_filter.ref = f"A1:G{len(rows)+1}"

# ---- hoja resumen ----
ws2 = wb.create_sheet("Resumen por equipo")
ws2.append(["Equipo", "Altas (jugadores)", "Bajas (jugadores)", "Altas (staff)", "Bajas (staff)"])
for c in range(1, 6):
    cell = ws2.cell(row=1, column=c)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = Alignment(horizontal="center")
    cell.border = border

teams_order = []
for r in rows:
    if r[0] not in teams_order:
        teams_order.append(r[0])

for t in teams_order:
    trows = [r for r in rows if r[0] == t]
    a_j = sum(1 for r in trows if r[1] == "Alta" and r[3] == "Jugador")
    b_j = sum(1 for r in trows if r[1] == "Baja" and r[3] == "Jugador")
    a_s = sum(1 for r in trows if r[1] == "Alta" and r[3] == "Entrenador")
    b_s = sum(1 for r in trows if r[1] == "Baja" and r[3] == "Entrenador")
    ws2.append([t, a_j, b_j, a_s, b_s])

for row in ws2.iter_rows(min_row=2, max_row=ws2.max_row, max_col=5):
    for cell in row:
        cell.font = normal_font
        cell.border = border
        cell.alignment = Alignment(horizontal="center" if cell.column > 1 else "left")

ws2.column_dimensions["A"].width = 32
for col in "BCDE":
    ws2.column_dimensions[col].width = 16
ws2.freeze_panes = "A2"

# ---- hoja leeme ----
ws3 = wb.create_sheet("Léeme")
ws3.column_dimensions["A"].width = 100
leeme = [
    "ALTAS Y BAJAS ACB 2026-27 — fuente: acb.com/es/liga/tabla-mercado/2026-27",
    "",
    f"Total de equipos: {len(teams_order)}",
    f"Total de movimientos de jugadores: {n_players}  (Altas: {sum(1 for r in rows if r[1]=='Alta' and r[3]=='Jugador')} / "
    f"Bajas: {sum(1 for r in rows if r[1]=='Baja' and r[3]=='Jugador')})",
    f"Movimientos de staff técnico (entrenadores): {n_coaches} — filas en cursiva, no cuentan para el modelo de rating de jugadores.",
    "",
    "Cómo leer la hoja 'Altas y Bajas 26-27':",
    "- Cada fila es un movimiento: una Alta (incorporación) o una Baja (salida) de un jugador o entrenador respecto al equipo.",
    "- 'Procedencia / Destino': de dónde viene (si es Alta) o a dónde va (si es Baja), tal y como lo indica la página. Vacío = no especificado en la fuente (agente libre, sin anunciar, etc.).",
    "- 'Nota': marca casos especiales — cesión, retirado, renovación, fin de cesión.",
    "- Verde = Alta, Rojo = Baja. Cursiva = staff técnico (no jugador).",
    "",
    "Advertencias importantes:",
    "- Esta tabla es una TRANSCRIPCIÓN del extracto automático de la página de acb.com. Antes de usarla para construir el impacto de fichajes,",
    "  conviene que la revises rápidamente contra la página en vivo — sobre todo casos marcados con nota, y el de Alex Len en Kosner Baskonia,",
    "  que en la fuente aparece como alta 'desde Kosner Baskonia' (mismo club) — probablemente una renovación mal etiquetada en la web, a confirmar.",
    "- Leyma Coruña y Monbus Obradoiro suben desde Primera FEB: no tienen histórico en player_season.csv (ACB). Sus estadísticas de la",
    "  temporada pasada están en el Box_Scores_FEB_Completo que adjuntaste — siguiente paso será cruzar esos dos rosters con ese CSV",
    "  para construir su 'bajas/altas medibles' igual que se hizo con Valencia Basket y Real Madrid.",
    "- Para el resto de equipos (jugadores que vienen de otras ligas ACB o del extranjero), usaré player_season.csv más las fuentes ya",
    "  usadas en fases anteriores (acb.com, proballers, wikipedia, etc.) para las bajas que salen de ACB y las altas que llegan de fuera.",
]
for i, line in enumerate(leeme, start=1):
    ws3.cell(row=i, column=1, value=line).font = Font(name=FONT_NAME, size=10, bold=(i == 1))
    ws3.cell(row=i, column=1).alignment = Alignment(wrap_text=True, vertical="top")

wb.save("Altas_Bajas_ACB_26-27.xlsx")
print("OK", len(rows), "filas |", n_players, "jugadores |", n_coaches, "staff |", len(teams_order), "equipos")

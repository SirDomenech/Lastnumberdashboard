# -*- coding: utf-8 -*-
import os as _os
_os.chdir(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'data'))
# ^ Reorg 28/09/2026: separacion frontend/backend -- este script vive en
#   backend/pipeline/ pero sigue leyendo/escribiendo sus CSV/JSON/XLSX con
#   rutas relativas como antes (todos en backend/data/), asi que apuntamos
#   el cwd ahi en vez de reescribir cada ruta del script.

"""
Rating de jugador v4 -- Valencia Basket. Cuarta vuelta, feedback de Miguel sobre v3:

1) Dar rol esperado también a los traspasos ACB->ACB (Corbalán, Valtonen), no
   solo a los fichajes de fuera -- y avisar de que el rol puede cambiar de
   equipo a equipo.
2) Ponderar el CONTEXTO DE EQUIPO DE ORIGEN: Corbalán viene de un equipo peor
   (Burgos) -- eso también hay que ponderarlo, no solo el nivel de liga.
3) Reajustar las bajas: jugaron en el MEJOR equipo de la liga (Valencia,
   campeón, +14.5 de NetRtg, el mejor de los 16 reales). Jean Montero no puede
   tener un 80 -- eso hay que subirlo.

Ajuste nuevo: TEAM_CONTEXT_ADJ, en puntos de rating, proporcional al z-score
del Net Rating real del equipo de ORIGEN del jugador (frente a los 16 equipos
reales de ACB -- misma curva que ya usa el dashboard para el Rating de equipo).
Un jugador que sale de un equipo mucho mejor que la media sube de nota (jugó
un rol real en un equipo ganador, rodeado de más nivel); uno que sale de un
equipo mucho peor que la media baja (su producción bruta refleja en parte un
contexto más fácil). Mismo coeficiente k para ambas direcciones, por
consistencia y porque es simétrico por construcción.

k = 8 puntos de rating por desviación estándar de NetRtg del equipo de origen
(editorial, primer corte -- ajustable). Con Valencia en z=+1.83 (NetRtg +14.5,
el mejor de los 16 reales), el ajuste es de +14.6 puntos para cualquier
jugador que sale de Valencia.

De momento este ajuste solo se aplica a jugadores con equipo de origen EN LA
ACB (tenemos el Net Rating real de los 16 equipos). Para los fichajes de
fuera de la ACB (TJ Shorts, Brooks, Mirotic, etc.) no tengo un rating de
fuerza de sus clubes de origen (Paris Basketball, Panathinaikos, etc.) --
ahí sigue aplicando solo el ajuste por NIVEL DE LIGA de la vuelta anterior,
no por fuerza del club dentro de esa liga. Lo dejo anotado como limitación,
no lo invento.
"""
import pandas as pd
import numpy as np
from scipy import stats as sps
import json
import re
import unicodedata

def norm(s):
    if pd.isna(s):
        return ''
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode('ascii')
    return ' '.join(s.lower().strip().split())

pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 60)
pd.set_option('display.max_rows', 200)

# ============================================================================
# 0) NetRtg real de los 16 equipos ACB (curva de referencia, la misma que usa
#    el dashboard) -- para el ajuste por equipo de origen.
# ============================================================================
with open('dashboard_v2_content.html', encoding='utf-8') as f:
    _html = f.read()
_m = re.search(r'const TEAMS = (\{.*?\});\n(?=const LOGOS)', _html, re.S)
_teams = json.loads(_m.group(1))
_real = {k: v for k, v in _teams.items() if not v['estimado_feb']}
_net_vals = [t['netrtg'] for t in _real.values()]
NET_MEAN, NET_STD = np.mean(_net_vals), np.std(_net_vals)

acb_season = pd.read_csv('season_metrics.csv', index_col=0)
TEAM_NETRTG = {t: (row['OER'] - row['DER']) for t, row in acb_season.iterrows()}

K_TEAM_CONTEXT = 8.0  # puntos de rating por SD de NetRtg del equipo de origen

def team_context_adj(team_name):
    if team_name not in TEAM_NETRTG:
        return 0.0, None
    z = (TEAM_NETRTG[team_name] - NET_MEAN) / NET_STD
    return round(K_TEAM_CONTEXT * z, 1), round(z, 2)

# ============================================================================
# 1) referencia ACB (igual que v3)
# ============================================================================
ps = pd.read_csv('player_season.csv')
rm = pd.read_csv('roster_matched.csv')
POS_MAP = {'G':'Guard','PG':'Guard','SG':'Guard','F':'Forward','SF':'Forward','PF':'Forward',
           'GF':'Forward','C':'Center','FC':'Center','-':None}
rm['pos_group'] = rm['Pos'].map(POS_MAP)
pos_by_id = rm.dropna(subset=['id']).drop_duplicates('id').set_index('id')['pos_group']
ps['pos_group'] = ps['id'].map(pos_by_id)

tg = pd.read_csv('team_game_full.csv')
team_trb = tg.groupby('Nombre equipo', as_index=False).agg(Team_TRB_season=('TRB','sum'), Opp_TRB_season=('Opp_TRB','sum'))
ps = ps.merge(team_trb, left_on='team_last', right_on='Nombre equipo', how='left')
MP = ps['MP_sec']/60; T_MP = ps['T_MPsec']/60
ps['eFG%'] = 100*(ps['FGM'] + 0.5*ps['P3M']) / ps['FGA']
ps['TRB%'] = 100*ps['TRB']*(T_MP/5) / (MP*(ps['Team_TRB_season']+ps['Opp_TRB_season']))
ps['BPG'] = ps['BLK']/ps['games']
ps['FG%'] = 100*ps['FGM']/ps['FGA']

qualified = ps[~ps['bajo_volumen']].copy()
ps['name_norm'] = ps['nickname'].map(norm)
ps_by_name = ps.set_index('name_norm')

def lookup_player(name):
    key = norm(name)
    if key not in ps_by_name.index:
        return None
    row = ps_by_name.loc[key]
    if isinstance(row, pd.DataFrame):
        row = row.sort_values('games', ascending=False).iloc[0]
    return row

CORE = ['USG%', 'AST%', 'PPG', 'APG']
SEC = {'eFG%': 1, 'TRB%': 1, 'BPG': 1, 'FG%': 1, '3P%': 1, 'TOV%': -1}
REF_WHOLE = {m: qualified[m].dropna().values for m in CORE + ['MPG']}
REF_POS = {grp: {m: qualified[qualified['pos_group']==grp][m].dropna().values for m in SEC}
           for grp in ['Guard', 'Forward', 'Center']}
ROLE_METRICS = ['USG%','AST%','TS%','3PAr','FTr']
qualified_rm = rm['nickname'].notna() & (rm['bajo_volumen']==False)
REF_ROLE = {grp: {m: rm.loc[qualified_rm & (rm['pos_group']==grp), m].dropna().values for m in ROLE_METRICS}
            for grp in ['Guard', 'Forward', 'Center']}

def pctl(ref, value, invert=False):
    if value is None or pd.isna(value) or len(ref) < 5:
        return np.nan
    p = sps.percentileofscore(ref, value, kind='mean')
    return 100 - p if invert else p

def rating_from_metrics(m, pos_group):
    core_p = [pctl(REF_WHOLE[k], m[k]) for k in CORE]
    core_avg = np.nanmean(core_p) if not all(pd.isna(x) for x in core_p) else np.nan
    mpg_p = pctl(REF_WHOLE['MPG'], m['MPG'])
    if pos_group in REF_POS:
        sec_p = [pctl(REF_POS[pos_group][k], m[k], invert=(d==-1)) for k, d in SEC.items()]
        sec_avg = np.nanmean(sec_p) if not all(pd.isna(x) for x in sec_p) else np.nan
    else:
        sec_avg = np.nan
    parts = [(0.55, core_avg), (0.25, mpg_p), (0.20, sec_avg)]
    parts = [(w, v) for w, v in parts if not pd.isna(v)]
    if not parts:
        return np.nan
    wsum = sum(w for w, v in parts)
    return sum(w*v for w, v in parts) / wsum

AST_ABS_MIN = 18
def classify_role(pos_group, ast_pct, usg_pct, ts_pct, threepar_pct, ftr_pct, ppg, height_m=None,
                   ast_raw=None, usg_raw=None):
    g = pos_group
    if any(pd.isna(v) for v in [ast_pct, usg_pct, ts_pct, threepar_pct, ftr_pct]) or pd.isna(ppg):
        return 'Sin datos'
    elite_scorer = (ppg > 15.5 and ast_pct < 80) or (usg_pct >= 70 and ts_pct >= 65) or (usg_pct >= 80 and ppg >= 14)
    if g == 'Guard':
        if ast_pct >= 80 and usg_pct >= 55: return 'Primary Ball Handler'
        if ast_pct >= 80 and usg_pct < 55: return 'Floor General'
        if ppg > 15.5 and ast_pct < 80: return 'Elite Scorer'
        if 40 <= ast_pct <= 80 and 45 <= usg_pct <= 90: return 'Secondary Ball Handler'
        if elite_scorer: return 'Elite Scorer'
        if threepar_pct >= 75 and usg_pct < 55: return 'Spot-Up Shooter'
        if usg_pct >= 50: return 'Scorer'
        return 'Spot-Up Shooter'
    if g == 'Forward':
        tall = height_m > 2.00 if height_m is not None else False
        if tall and ppg >= 9 and usg_pct >= 35: return 'Three-Level Wing Scorer'
        if elite_scorer: return 'Elite Scorer'
        if ftr_pct >= 70 and threepar_pct <= 45: return 'Slasher'
        if threepar_pct >= 75: return 'Spot-Up Shooter'
        if usg_pct >= 50: return 'Three-Level Wing Scorer' if (tall and ppg>=9) else 'Scorer'
        return 'Spot-Up Shooter'
    if g == 'Center':
        if ast_pct >= 75 and (ast_raw is not None and ast_raw >= AST_ABS_MIN): return 'Post Player'
        if (usg_raw is not None and usg_raw >= 16) and ppg >= 5: return 'Post Player'
        if threepar_pct >= 70: return 'Stretch Big'
        return 'Roller'
    return 'Sin clasificar'

def role_from_row(row, pos_group, height_m=None):
    usg_pct = pctl(REF_ROLE[pos_group]['USG%'], row['USG%'])
    ast_pct = pctl(REF_ROLE[pos_group]['AST%'], row['AST%'])
    ts_pct = pctl(REF_ROLE[pos_group]['TS%'], row['TS%'])
    p3ar_pct = pctl(REF_ROLE[pos_group]['3PAr'], row['3PAr'])
    ftr_pct = pctl(REF_ROLE[pos_group]['FTr'], row['FTr'])
    return classify_role(pos_group, ast_pct, usg_pct, ts_pct, p3ar_pct, ftr_pct, row['PPG'], height_m,
                          ast_raw=row['AST%'], usg_raw=row['USG%'])

# ============================================================================
# 2) BAJAS de Valencia -- rating + ajuste por equipo de origen (todas salen de
#    Valencia, campeón, el mejor NetRtg real de la liga)
# ============================================================================
with open('fichajes_impact.json', encoding='utf-8') as f:
    fichajes = json.load(f)
valencia = fichajes['Valencia Basket']

adj_val, z_val = team_context_adj('Valencia Basket')
print(f"Ajuste equipo de origen para TODAS las bajas (salen de Valencia, NetRtg={TEAM_NETRTG['Valencia Basket']:.1f}, z={z_val}): {adj_val:+.1f} puntos\n")

bajas_out = []
for b in valencia['detalle_bajas_medibles']:
    row = lookup_player(b['jugador'])
    if row is None:
        bajas_out.append({**b, 'rating_0_100': None, 'pos_group': None})
        continue
    m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
    base = rating_from_metrics(m, row['pos_group'])
    final = None if pd.isna(base) else round(float(np.clip(base + adj_val, 1, 99)), 1)
    bajas_out.append({**b, 'rating_base': round(base,1) if not pd.isna(base) else None,
                       'team_context_adj': adj_val, 'rating_0_100': final, 'pos_group': row['pos_group']})

print("=== BAJAS de Valencia (rating v4, con ajuste por equipo de origen) ===")
for b in sorted(bajas_out, key=lambda x: -(x['rating_0_100'] or 0)):
    print(f"  -{b['jugador']:20s} pos={str(b['pos_group']):8s} base={b['rating_base']}  +ctx={b['team_context_adj']:+.1f}  "
          f"-> Rating={b['rating_0_100']}/100  -> {b['procedencia_destino']}")

# ============================================================================
# 3) ALTAS ya medidas vía ACB->ACB (Corbalán, Valtonen) -- rating + ROL + ajuste
#    por equipo de origen (peor que Valencia en ambos casos)
# ============================================================================
altas_acb_out = []
for a in valencia['detalle_altas_medibles']:
    row = lookup_player(a['jugador'])
    if row is None:
        altas_acb_out.append({**a, 'rating_0_100': None, 'pos_group': None, 'role': None})
        continue
    origin_team = row['team_last']
    adj, z = team_context_adj(origin_team)
    m = {k: row[k] for k in CORE + ['MPG'] + list(SEC.keys())}
    base = rating_from_metrics(m, row['pos_group'])
    final = None if pd.isna(base) else round(float(np.clip(base + adj, 1, 99)), 1)
    role = role_from_row(row, row['pos_group']) if row['pos_group'] in REF_ROLE else 'Sin clasificar'
    altas_acb_out.append({**a, 'rating_base': round(base,1) if not pd.isna(base) else None,
                           'origin_team': origin_team, 'origin_netrtg': round(TEAM_NETRTG.get(origin_team, float('nan')),1),
                           'origin_z': z, 'team_context_adj': adj, 'rating_0_100': final,
                           'pos_group': row['pos_group'], 'role_en_origen': role})

print("\n=== ALTAS ya medidas ACB->ACB (rating v4 + rol) ===")
for a in sorted(altas_acb_out, key=lambda x: -(x['rating_0_100'] or 0)):
    print(f"  +{a['jugador']:20s} pos={str(a['pos_group']):8s} origen={a['origin_team']} (NetRtg={a['origin_netrtg']}, z={a['origin_z']})  "
          f"base={a['rating_base']}  ctx={a['team_context_adj']:+.1f}  -> Rating={a['rating_0_100']}/100   rol en origen={a['role_en_origen']}")

# ============================================================================
# 4) ALTAS del fichero nuevo (sin cambios respecto a v3 -- sin dato de fuerza
#    del club de origen fuera de ACB, solo nivel de liga)
# ============================================================================
mk = pd.read_csv('/root/.claude/uploads/1651dd89-f352-5de2-b8ff-2dc2d4c4ca2b/92425b6a-Fichajes_-_ACB_-_Hoja_1.csv')

def season_rows(df_player):
    out = []
    for season, sub in df_player.groupby('Season', sort=False):
        agg = sub[sub['Team'] == 'All Teams']
        if len(agg) == 1:
            out.append(agg.iloc[0])
        elif len(sub) == 1:
            out.append(sub.iloc[0])
        else:
            out.append(sub.sort_values('GP', ascending=False).iloc[0])
    return out

def row_metrics(r):
    return {
        'USG%': r['USG%'], 'AST%': r['AST%'], 'PPG': r['PTS'], 'APG': r['AST'], 'MPG': r['MIN'],
        'eFG%': r['eFG%']/10 if not pd.isna(r['eFG%']) else np.nan,
        'TRB%': r['TRB%'], 'BPG': r['BLK'],
        'FG%': r['FG%']/10 if not pd.isna(r['FG%']) else np.nan,
        '3P%': r['3P%']/10 if not pd.isna(r['3P%']) else np.nan,
        'TOV%': r['TOV%'],
    }

LEVEL_SHIFT_PTS = {'Higher': +8, 'Same': 0, 'Lower level': -12, 'Much lower': -20}
CONTEXT_MULT = {'Similar': 1.0, 'Slower': 0.4, 'Other context': 0.4}
CORRUPT_ROW_FIX = {
    ('Lucas Marí', '2024-25 *', 'All Teams'): ('2024-25 *', "CB L'Horta Godella"),
    ('Lucas Marí', '2025-26', 'Vermont'): None,
    ('Mario Saint-Supery', '2024-25 *', 'All Teams'): ('2024-25 *', 'BAXI Manresa'),
    ('Nikola Mirotic', '2024-25 *', 'All Teams'): ('2024-25 *', 'AX Armani Exchange Milan'),
    ('Mario Saint-Supery', '2025-26', 'Gonzaga'): None,
}
POS_ASSUMED = {
    'TJ Shorts': 'Guard', 'Armoni Brooks': 'Guard', 'Mo Gueye': 'Center', 'Lucas Marí': 'Forward',
    'Nikola Mirotic': 'Forward', 'Dylan Osetkowski': 'Forward', 'Mario Saint-Supery': 'Guard',
}

players_out = []
for player, sub in mk.groupby('Player', sort=False):
    sub = sub.copy()
    rows = season_rows(sub)
    rows = sorted(rows, key=lambda r: str(r['Season']), reverse=True)[:2]
    pos_group = POS_ASSUMED.get(player)

    detail = []
    for r in rows:
        key = (player, r['Season'], r['Team'])
        if key in CORRUPT_ROW_FIX:
            fix = CORRUPT_ROW_FIX[key]
            if fix is None:
                continue
            season_ov, team_ov = fix
            r = mk[(mk['Player']==player) & (mk['Season']==season_ov) & (mk['Team']==team_ov)].iloc[0]
        m = row_metrics(r)
        base = rating_from_metrics(m, pos_group)
        if pd.isna(base):
            continue
        level, context = r['Level'], r['Context']
        adj = base + LEVEL_SHIFT_PTS.get(level, 0)
        w = r['GP'] * CONTEXT_MULT.get(context, 0.4)
        detail.append({'season': r['Season'], 'team': r['Team'], 'league': r['League'], 'gp': int(r['GP']),
                        'level': level, 'context': context, 'blend_weight': round(w,1),
                        'rating_bruto': round(base,1), 'rating_ajustado': round(adj,1)})

    if not detail:
        players_out.append({'player': player, 'rating_0_100': None, 'pos_group': pos_group, 'temporadas': []})
        continue
    wsum = sum(d['blend_weight'] for d in detail)
    rating = sum(d['blend_weight']*d['rating_ajustado'] for d in detail) / wsum
    rating = round(float(np.clip(rating, 1, 99)), 1)
    players_out.append({'player': player, 'rating_0_100': rating, 'pos_group': pos_group, 'temporadas': detail})

print("\n=== ALTAS nuevas (sin cambios vs v3) ===")
for p in sorted(players_out, key=lambda x: -(x['rating_0_100'] or 0)):
    print(f"  {p['player']:22s} ({p['pos_group']}): Rating = {p['rating_0_100']}/100")

# ============================================================================
# 5) resumen sumado y restado
# ============================================================================
altas_all = [{'player': p['player'], 'rating': p['rating_0_100']} for p in players_out if p['rating_0_100'] is not None] + \
            [{'player': a['jugador'], 'rating': a['rating_0_100']} for a in altas_acb_out if a['rating_0_100'] is not None]
bajas_all = [{'player': b['jugador'], 'rating': b['rating_0_100']} for b in bajas_out if b['rating_0_100'] is not None]

sum_altas = sum(x['rating'] for x in altas_all)
sum_bajas = sum(x['rating'] for x in bajas_all)
print(f"\n=== RESUMEN (v4) ===")
print(f"Altas medibles: n={len(altas_all)}  suma={sum_altas:.1f}  media={sum_altas/len(altas_all):.1f}")
print(f"Bajas medibles: n={len(bajas_all)}  suma={sum_bajas:.1f}  media={sum_bajas/len(bajas_all):.1f}")
print(f"Balance neto (suma altas - suma bajas): {sum_altas - sum_bajas:+.1f}")

with open('valencia_player_ratings_v4.json', 'w', encoding='utf-8') as f:
    def _default(o):
        return o.item() if hasattr(o,'item') else str(o)
    json.dump({'altas_nuevas': players_out, 'bajas': bajas_out, 'altas_ya_medidas_acb': altas_acb_out,
               'resumen': {'sum_altas': sum_altas, 'sum_bajas': sum_bajas, 'balance': sum_altas-sum_bajas}},
              f, ensure_ascii=False, indent=1, default=_default)

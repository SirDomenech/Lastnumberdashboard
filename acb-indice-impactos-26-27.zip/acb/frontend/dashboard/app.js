document.getElementById('genDate').textContent = new Date().toLocaleDateString('es-ES',{year:'numeric',month:'long',day:'numeric'});

// ---------- tabs ----------
document.querySelectorAll('.tab-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('.tab-btn').forEach(b=>{b.classList.remove('active'); b.setAttribute('aria-selected','false');});
    document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
    btn.classList.add('active'); btn.setAttribute('aria-selected','true');
    document.getElementById('panel-'+btn.dataset.tab).classList.add('active');
  });
});

// ---------- helpers ----------
const FAM = {
  'Primary Ball Handler':'play','Floor General':'play','Secondary Ball Handler':'play',
  'Elite Scorer':'score','Scorer':'score',
  'Spot-Up Shooter':'wing','Slasher':'wing','Three-Level Wing Scorer':'wing','Versatile':'wing',
  'Post Player':'big','Stretch Big':'big','Roller':'big',
};
function famOf(role){ return FAM[role] || 'wing'; }
// Arquetipos en español (mapeo confirmado por Miguel). Las claves internas
// (role) siguen en ingles -- se usan para logica/filtrado/colores (FAM);
// esto solo traduce lo que se MUESTRA en pantalla. 'Versatile' es la unica
// categoria nueva que Miguel introdujo al corregir arquetipos (03/10/2026).
const ROLE_ES = {
  'Floor General':'Floor General', 'Primary Ball Handler':'Manejador principal',
  'Secondary Ball Handler':'Manejador secundario', 'Post Player':'Jugador de poste',
  'Roller':'Finalizador', 'Three-Level Wing Scorer':'Alero anotador completo',
  'Spot-Up Shooter':'Lanzador exterior', 'Scorer':'Anotador', 'Elite Scorer':'Anotador de élite',
  'Stretch Big':'Interior abierto', 'Slasher':'Penetrador', 'Versatile':'Jugador versátil',
};
function roleEs(role){ return ROLE_ES[role] || role; }
// Posicion (pos_group: Guard/Forward/Center, en ingles en los datos) --
// pedido de Miguel (03/10/2026): dejar "Guard"/"Forward"/"Center" tal cual
// vienen del dato, sin traducir al español, tanto en el filtro "Posición"
// como en la linea de meta de cada jugador. Se mantiene POS_ES/posEs() como
// unico punto de paso (identidad ahora) para no tocar el resto del código
// que ya lo usa. Orden de baloncesto (base, alero, pivot), no alfabetico,
// tanto para POS_ORDER como para el <select>.
const POS_ES = {'Guard':'Guard', 'Forward':'Forward', 'Center':'Center'};
const POS_ORDER = ['Guard', 'Forward', 'Center'];
function posEs(pos){ return pos ? (POS_ES[pos] || pos) : ''; }
function roleChip(role){
  const f = famOf(role);
  return `<span class="role-chip" style="background:var(--fam-${f}-soft); color:var(--fam-${f})">${roleEs(role)||'Sin clasificar'}</span>`;
}
function statusLabel(s){
  return {returning:'Se queda', alta_acb:'Alta ACB', alta_extranjero:'Alta fuera ACB', baja:'Baja'}[s] || s;
}
const RADAR_AXES = [
  {key:'anotacion', short:'Anotación', label:'Anotación'},
  {key:'creacion', short:'Creación', label:'Creación de Juego'},
  {key:'cuidado_balon', short:'Cuidado balón', label:'Cuidado del Balón'},
  {key:'defensa', short:'Defensa', label:'Defensa'},
  {key:'rebote', short:'Rebote', label:'Rebote'},
  {key:'impacto', short:'Impacto', label:'Impacto'},
];
// Ejes del rating DE EQUIPO (pedido explicito de Miguel, 24/09/2026) --
// distintos de los de jugador: sustituye 'Impacto' por 'Consistencia'
// (fiabilidad de la plantilla 26/27 -- ver fiabilidad_jugador en el pipeline).
const TEAM_RADAR_AXES = [
  {key:'anotacion', short:'Anotación', label:'Anotación'},
  {key:'cuidado_balon', short:'Cuidado balón', label:'Cuidado del Balón'},
  {key:'rebote', short:'Rebote', label:'Rebote'},
  {key:'defensa', short:'Defensa', label:'Defensa'},
  {key:'consistencia', short:'Consistencia', label:'Consistencia'},
  {key:'creacion', short:'Creación', label:'Creación de Juego'},
];
// 'compare' (opcional, {attrs, mainLabel, label}) superpone un segundo
// poligono en el MISMO hexágono -- pedido de Miguel (03/10/2026): "meter
// un comparador de jugadores cuando se despliega el ver atributos". Solo
// lo usa atributosBlock() para jugadores; el radar de equipo
// (teamResumenBlock) nunca pasa este argumento y su salida no cambia ni
// un caracter respecto a antes.
function hexRadarSVG(attrs, axesList, compare){
  const AX = axesList || RADAR_AXES;
  if(!attrs) return '<div class="note">Sin datos suficientes para el mapa de atributos.</div>';
  const cx=160, cy=118, maxR=62, n=AX.length;
  const pt = (r, i) => {
    const rad = (Math.PI/180) * (i * (360/n));
    return [cx + r*Math.sin(rad), cy - r*Math.cos(rad)];
  };
  const gridSVG = [0.25,0.5,0.75,1.0].map(frac=>{
    const pts = AX.map((_,i)=>pt(maxR*frac, i).join(',')).join(' ');
    return `<polygon points="${pts}" fill="none" stroke="var(--border)" stroke-width="1"/>`;
  }).join('');
  const axisSVG = AX.map((_,i)=>{
    const [x,y] = pt(maxR, i);
    return `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="var(--border)" stroke-width="1"/>`;
  }).join('');
  const missing = [];
  const dataPts = AX.map((ax,i)=>{
    let v = attrs[ax.key];
    if(v==null){ missing.push(ax.label); v = 0; }
    return pt(maxR*(v/100), i);
  });
  const dataPolygon = dataPts.map(p=>p.join(',')).join(' ');
  const dots = AX.map((ax,i)=>{
    const v = attrs[ax.key];
    const [x,y] = dataPts[i];
    return v==null
      ? `<circle cx="${x}" cy="${y}" r="3" fill="var(--surface)" stroke="var(--muted)" stroke-width="1.5" stroke-dasharray="2,1.5"/>`
      : `<circle cx="${x}" cy="${y}" r="3" fill="var(--accent)"/>`;
  }).join('');
  // Poligono de comparacion: mismo trazado que el principal pero en --cmp
  // (turquesa) y con trazo discontinuo, para que se distinga del jugador
  // principal (--accent, trazo continuo) incluso donde se superponen.
  let comparePolygonSVG = '', compareDotsSVG = '';
  const cMissing = [];
  if(compare && compare.attrs){
    const cPts = AX.map((ax,i)=>{
      let v = compare.attrs[ax.key];
      if(v==null){ cMissing.push(ax.label); v = 0; }
      return pt(maxR*(v/100), i);
    });
    const cPolygon = cPts.map(p=>p.join(',')).join(' ');
    comparePolygonSVG = `<polygon points="${cPolygon}" fill="var(--cmp)" fill-opacity="0.2" stroke="var(--cmp)" stroke-width="1.6" stroke-dasharray="4,2"/>`;
    compareDotsSVG = AX.map((ax,i)=>{
      const v = compare.attrs[ax.key];
      const [x,y] = cPts[i];
      return v==null
        ? `<circle cx="${x}" cy="${y}" r="3" fill="var(--surface)" stroke="var(--cmp)" stroke-width="1.5" stroke-dasharray="2,1.5"/>`
        : `<circle cx="${x}" cy="${y}" r="3" fill="var(--cmp)"/>`;
    }).join('');
  }
  const labels = AX.map((ax,i)=>{
    const [x,y] = pt(maxR+14, i);
    const anchor = Math.abs(x-cx) < 4 ? 'middle' : (x > cx ? 'start' : 'end');
    return `<text x="${x}" y="${y}" text-anchor="${anchor}" dominant-baseline="middle" font-size="10" fill="var(--ink-2)">${ax.short}</text>`;
  }).join('');
  const legend = AX.map(ax=>{
    const v = attrs[ax.key];
    const mainTxt = v==null?'s/d':Math.round(v);
    if(compare && compare.attrs){
      const cv = compare.attrs[ax.key];
      const cmpTxt = cv==null?'s/d':Math.round(cv);
      return `<span style="margin-right:14px;">${ax.label}: <strong style="color:var(--accent)">${mainTxt}</strong><span style="color:var(--muted)"> / </span><strong style="color:var(--cmp)">${cmpTxt}</strong></span>`;
    }
    return `<span style="margin-right:10px;">${ax.label}: <strong>${mainTxt}</strong></span>`;
  }).join('');
  let missNote = '';
  if(!compare || !compare.attrs){
    missNote = missing.length ? `<div class="note" style="text-align:left">Sin dato: ${missing.join(', ')} -- no hay +/- real de boxscore ACB 25/26 para este jugador (viene de fuera de la ACB).</div>` : '';
  } else {
    const parts = [];
    if(missing.length) parts.push(`${compare.mainLabel||'Jugador principal'}: ${missing.join(', ')}`);
    if(cMissing.length) parts.push(`${compare.label||'Comparado'}: ${cMissing.join(', ')}`);
    missNote = parts.length ? `<div class="note" style="text-align:left">Sin dato -- ${parts.join(' · ')} -- no hay +/- real de boxscore ACB 25/26 para estos jugadores (vienen de fuera de la ACB).</div>` : '';
  }
  const namesLegend = (compare && compare.attrs) ? `<div class="radar-names-legend">
    <span class="radar-name-item"><i class="dot" style="background:var(--accent)"></i>${compare.mainLabel||'Jugador'}</span>
    <span class="radar-name-item"><i class="dot" style="background:var(--cmp)"></i>${compare.label||'Comparado'}</span>
  </div>` : '';
  return `<div class="radar-wrap">
    ${namesLegend}
    <svg viewBox="0 0 320 236" width="100%" style="max-width:360px; display:block; margin:6px auto;">
      ${gridSVG}${axisSVG}
      <polygon points="${dataPolygon}" fill="var(--accent)" fill-opacity="0.28" stroke="var(--accent)" stroke-width="1.6"/>
      ${comparePolygonSVG}
      ${dots}${compareDotsSVG}${labels}
    </svg>
    <div class="note" style="text-align:left">${legend}</div>
    ${missNote}
  </div>`;
}
// Comparador de jugadores dentro de "Ver atributos" (pedido de Miguel,
// 03/10/2026). El <select> arranca vacío (solo "Ninguno") y sus opciones
// se rellenan al vuelo la primera vez que se abre ESTE desplegable en
// concreto -- ver el listener de 'toggle' más abajo -- para no generar de
// entrada un <option> por cada uno de los ~250 jugadores del roster
// completo en cada una de las tarjetas visibles.
// La comparativa solo tiene sentido entre jugadores del mismo puesto
// (pedido explicito de Miguel: "la comparativa que sea solo efectiva por
// posicion") -- comparar un Pívot con un Base en los mismos 6 ejes no dice
// nada util. El <select> por eso solo se rellena (ver
// attrsCompareOptionsHTML) con jugadores de igual pos_group, y la etiqueta
// lo deja explícito para que no parezca una limitación silenciosa.
function atributosBlock(p){
  const pk = playerKey(p);
  const posLbl = posEs(p.pos_group);
  return `<details class="attrs-toggle">
    <summary>Ver atributos</summary>
    <div class="attrs-compare-row">
      <label class="attrs-compare-lbl">Comparar con${posLbl ? ` (mismo puesto: ${posLbl})` : ''}:
        <select class="attrs-compare-select" data-player-key="${pk}"${p.pos_group ? '' : ' disabled title="Sin puesto asignado -- no se puede comparar de forma fiable"'}>
          <option value="">Ninguno</option>
        </select>
      </label>
    </div>
    <div class="attrs-radar-wrap">${hexRadarSVG(p.atributos)}</div>
  </details>`;
}
function teamLogo(logoKey){
  const src = logoKey ? DATA.logos[logoKey] : null;
  return src ? `<img class="team-logo" src="${src}" alt="${logoKey}" title="${logoKey}">` : `<span class="team-logo placeholder"></span>`;
}
function ratingColor(v){
  if(v==null) return 'var(--muted)';
  return 'var(--accent)';
}
function fmt(v, d=1){ return (v==null || isNaN(v)) ? '—' : Number(v).toFixed(d); }

function isCurrentSeason(seasonStr){
  const m = String(seasonStr).match(/^(\d{4})/);
  return !!m && m[1] === '2025';
}
// Competiciones europeas/copa que disputo cada equipo ACB en 25/26 --
// dato dado a mano por Miguel (25/09/2026), no esta en el box score real.
// Claves con las dos variantes de nombre de equipo que aparecen en
// 'seasons' (convencion antigua/nueva -- el dataset mezcla ambas).
const TEAM_COMPETITIONS_25_26 = {
  'Real Madrid': ['EuroLeague','Copa ACB','Supercopa'],
  'Valencia Basket': ['EuroLeague','Copa ACB','Supercopa'],
  'Barça': ['EuroLeague','Copa ACB'],
  'Kosner Baskonia': ['EuroLeague','Copa ACB'], 'Baskonia': ['EuroLeague','Copa ACB'],
  'Unicaja': ['Champions League','Copa ACB','Supercopa'],
  'La Laguna Tenerife': ['Champions League','Copa ACB','Supercopa'],
  'Asisa Joventut': ['Champions League','Copa ACB'], 'Joventut Badalona': ['Champions League','Copa ACB'],
  'UCAM Murcia': ['Previa Champions League','Europe Cup','Copa ACB'],
  'Kids&Us Manresa': ['Eurocup'], 'BAXI Manresa': ['Eurocup'],
  'Surne Bilbao': ['Europe Cup'], 'Surne Bilbao Basket': ['Europe Cup'],
  'Dreamland Gran Canaria': ['Champions League'],
};
const LEAGUE_DISPLAY = { 'Euroleague':'EuroLeague', 'EuroLeague':'EuroLeague', 'Eurocup':'Eurocup', 'EuroCup':'Eurocup' };
function leagueDisplay(l){ return LEAGUE_DISPLAY[l] || l; }

// Agrupa las filas de temporada por (temporada, equipo) -- pedido explicito
// de Miguel (25/09/2026): antes cada competicion salia en su propia linea
// ("2025-26 * · Paris Basketball · Jeep Elite" / "... · Euroleague" / ...);
// ahora se junta en una sola linea por temporada+equipo, competiciones
// separadas por comas y "y" antes de la ultima. Para filas ACB de la
// 25/26 añade ademas las competiciones de TEAM_COMPETITIONS_25_26 -- ej.
// Edy Tavares (Real Madrid, ACB) pasa a mostrar ACB + EuroLeague + Copa
// ACB + Supercopa en vez de solo ACB.
function groupedSeasonLines(seasons){
  const groups = []; const idx = {};
  seasons.forEach(s=>{
    const seasonLabel = String(s.season).replace(/\s*\*\s*$/, '').trim();
    const key = seasonLabel + '||' + s.team;
    if(!(key in idx)){ idx[key] = groups.length; groups.push({season: seasonLabel, team: s.team, leagues: []}); }
    const g = groups[idx[key]];
    const disp = leagueDisplay(s.league);
    if(disp && disp !== '-' && !g.leagues.includes(disp)) g.leagues.push(disp);
    if(s.league === 'ACB' && seasonLabel === '2025-26'){
      (TEAM_COMPETITIONS_25_26[s.team] || []).forEach(extra=>{
        if(!g.leagues.includes(extra)) g.leagues.push(extra);
      });
    }
  });
  return groups.map(g=>{
    const leaguesTxt = g.leagues.length > 1
      ? g.leagues.slice(0, -1).join(', ') + ' y ' + g.leagues[g.leagues.length-1]
      : (g.leagues[0] || '');
    return `<div class="season-line"><b>${g.season}</b>, ${g.team}${leaguesTxt ? ' - '+leaguesTxt : ''}</div>`;
  }).join('');
}

// Chips de etiquetas especiales (columna "Etiqueta especial" del csv de
// Miguel) -- pedido explicito de Miguel (24/09/2026): "necesito que lo
// tengas en cuenta tanto para hacerlo visible...". Antes se guardaban en
// el JSON (etiquetas_especiales) pero nunca se pintaban en el dashboard --
// ahora se ven siempre en la ficha del jugador, tengan o no efecto
// numerico (etiquetas_efecto, calculado en el pipeline, dice cual).
function tagChips(tags){
  if(!tags || !tags.length) return '';
  return tags.map(t=>`<span class="tag-chip">${t}</span>`).join('');
}
function playerCard(p, idx, statusOverride){
  const status = statusOverride || p.status;
  const lowSample = p.low_sample ? '<span class="low-sample" title="Muestra insuficiente esta temporada">†</span>' : '';
  const injury = p.lesionado ? `<span class="injury-mark" title="${p.lesionado}">*</span>` : '';
  const rating = p.rating_0_100;
  const seasonsAll = p.seasons || [];
  const seasonsCur = seasonsAll.filter(s=>isCurrentSeason(s.season));
  const seasons = seasonsCur.length ? seasonsCur : null;
  const seasonsFallback = !seasonsCur.length && seasonsAll.length;
  const injuryNote = p.lesionado ? `<div class="note"><strong>Lesión:</strong> ${p.lesionado}</div>` : '';
  const expectativaNote = p.expectativa ? `<div class="note">${p.expectativa}</div>` : '';
  const etiquetaNote = (p.etiquetas_especiales && p.etiquetas_especiales.length)
    ? `<div class="note"><strong>Etiquetas especiales:</strong> ${p.etiquetas_especiales.join(', ')}${(p.etiquetas_efecto && p.etiquetas_efecto.length) ? '<br>' + p.etiquetas_efecto.join('<br>') : ''}</div>`
    : '';
  // Bloque "Ajustes sobre el modelo" retirado a peticion explicita de
  // Miguel (25/09/2026) -- los datos (role_model_note etc.) se conservan
  // en el JSON, simplemente ya no se pintan en la ficha del jugador.
  return `<details class="pcard">
    <summary>
      <div class="rank-logo">${teamLogo(p.logo_key)}<div class="rank-num">${idx}</div></div>
      <div class="pname-col">
        <div class="pname">${p.player}${lowSample}${injury}<span class="chevron">▸</span></div>
        <div class="pmeta">${posEs(p.pos_group)} · ${roleChip(p.role)}${p.referencia_defensiva?` · <span class="def-ref-chip">Referencia defensiva</span>`:''}${p.edad?` · <span class="role-chip" style="background:var(--border);color:inherit">${p.edad}a</span>`:''}${tagChips(p.etiquetas_especiales)}</div>
      </div>
      <div class="rating-col">
        <div class="rating-bar-track"><div class="rating-bar-fill" style="width:${rating||0}%; background:${ratingColor(rating)}"></div></div>
        <div class="rating-num">${rating!=null?Math.round(rating):'—'}</div>
      </div>
    </summary>
    <div class="pcard-body">
      ${injuryNote}
      ${expectativaNote}
      ${etiquetaNote}
      ${seasons ? `<div class="seasons-simple">${groupedSeasonLines(seasons)}</div>` : seasonsFallback
        ? '<div class="note">Sin datos de la 25/26 disponibles (la única temporada que tenemos para este jugador quedó excluida -- ver nota arriba).</div>'
        : '<div class="note">Sin datos de temporada disponibles.</div>'}
      ${atributosBlock(p)}
    </div>
  </details>`;
}

// ---------- render roster (tab 1) ----------
// Combina el roster de TODOS los equipos con modelo completo (antes solo
// Valencia) -- pedido por Miguel: "una estructura que me permita dividir por
// equipo", con filtros de Equipo / Rol / Solo fichajes. La seccion "Jugadores
// que se van" se quito del todo (pedido explicito de Miguel: "ya aparecera la
// baja mas sensible por equipo" -- esa info ya vive en la pestaña "Ranking de
// equipos", resumen.baja_mas_sensible, sin duplicarla aqui).
const TEAM_NAMES = Object.keys(DATA.equipos);
const ALL_ROSTER = TEAM_NAMES.flatMap(t => DATA.equipos[t].roster_26_27);
// No hay un id de jugador en los datos -- team+player es la clave estable
// que usa tanto atributosBlock() como el comparador para identificar a
// cada jugador (no hay dos jugadores con el mismo nombre en el mismo
// equipo).
function playerKey(p){ return `${p.team}||${p.player}`; }
const PLAYERS_BY_KEY = {};
ALL_ROSTER.forEach(p=>{ PLAYERS_BY_KEY[playerKey(p)] = p; });

let currentSort = 'rating';
let filterTeam = 'all';
let filterRole = 'all';
let filterPos = 'all';
let soloFichajes = false;

function sortPlayers(list){
  const arr = [...list];
  if(currentSort==='rating') arr.sort((a,b)=>(b.rating_0_100||0)-(a.rating_0_100||0));
  else if(currentSort==='role') arr.sort((a,b)=> (a.role||'').localeCompare(b.role||'') || (b.rating_0_100||0)-(a.rating_0_100||0));
  else if(currentSort==='alpha') arr.sort((a,b)=>a.player.localeCompare(b.player));
  return arr;
}
function passesFilter(p){
  return (filterTeam==='all' || p.team===filterTeam) && (filterRole==='all' || p.role===filterRole) && (filterPos==='all' || p.pos_group===filterPos);
}

// ---- filtro Equipo (dropdown, pedido explicito de Miguel via comentario en
//      el artifact: "haz un dropdown, no lo pongas por equipo" -- antes eran
//      chips con escudo, uno por equipo) ----
const teamFilterSel = document.getElementById('teamFilter');
teamFilterSel.innerHTML = `<option value="all">Todos los equipos</option>` +
  TEAM_NAMES.map(t => `<option value="${t}">${t}</option>`).join('');
teamFilterSel.addEventListener('change', ()=>{
  filterTeam = teamFilterSel.value; renderRoster();
});

// ---- filtro Posición (pedido de Miguel, 03/10/2026: "Añade un filtro de
//      añadir por posiciones en jugadores"). Mismo patron que Equipo/Rol --
//      dropdown, opciones dinamicas segun lo que haya en el roster, pero en
//      orden de baloncesto (POS_ORDER) en vez de alfabetico. Los 2 jugadores
//      sin pos_group nunca pasan un filtro de posicion concreto (se ven solo
//      con "Todas las posiciones"), igual que ya pasaba con rol/equipo. ----
const posFilterSel = document.getElementById('posFilter');
const POS_PRESENT = POS_ORDER.filter(pos => ALL_ROSTER.some(p => p.pos_group === pos));
posFilterSel.innerHTML = `<option value="all">Todas las posiciones</option>` + POS_PRESENT.map(pos=>`<option value="${pos}">${posEs(pos)}</option>`).join('');
posFilterSel.addEventListener('change', ()=>{ filterPos = posFilterSel.value; renderRoster(); });

// ---- filtro Rol (select, opciones dinamicas segun roles presentes) ----
const roleFilterEl = document.getElementById('roleFilter');
const ROLES_PRESENT = Array.from(new Set(ALL_ROSTER.map(p=>p.role).filter(Boolean))).sort();
roleFilterEl.innerHTML = `<option value="all">Todos los roles</option>` + ROLES_PRESENT.map(r=>`<option value="${r}">${roleEs(r)}</option>`).join('');
roleFilterEl.addEventListener('change', ()=>{ filterRole = roleFilterEl.value; renderRoster(); });

// ---- toggle Solo fichajes (oculta 'se quedan' y la seccion de bajas -- una
//      baja nunca es un fichaje/alta) ----
document.getElementById('soloFichajes').addEventListener('change', (e)=>{
  soloFichajes = e.target.checked; renderRoster();
});

// ---- panel "qué se va / qué llega" (mix de atributos), pedido por Miguel:
//      comparar lo que aportan los que se van frente a las virtudes de los
//      que llegan, eje por eje. Solo tiene sentido con UN equipo seleccionado. ----
const AXIS_LABELS = {anotacion:'Anotación', creacion:'Creación', cuidado_balon:'Cuidado balón', defensa:'Defensa', rebote:'Rebote', impacto:'Impacto'};
function renderMixPanel(){
  const mixEl = document.getElementById('mixPanel');
  const mix = filterTeam !== 'all' ? DATA.equipos[filterTeam]?.attribute_mix : null;
  if(!mix){ mixEl.style.display = 'none'; return; }
  mixEl.style.display = '';
  const axes = Object.keys(AXIS_LABELS).map(ax=>{
    const d = mix[ax];
    const van = d.se_van, lleg = d.llegan;
    const deltaCls = d.delta == null ? '' : (d.delta >= 0 ? 'up' : 'down');
    const deltaTxt = d.delta == null ? '—' : (d.delta>=0?'+':'')+fmt(d.delta,1);
    return `<div class="mix-axis">
      <div class="mix-axis-head"><span class="mix-label">${AXIS_LABELS[ax]}</span><span class="mix-delta ${deltaCls}">Δ ${deltaTxt}</span></div>
      <div class="mix-bar-line"><span class="mix-tag">Se van</span><div class="mix-bar"><div class="mix-fill-van" style="width:${van||0}%"></div></div><span class="mix-val">${van==null?'—':fmt(van,1)}</span></div>
      <div class="mix-bar-line"><span class="mix-tag">Llegan</span><div class="mix-bar"><div class="mix-fill-llegan" style="width:${lleg||0}%"></div></div><span class="mix-val">${lleg==null?'—':fmt(lleg,1)}</span></div>
    </div>`;
  }).join('');
  mixEl.innerHTML = `<div class="mix-title">Qué se va y qué llega — ${filterTeam}</div>
    <div class="mix-sub">Media del atributo (0–100) entre las bajas medibles frente a las altas medibles de este equipo. El eje "Impacto" tiene muestra pequeña en las altas -- solo las altas ACB→ACB tienen +/- real de boxscore, las de fuera de la ACB no.</div>
    <div class="mix-grid">${axes}</div>`;
}

function renderRoster(){
  renderMixPanel();
  let roster = ALL_ROSTER.filter(passesFilter);
  if(soloFichajes) roster = roster.filter(p => p.status !== 'returning');
  roster = sortPlayers(roster);
  document.getElementById('rosterList').innerHTML = roster.length
    ? roster.map((p,i)=>playerCard(p,i+1)).join('')
    : '<div class="note" style="padding:12px 0;">Sin jugadores para este filtro.</div>';
  document.getElementById('nRoster').textContent = roster.length;
  document.getElementById('rosterCount').textContent = roster.length + ' jugadores' + (soloFichajes ? ' (solo fichajes)' : ' proyectados');
}
document.querySelectorAll('#sortGrp .chip').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('#sortGrp .chip').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active'); currentSort = btn.dataset.sort; renderRoster();
  });
});
renderRoster();

// ---------- comparador de jugadores dentro de "Ver atributos" ----------
// Pedido de Miguel (03/10/2026): "meter una de comparador de jugadores
// cuando se despliega el ver atributos". A diferencia del comparador de
// equipos (dos paneles lado a lado en un pop-up), aquí los dos jugadores
// se superponen en el MISMO hexágono de 6 ejes -- es lo que de verdad
// permite comparar perfil a perfil de un vistazo, y no necesita un
// pop-up aparte: vive dentro del propio desplegable "Ver atributos".
// Restringido a jugadores del MISMO pos_group (pedido de Miguel, mismo
// dia: "la comparativa que sea solo efectiva por posicion") -- comparar
// entre puestos distintos en los mismos 6 ejes no es una comparacion util.
function attrsCompareOptionsHTML(excludeKey, posGroup){
  const byTeam = {};
  ALL_ROSTER.forEach(p=>{
    const k = playerKey(p);
    if(k === excludeKey) return;
    if(p.pos_group !== posGroup) return;
    (byTeam[p.team] = byTeam[p.team] || []).push(p);
  });
  return Object.keys(byTeam).sort((a,b)=>a.localeCompare(b,'es')).map(team=>{
    const opts = byTeam[team].slice()
      .sort((a,b)=>a.player.localeCompare(b.player,'es'))
      .map(p=>`<option value="${playerKey(p)}">${p.player}</option>`).join('');
    return `<optgroup label="${team}">${opts}</optgroup>`;
  }).join('');
}
const rosterListEl = document.getElementById('rosterList');
// Las opciones del <select> se rellenan la primera vez que se abre CADA
// "Ver atributos" en concreto, no de entrada para los ~250 jugadores del
// roster completo (serían decenas de miles de <option> sin usar casi
// nunca). El evento 'toggle' de <details> no burbujea, así que la
// delegación en el contenedor se hace en fase de captura.
rosterListEl.addEventListener('toggle', e=>{
  const det = e.target;
  if(!det.classList || !det.classList.contains('attrs-toggle') || !det.open) return;
  const select = det.querySelector('.attrs-compare-select');
  if(select && !select.dataset.populated){
    const main = PLAYERS_BY_KEY[select.dataset.playerKey];
    if(main && main.pos_group){
      select.insertAdjacentHTML('beforeend', attrsCompareOptionsHTML(select.dataset.playerKey, main.pos_group));
    }
    select.dataset.populated = '1';
  }
}, true);
rosterListEl.addEventListener('change', e=>{
  const select = e.target.closest('.attrs-compare-select');
  if(!select) return;
  const main = PLAYERS_BY_KEY[select.dataset.playerKey];
  if(!main) return;
  const wrap = select.closest('.attrs-toggle').querySelector('.attrs-radar-wrap');
  const cmp = select.value ? PLAYERS_BY_KEY[select.value] : null;
  wrap.innerHTML = hexRadarSVG(main.atributos, null, cmp ? {attrs: cmp.atributos, mainLabel: main.player, label: cmp.player} : null);
});

// ---------- render teams (tab 2) ----------
// Indice equipo -> objeto, usado por el pop-up de ficha (necesita poder
// buscar cualquier equipo por clave, no solo los que esten visibles en
// una fila concreta) y por el selector "Comparar con".
const TEAMS_BY_KEY = {};
DATA.teams.forEach(t=>{ TEAMS_BY_KEY[t.team] = t; });
// Equipo nº1 proyectado (mismo criterio que antes se pasaba via opts.rank1
// desde renderTeams: es siempre el primero del Top 4 tras ordenar por
// posicion_proyectada_26_27). Se centraliza aqui porque ahora tambien lo
// necesita el panel de ficha del pop-up, no solo la tarjeta compacta.
function isRank1(t){
  const r = t.resumen;
  return !!(r && r.posicion_proyectada_26_27 === 1);
}
// Estrellas (0-5, medias estrellas), pedido explicito de Miguel
// (24/09/2026): "Evalua de 0 a 5 estrellas. Puedes poner media estrella en
// plan 4.5, 3.5." r.estrellas ya viene calculado del pipeline (escala
// lineal min-max de team_rating entre los 16 equipos con plantilla
// completa, suelo 0.5). Se pinta con un gradiente de texto (misma tecnica
// que una barra de progreso, pero recortando el propio glifo ★★★★★) para
// poder mostrar medias estrellas sin depender de una fuente concreta.
function starsVisual(n){
  if(n==null) return `<div class="team-rating-col"><span class="stars-visual" style="--pct:0%">★★★★★</span><div class="team-rating-lbl">sin rating</div></div>`;
  const pct = Math.max(0, Math.min(100, (n/5)*100));
  return `<div class="team-rating-col"><span class="stars-visual" style="--pct:${pct}%">★★★★★</span><div class="team-rating-lbl">${fmt(n,1)} / 5</div></div>`;
}
// V-D esperado: victorias redondeadas / (partidos - victorias). Sustituye a
// los puntos por partido en toda la pestaña de equipos -- pedido explicito
// de Miguel: "no me importan los puntos por partido. No dicen absolutamente
// nada."
function wlStr(wins, gp){
  if(wins==null || gp==null) return null;
  const w = Math.round(wins);
  return `${w}-${gp-w}`;
}
function teamVirtudesDefectosBlock(t){
  const r = t.resumen;
  if(!r || (!(r.virtudes||[]).length && !(r.defectos||[]).length)) return '';
  const item = v => `<div class="vd-item"><span class="vd-name">${v.eje}</span><span class="vd-pctl">P${Math.round(v.percentil)}</span></div>`;
  const vItems = (r.virtudes||[]).map(item).join('') || '<div class="note">—</div>';
  const dItems = (r.defectos||[]).map(item).join('') || '<div class="note">—</div>';
  return `<div class="tr-section-lbl">Virtudes y defectos</div>
    <div class="vd-grid">
      <div class="vd-col vd-good"><div class="vd-col-lbl">Virtudes</div>${vItems}</div>
      <div class="vd-col vd-bad"><div class="vd-col-lbl">Defectos</div>${dItems}</div>
    </div>
    <div class="note" style="margin-top:4px;">Percentil de cada eje frente a los 16 equipos con plantilla completa (excluye ascendidos), sobre el mismo perfil de 6 atributos del rating de equipo.</div>`;
}
// Icono de trofeo (linea, currentColor) para el titulo real de liga --
// distinto del rating del modelo, que es otra cosa (Real Madrid lidero la
// fase regular 25/26 segun el modelo, pero Valencia fue el campeon real).
const TROPHY_SVG = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4Z"/><path d="M7 5H4a2 2 0 0 0 0 4c.5 1.5 1.5 2.5 3 3M17 5h3a2 2 0 0 1 0 4c-.5 1.5-1.5 2.5-3 3"/></svg>';
function logroBadge(logro){
  if(!logro) return '';
  if(logro.startsWith('Campeón')){
    return `<div class="badge-champion">${TROPHY_SVG}${logro}</div>`;
  }
  return `<div class="delta-pill delta-up" style="margin-top:8px;">${logro}</div>`;
}
// La ficha de cada equipo ya NO se despliega dentro de su propia tarjeta
// (pedido de Miguel, 28/09/2026: "que se despliegue en Pop-up ocupando
// pantalla toda la ficha de cada equipo en vez de desplegarlo y ponerlo
// absolutamente desproporcionado" -- con 4 tarjetas por fila cada una vive
// en un carril de ~240-260px, y el contenido ancho de la ficha (compare-grid
// a 2 columnas, radar, tabla de "Ver cálculo") quedaba comprimido ahi
// mismo). Se separa en tres piezas reutilizables:
//   - teamMetaLine(t)      -> el texto "X-Y esperado (26/27)" / equivalente
//   - teamHeaderHTML(t)    -> logo+nombre, estrellas, meta -- igual en la
//                             tarjeta compacta de la lista y en la cabecera
//                             del panel de ficha del pop-up
//   - teamCard(t)          -> tarjeta compacta de la lista (sin cuerpo),
//                             con un botón "Ver ficha" al pie
//   - teamFichaBody(t)     -> el contenido ancho (compare-grid, virtudes y
//                             defectos, resumen, cálculo) -- solo se
//                             renderiza dentro del pop-up, nunca en la lista
function teamMetaLine(t){
  const rp = t.rating_pasado;
  if(t.is_promoted){
    const re = t.rating_esperado;
    const wlEsperado = re ? wlStr(re.wins_est, re.gp) : null;
    return `Recién ascendido de Primera FEB · ${wlEsperado ? wlEsperado+' esperado (26/27)' : 'Proyección 26/27 pendiente'}`;
  }
  if(t.has_full_model && t.rating_esperado){
    const re = t.rating_esperado;
    return `${wlStr(re.wins_est, re.gp)||'—'} esperado (26/27)`;
  }
  return 'Proyección 26/27 pendiente';
}
function teamHeaderHTML(t){
  const r = t.resumen;
  const playoffBadge = r && r.playoff_esperado ? '<span class="role-chip badge-playoff">Playoffs 26/27</span>' : '';
  return `<div class="tcard-head">
    <div class="tcard-namerow">
      ${teamLogo(t.logo_key)}
      <span class="tname">${t.team_sponsor||t.team}</span>
    </div>
    ${starsVisual(r ? r.estrellas : null)}
    <div class="tcard-metarow">
      <span class="tmeta">${teamMetaLine(t)}</span>
      ${playoffBadge}
    </div>
  </div>`;
}
function teamCard(t){
  const r = t.resumen;
  const rank1Attr = isRank1(t) ? ' data-rank1="1"' : '';
  return `<div class="tcard" data-valencia="${t.has_full_model?1:0}" data-playoff="${r && r.playoff_esperado?1:0}"${rank1Attr}>
    ${teamHeaderHTML(t)}
    <div class="tcard-foot">
      <button type="button" class="btn-ver-ficha" data-team-key="${t.team}">Ver ficha <span aria-hidden="true">→</span></button>
    </div>
  </div>`;
}
function teamFichaBody(t){
  const rp = t.rating_pasado;
  const r = t.resumen;
  if(t.is_promoted){
    const re = t.rating_esperado;
    const wlEsperado = re ? wlStr(re.wins_est, re.gp) : null;
    return `<div class="note" style="padding-top:10px;">${rp.nota} Sin partidos reales en la ACB 25/26 — no hay récord real ni posición del año pasado con la que comparar. La proyección 26/27 (récord y posición) sí se calcula, con el mismo modelo de calendario completo que el resto de la liga, sobre el NetRtg estimado por traducción de nivel FEB→ACB.</div>
      ${re ? `<div class="compare-grid" style="grid-template-columns:1fr;">
        <div class="compare-box">
          <div class="lbl">Esperado 26/27 (proyección)</div>
          <div class="big">${wlEsperado||'—'} <span style="font-size:13px; color:var(--muted); font-weight:600;">(${fmt(re.win_pct_est,1)}%)</span></div>
          <div class="small">${r && r.posicion_proyectada_26_27!=null?'#'+r.posicion_proyectada_26_27+' proyectado':''}</div>
        </div>
      </div>` : ''}
      ${teamVirtudesDefectosBlock(t)}
      ${teamResumenBlock(t)}
      ${teamCalculoBlock(t)}`;
  }
  if(t.has_full_model && t.rating_esperado){
    const re = t.rating_esperado;
    const wlPasado = wlStr(rp.wins_est, rp.gp);
    const wlEsperado = wlStr(re.wins_est, re.gp);
    return `<div class="compare-grid">
      <div class="compare-box">
        <div class="lbl">Año pasado (25/26)</div>
        <div class="big">${wlPasado||'—'}</div>
        <div class="small">${rp.rank_estrellas!=null?'#'+rp.rank_estrellas+' de 18 · rating':''}</div>
        ${rp.posicion_real_25_26!=null?`<div class="small">#${rp.posicion_real_25_26} de 18 · clasificación real</div>`:''}
        ${r ? logroBadge(r.logro_25_26) : ''}
      </div>
      <div class="compare-box">
        <div class="lbl">Esperado 26/27 (proyección)</div>
        <div class="big">${wlEsperado||'—'} <span style="font-size:13px; color:var(--muted); font-weight:600;">(${fmt(re.win_pct_est,1)}%)</span></div>
        <div class="small">${r && r.posicion_proyectada_26_27!=null?'#'+r.posicion_proyectada_26_27+' proyectado':''}</div>
        ${re.delta_wins!=null?`<div class="delta-pill ${re.delta_wins>=0?'delta-up':'delta-down'}">${re.delta_wins>=0?'▲':'▼'} ${re.delta_wins>=0?'+':''}${fmt(re.delta_wins,1)} victorias vs 25/26</div>`:''}
      </div>
    </div>
    ${teamVirtudesDefectosBlock(t)}
    ${teamResumenBlock(t)}
    ${teamCalculoBlock(t)}`;
  }
  const ms = t.market_signal;
  const wlPasado = wlStr(rp.wins_est, rp.gp);
  return `<div class="compare-grid">
    <div class="compare-box">
      <div class="lbl">Año pasado (25/26)</div>
      <div class="big">${wlPasado||'—'}</div>
      <div class="small">${rp.rank_estrellas!=null?'#'+rp.rank_estrellas+' de 18 · rating':''}</div>
      ${rp.posicion_real_25_26!=null?`<div class="small">#${rp.posicion_real_25_26} de 18 · clasificación real</div>`:''}
      ${r ? logroBadge(r.logro_25_26) : ''}
    </div>
    <div class="compare-box">
      <div class="lbl">Esperado 26/27</div>
      <div class="big" style="font-size:15px; color:var(--muted); font-weight:700;">Pendiente</div>
      ${ms ? `<div class="small">Señal parcial de mercado: balance GmSc medible ${fmt(ms.balance_medible_gmsc,1)} (cobertura altas ${ms.cobertura_altas_pct}%, bajas ${ms.cobertura_bajas_pct}%)</div>` : '<div class="small">Sin datos de fichajes aún</div>'}
    </div>
  </div>
  ${teamVirtudesDefectosBlock(t)}`;
}
function teamFichaPanelHTML(t){
  const r = t.resumen;
  const rank1Attr = isRank1(t) ? ' data-rank1="1"' : '';
  return `<div class="ficha-panel" data-valencia="${t.has_full_model?1:0}" data-playoff="${r && r.playoff_esperado?1:0}"${rank1Attr}>
    ${teamHeaderHTML(t)}
    <div class="tcard-body">${teamFichaBody(t)}</div>
  </div>`;
}
function teamResumenBlock(t){
  const r = t.resumen;
  if(!r) return '';
  const top3 = (r.top3||[]).map((p,i)=>`<div class="tr-player"><span class="tr-rank">${i+1}</span><span class="tr-name">${p.player}</span><span class="tr-role">${roleChip(p.role)}</span><span class="tr-rating">${Math.round(p.rating)}</span></div>`).join('');
  const fichaje = r.mejor_fichaje ? `<div class="tr-box"><div class="lbl">Mejor fichaje</div><div class="tr-box-name">${r.mejor_fichaje.player}</div><div class="small">${roleChip(r.mejor_fichaje.role)} · rating ${Math.round(r.mejor_fichaje.rating)}</div></div>` : '';
  const baja = r.baja_mas_sensible ? `<div class="tr-box"><div class="lbl">Baja más sensible</div><div class="tr-box-name">${r.baja_mas_sensible.player}</div><div class="small">${roleChip(r.baja_mas_sensible.role)} · rating ${Math.round(r.baja_mas_sensible.rating)}${r.baja_mas_sensible.destino?` · → ${r.baja_mas_sensible.destino}`:''}</div></div>` : '';
  return `
    ${r.descripcion ? `<div class="tr-desc">${r.descripcion}</div>` : ''}
    <div class="tr-section-lbl">Top 3 esperados</div>
    <div class="tr-players">${top3}</div>
    <div class="tr-fichajes">${fichaje}${baja}</div>
    <div class="tr-section-lbl">Perfil de plantilla (percentil vs. liga)</div>
    ${hexRadarSVG(r.perfil_atributos_pctl, TEAM_RADAR_AXES)}`;
}
// Desglose auditable del Rating de equipo, jugador a jugador -- pedido
// explicito de Miguel (03/10/2026) tras preguntar como se calculaba: por
// cada jugador (ordenado por rating, de mayor a menor) se aplica un peso
// geometrico (1, 0.80, 0.64, 0.51...) y se SUMA (no se promedia) esa
// contribucion en cada uno de los 6 atributos -- ver TEAM_RATING_DECAY /
// _avg_axis en el pipeline (mismo criterio, replicado aqui en JS para que
// se pueda auditar directamente en el dashboard sin tener que preguntar).
// La fila "Suma ponderada" y el Rating de equipo final se toman TAL CUAL
// de resumen.perfil_atributos / resumen.team_rating (ya calculados en
// Python) para que nunca puedan descuadrar con lo que se ve en la ficha --
// esta tabla es solo para mostrar CÓMO se llega a esos numeros.
const TEAM_RATING_DECAY_JS = 0.80;
function fiabilidadJugadorJS(p){
  let f = 100;
  if(p.status === 'alta_extranjero') f -= 40;
  if(p.low_sample) f -= 30;
  if(p.lesionado) f -= 30;
  if(p.debutante) f -= 15;
  return Math.max(0, f);
}
function teamCalculoBlock(t){
  const r = t.resumen;
  const eq = DATA.equipos[t.team];
  if(!r || !r.perfil_atributos || !eq || !eq.roster_26_27) return '';
  const roster = eq.roster_26_27.filter(p=>p.rating_0_100!=null).slice().sort((a,b)=>b.rating_0_100-a.rating_0_100);
  if(!roster.length) return '';
  const rows = roster.map((p,i)=>{
    const w = Math.pow(TEAM_RATING_DECAY_JS, i);
    const cells = TEAM_RADAR_AXES.map(ax=>{
      const v = ax.key === 'consistencia' ? fiabilidadJugadorJS(p) : (p.atributos ? p.atributos[ax.key] : null);
      return v == null ? '<td>—</td>' : `<td>${Math.round(w*v)}</td>`;
    }).join('');
    return `<tr><td>${p.player}</td><td>${Math.round(p.rating_0_100)}</td><td>${w.toFixed(3)}</td>${cells}</tr>`;
  }).join('');
  const totalCells = TEAM_RADAR_AXES.map(ax=>`<td>${r.perfil_atributos[ax.key]!=null?Math.round(r.perfil_atributos[ax.key]):'—'}</td>`).join('');
  return `<details class="calc-toggle">
    <summary>Ver cálculo</summary>
    <div class="note" style="text-align:left; margin-top:4px;">Jugadores ordenados por su rating individual, de más a menos. El 1º pesa 1, el 2º 0.80, el 3º 0.64... (80% del anterior). Cada columna de atributo es la SUMA de peso × valor del atributo de cada jugador -- no una media -- por eso el total puede superar 100: refleja también cuánto nivel acumulado tiene la plantilla, no solo el perfil medio de un jugador cualquiera.</div>
    <div class="overflow-x"><table class="calc-table">
      <thead><tr><th>Jugador</th><th>Rating</th><th>Peso</th>${TEAM_RADAR_AXES.map(ax=>`<th>${ax.short}</th>`).join('')}</tr></thead>
      <tbody>${rows}<tr class="calc-total"><td colspan="3">Suma ponderada</td>${totalCells}</tr></tbody>
    </table></div>
    <div class="note" style="text-align:left; padding-top:6px;">Rating de equipo = media de esas 6 sumas = <strong>${Math.round(r.team_rating)}</strong>.</div>
  </details>`;
}
// Orden de la lista de equipos: por posicion_proyectada_26_27 (viene de la
// proyeccion de victorias, calendario completo/log5) -- pedido explicito
// de Miguel (24/09/2026): "ordena el ranking y las estrellas correlacionado
// con lo que esperas en racha". Antes ordenaba por team_rating (perfil de
// atributos), que podia divergir de las victorias esperadas -- ahora el
// ORDEN de la lista, las ESTRELLAS (ver starsVisual/estrellas en Python) y
// el V-D esperado mostrado en cada ficha usan la MISMA metrica de fondo,
// no pueden contradecirse entre si.
function renderTeams(){
  const teams = [...DATA.teams].sort((a,b)=>{
    const ar = a.resumen ? a.resumen.posicion_proyectada_26_27 : null, br = b.resumen ? b.resumen.posicion_proyectada_26_27 : null;
    if(ar==null && br==null) return b.rating_pasado.netrtg - a.rating_pasado.netrtg;
    if(ar==null) return 1;
    if(br==null) return -1;
    return ar - br;
  });
  // Ranking de equipos en 5 filas por franja de la tabla (pedido de
  // Miguel, 28/09/2026 -- primero probamos 4 columnas en plan "pipeline"
  // y lo rechazó: "no lo hagas a lo pipeline", pide filas, una por
  // franja). Cortes sobre el ranking ya ordenado arriba por
  // posicion_proyectada_26_27: 1-4 Top 4 · 5-8 Playoffs · 9-12 Pelea por
  // playoffs · 13-16 Pelea por no bajar · 17-18 Descenso. Dentro de cada
  // fila los equipos van en horizontal (team-row-cards), no apilados.
  // El equipo nº1 proyectado se pinta de azul (--rank1), pedido aparte
  // de Miguel para que destaque sobre el resto del Top 4.
  let i = 0;
  const take = n => teams.slice(i, i += n);
  const top4 = take(4), playoffs = take(4), peleaPlayoffs = take(4), peleaNoBajar = take(4), descenso = take(2);

  const row = (title, range, cls, group) => `
    <div class="team-row">
      <div class="team-row-header ${cls}"><span class="team-row-title">${title}</span><span class="team-row-range">${range}</span></div>
      <div class="team-row-cards">${group.map(t => teamCard(t)).join('')}</div>
    </div>`;

  const html = [
    row('Top 4', 'Posiciones 1-4', 'zone-top4', top4),
    row('Playoffs', 'Posiciones 5-8', 'zone-playoffs', playoffs),
    row('Pelea por playoffs', 'Posiciones 9-12', 'zone-pelea-playoffs', peleaPlayoffs),
    row('Pelea por no bajar', 'Posiciones 13-16', 'zone-pelea-descenso', peleaNoBajar),
    row('Descenso', 'Posiciones 17-18', 'zone-descenso', descenso),
  ].join('');
  document.getElementById('teamList').innerHTML = html;
}
renderTeams();

// ---------- pop-up de ficha de equipo ----------
// Pedido de Miguel (28/09/2026): la ficha se abre en un pop-up a pantalla
// completa (no dentro de la tarjeta, ver nota junto a teamFichaBody más
// arriba) y desde el propio pop-up se puede comparar con otro equipo --
// un selector "Comparar con" (opción elegida por Miguel entre varias:
// un único equipo de comparación a la vez, mostrado en dos columnas lado
// a lado dentro del mismo pop-up; sin flechas de siguiente/anterior --
// para ver otra ficha se cierra y se vuelve a la lista).
const fichaModalBackdrop = document.getElementById('fichaModalBackdrop');
const fichaModalBody = document.getElementById('fichaModalBody');
const fichaCompareSelect = document.getElementById('fichaCompareSelect');
let fichaCurrentKey = null;

function populateCompareSelect(excludeKey){
  const opts = ['<option value="">Ninguno</option>'];
  [...DATA.teams]
    .sort((a,b)=>(a.team_sponsor||a.team).localeCompare(b.team_sponsor||b.team, 'es'))
    .forEach(t=>{
      if(t.team === excludeKey) return;
      opts.push(`<option value="${t.team}">${t.team_sponsor||t.team}</option>`);
    });
  fichaCompareSelect.innerHTML = opts.join('');
}
function renderFichaModal(){
  const main = TEAMS_BY_KEY[fichaCurrentKey];
  if(!main) return;
  const compareKey = fichaCompareSelect.value;
  const compare = compareKey ? TEAMS_BY_KEY[compareKey] : null;
  fichaModalBody.innerHTML = `<div class="ficha-columns${compare ? ' is-compare' : ''}">
    ${teamFichaPanelHTML(main)}
    ${compare ? teamFichaPanelHTML(compare) : ''}
  </div>`;
}
function openFicha(teamKey){
  if(!TEAMS_BY_KEY[teamKey]) return;
  fichaCurrentKey = teamKey;
  populateCompareSelect(teamKey);
  fichaCompareSelect.value = '';
  renderFichaModal();
  fichaModalBackdrop.hidden = false;
  document.body.classList.add('ficha-modal-open');
  fichaModalBackdrop.focus();
}
function closeFicha(){
  fichaModalBackdrop.hidden = true;
  document.body.classList.remove('ficha-modal-open');
  fichaCurrentKey = null;
  fichaModalBody.innerHTML = '';
}
document.getElementById('teamList').addEventListener('click', e=>{
  const btn = e.target.closest('.btn-ver-ficha');
  if(btn) openFicha(btn.dataset.teamKey);
});
document.getElementById('fichaModalClose').addEventListener('click', closeFicha);
fichaModalBackdrop.addEventListener('click', e=>{
  if(e.target === fichaModalBackdrop) closeFicha();
});
document.addEventListener('keydown', e=>{
  if(e.key === 'Escape' && !fichaModalBackdrop.hidden) closeFicha();
});
fichaCompareSelect.addEventListener('change', renderFichaModal);

// ---------- render archetype matrix (tab 3) ----------
// Ahora por equipo (antes solo Valencia) y con el rating medio de quien
// cubria cada arquetipo antes/ahora -- pedido de Miguel: "ten en cuenta el
// impacto de los jugadores que se van en la construccion de los arquetipos".
// "Antes" usa rating_base (nivel de produccion la temporada pasada, SIN
// ajuste de contexto de equipo -- una baja no debe llevarse el credito/
// descuento de a donde va) tanto para los que se quedan como para las
// bajas; "Ahora" usa el rating final ya contextualizado a este equipo
// (incluye el ajuste de sistema de Pedro Martinez en Real Madrid).
function chipList(names, cls){
  if(!names || !names.length) return '<span style="color:var(--muted); font-size:12px;">—</span>';
  return names.map(n=>`<span class="player-chip ${cls||''}">${n}</span>`).join('');
}
function ratingLookups(team){
  const eq = DATA.equipos[team];
  const baseMap = {}, finalMap = {};
  eq.roster_26_27.forEach(p=>{
    finalMap[p.player] = p.rating_0_100;
    if(p.status==='returning') baseMap[p.player] = p.rating_base;
  });
  eq.bajas.forEach(p=>{ baseMap[p.player] = p.rating_base; });
  return {baseMap, finalMap};
}
function avgRating(names, map){
  const vals = (names||[]).map(n=>map[n]).filter(v=>v!=null);
  if(!vals.length) return null;
  return vals.reduce((a,b)=>a+b,0)/vals.length;
}
let arqFilterTeam = TEAM_NAMES[0];
const FAM_LABELS = {play:'Creación / manejo', score:'Anotación', wing:'Ala / combo', big:'Interior'};
const FAM_ORDER_LIST = ['play','score','wing','big'];
function renderMatrix(){
  const eq = DATA.equipos[arqFilterTeam];
  const last = eq.archetypes_last, now = eq.archetypes_new;
  const roles = Array.from(new Set([...Object.keys(last), ...Object.keys(now)]));
  const byFam = {};
  roles.forEach(role=>{
    const f = famOf(role);
    (byFam[f] = byFam[f] || []).push(role);
  });
  Object.values(byFam).forEach(list => list.sort((a,b)=>a.localeCompare(b)));
  const html = FAM_ORDER_LIST.filter(f => byFam[f] && byFam[f].length).map(f => {
    const rows = byFam[f].map(role=>{
      const before = last[role]||[], after = now[role]||[];
      const isNewRole = before.length===0 && after.length>0;
      const isGoneRole = before.length>0 && after.length===0;
      return `<div class="matrix-row ${isNewRole||isGoneRole?'changed':''}">
        <div class="matrix-role"><span style="color:var(--fam-${f})">●</span> ${roleEs(role)}${isNewRole?' <span class="role-chip" style="background:var(--pos-soft);color:var(--pos)">Nuevo</span>':''}${isGoneRole?' <span class="role-chip" style="background:var(--neg-soft);color:var(--neg)">Desaparece</span>':''}</div>
        <div class="matrix-cell" data-label="Año pasado">${chipList(before)}</div>
        <div class="matrix-cell" data-label="Este año">${chipList(after)}</div>
      </div>`;
    }).join('');
    return `<div class="matrix-fam"><div class="matrix-fam-lbl" style="color:var(--fam-${f})"><span style="background:var(--fam-${f})" class="dot"></span>${FAM_LABELS[f]}</div>${rows}</div>`;
  }).join('');
  document.getElementById('matrixList').innerHTML = html;
}
// Tab "Matriz de arquetipos" retirada de momento (24/09/2026) -- se guarda
// esta llamada detras de un guard en vez de borrar renderMatrix() y sus
// funciones de apoyo, para poder reactivarla sin reescribir la logica.
if(document.getElementById('matrixList')) renderMatrix();

// ---- filtro Equipo (tab 3, inactivo mientras el panel este retirado) ----
const arqTeamGrp = document.getElementById('arqTeamGrp');
if(arqTeamGrp){
  arqTeamGrp.innerHTML = TEAM_NAMES.map((t,i) => `<button class="chip${i===0?' active':''}" data-team="${t}">${teamLogo(DATA.equipos[t].roster_26_27[0]?.logo_key || null)}${t}</button>`).join('');
  arqTeamGrp.querySelectorAll('.chip').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      arqTeamGrp.querySelectorAll('.chip').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active'); arqFilterTeam = btn.dataset.team; renderMatrix();
    });
  });
}

# -*- coding: utf-8 -*-
"""
Compila frontend/dashboard/{index.html, styles.css, app.js, assets/*} + el
JSON de datos que produce el pipeline de backend (backend/data/roster_dashboard_data.json,
generado por backend/pipeline/29_valencia_dashboard_data.py) en un unico
fichero HTML autocontenido: dist/dashboard_roster_final.html.

Por que un solo fichero: el Artifact de claude.ai donde se publica el
dashboard exige un unico HTML sin hosts externos (salvo Google Fonts) y sin
<!doctype>/<html>/<head>/<body> propios -- el visor de artefactos envuelve
el contenido con su propio esqueleto al publicar. Por eso dist/dashboard_roster_final.html
mantiene el mismo formato "fragmento" que ya tenia el dashboard antes de
separar frontend/backend (empieza directo en <title>, sin <!doctype html>).

index.html, en cambio, SI es una pagina normal (con <link>/<script src>
relativos) para poder abrirla y trabajar la maquetacion/estilos localmente
sin pasar por el build -- lo unico que le falta sin build.py es el JSON de
datos real (DATA queda sin definir) y los logos como base64 en vez de
ficheros locales.

Uso:
    cd frontend/dashboard
    python3 build.py
"""
import base64
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_JSON_PATH = os.path.normpath(os.path.join(HERE, '..', '..', 'backend', 'data', 'roster_dashboard_data.json'))
OUT_PATH = os.path.join(HERE, 'dist', 'dashboard_roster_final.html')


def b64_data_uri(path, mime):
    with open(path, 'rb') as f:
        return f'data:{mime};base64,' + base64.b64encode(f.read()).decode('ascii')


def main():
    with open(os.path.join(HERE, 'index.html'), encoding='utf-8') as f:
        html = f.read()
    with open(os.path.join(HERE, 'styles.css'), encoding='utf-8') as f:
        css = f.read()
    with open(os.path.join(HERE, 'app.js'), encoding='utf-8') as f:
        js = f.read()
    with open(DATA_JSON_PATH, encoding='utf-8') as f:
        data_json = f.read()

    logo_acb = b64_data_uri(os.path.join(HERE, 'assets', 'logo_acb.png'), 'image/png')
    logo_lnd = b64_data_uri(os.path.join(HERE, 'assets', 'logo_lnd.png'), 'image/png')

    if '<link rel="stylesheet" href="styles.css">' not in html:
        raise SystemExit('index.html: no encuentro el <link> de styles.css -- ¿se edito la estructura?')
    if '<script src="app.js"></script>' not in html:
        raise SystemExit('index.html: no encuentro el <script src="app.js"> -- ¿se edito la estructura?')

    html = html.replace('<link rel="stylesheet" href="styles.css">', f'<style>\n{css}\n</style>')
    html = html.replace('<script src="app.js"></script>', f'<script>\nconst DATA = {data_json};\n\n{js}\n</script>')
    html = html.replace('src="assets/logo_acb.png"', f'src="{logo_acb}"')
    html = html.replace('src="assets/logo_lnd.png"', f'src="{logo_lnd}"')

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f'Construido {OUT_PATH} ({len(html):,} caracteres)')


if __name__ == '__main__':
    main()
